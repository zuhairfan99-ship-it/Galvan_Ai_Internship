/* ==========================================================
   LEGAL CONSULTANCY
   Client Side Validation
========================================================== */

(function () {

    "use strict";

    // -------------------------------------------------
    // Footer Year
    // -------------------------------------------------

    const year = document.getElementById("year");

    if (year) {
        year.textContent = new Date().getFullYear();
    }

    // -------------------------------------------------
    // Navbar Shadow
    // -------------------------------------------------

    const navbar = document.querySelector(".firm-navbar");

    if (navbar) {

        window.addEventListener("scroll", function () {

            navbar.style.boxShadow =
                window.scrollY > 30
                    ? "0 4px 18px rgba(0,0,0,.25)"
                    : "none";

        });

    }

    // -------------------------------------------------
    // Description Counter
    // -------------------------------------------------

    const description = document.getElementById("description");
    const descCount = document.getElementById("descCount");

    if (description && descCount) {

        function updateCounter() {

            const length = description.value.length;

            descCount.textContent = length;

            descCount.classList.toggle(
                "text-danger",
                length > 0 && length < 20
            );

        }

        description.addEventListener("input", updateCounter);

        updateCounter();

    }

    // -------------------------------------------------
    // Validation Regex
    // -------------------------------------------------

    // Letters and spaces only
    const NAME_REGEX = /^[A-Za-z ]+$/;

    // International phone numbers (loose client-side check only;
    // the backend uses the `phonenumbers` library for the real,
    // authoritative validation). Allows a leading "+" for full
    // international numbers, or a leading "0" for local-format
    // numbers like 03430099556.
    const PHONE_REGEX = /^\+?[0-9]{8,15}$/;

    // Email
    const EMAIL_REGEX =
        /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

    // -------------------------------------------------
    // Form
    // -------------------------------------------------

    // ==========================================================
    // NEW: Analytics modal + independent Book a Call workflow.
    // Everything below is additive - none of the code above this
    // point has been changed, so the existing consultation form
    // and Calendly modal keep working exactly as before.
    // ==========================================================

    // -------------------------------------------------
    // Best-effort analytics event logger (never blocks the UI)
    // -------------------------------------------------
    function logAnalyticsEvent(eventName, metadata) {
        try {
            fetch("/api/analytics/event", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ event: eventName, metadata: metadata || {} }),
            }).catch(function () {
                /* silently ignore - analytics logging must never break the UI */
            });
        } catch (err) {
            /* no-op */
        }
    }

    // -------------------------------------------------
    // Analytics Modal -> chain into the chosen target modal
    // -------------------------------------------------
    const analyticsModalEl = document.getElementById("analyticsModal");

    if (analyticsModalEl && window.bootstrap) {

        const analyticsModal = bootstrap.Modal.getOrCreateInstance(analyticsModalEl);

        analyticsModalEl.addEventListener("shown.bs.modal", function () {
            logAnalyticsEvent("analytics_modal_opened");
        });

        document.querySelectorAll(".analytics-option-btn").forEach(function (btn) {

            btn.addEventListener("click", function () {

                const targetSelector = btn.getAttribute("data-target-modal");
                const analyticsEvent = btn.getAttribute("data-analytics-event");
                const targetEl = targetSelector && document.querySelector(targetSelector);

                if (analyticsEvent) {
                    logAnalyticsEvent(analyticsEvent);
                }

                if (!targetEl) {
                    return;
                }

                // Wait for the Analytics modal to fully hide before showing
                // the target modal, so Bootstrap doesn't stack backdrops.
                analyticsModalEl.addEventListener(
                    "hidden.bs.modal",
                    function openTarget() {
                        bootstrap.Modal.getOrCreateInstance(targetEl).show();
                        analyticsModalEl.removeEventListener("hidden.bs.modal", openTarget);
                    }
                );

                analyticsModal.hide();

            });

        });

    }

    // -------------------------------------------------
    // New "Book a Call" form (independent of Calendly)
    // -------------------------------------------------
    const newBookingForm = document.getElementById("newBookingForm");

    if (newBookingForm) {

        const bkFullName = document.getElementById("booking_full_name");
        const bkEmail = document.getElementById("booking_email");
        const bkPhone = document.getElementById("booking_phone");
        const bkCompany = document.getElementById("booking_company_name");
        const bkDate = document.getElementById("booking_preferred_date");
        const bkTime = document.getElementById("booking_preferred_time");
        const bkMessage = document.getElementById("booking_message");

        const submitBtn = document.getElementById("newBookingSubmitBtn");
        const spinner = document.getElementById("newBookingSpinner");
        const btnText = submitBtn.querySelector(".btn-text");

        const successBox = document.getElementById("newBookingSuccess");
        const successDetails = document.getElementById("newBookingSuccessDetails");
        const meetLinkBtn = document.getElementById("newBookingMeetLink");
        const generalError = document.getElementById("newBookingGeneralError");

        // Reuse the same loose client-side regexes already defined above
        // for the consultation form (NAME_REGEX, PHONE_REGEX, EMAIL_REGEX);
        // the backend remains the source of truth for validation either way.

        [bkFullName, bkEmail, bkPhone, bkDate, bkTime, bkCompany, bkMessage].forEach(function (field) {
            if (field) {
                field.addEventListener("input", function () {
                    this.setCustomValidity("");
                });
            }
        });

        newBookingForm.addEventListener("submit", function (event) {

            event.preventDefault();
            event.stopPropagation();

            generalError.classList.add("d-none");
            generalError.textContent = "";

            let valid = newBookingForm.checkValidity();

            if (!NAME_REGEX.test(bkFullName.value.trim())) {
                bkFullName.setCustomValidity("Please enter a valid name using letters only.");
                valid = false;
            }

            if (!EMAIL_REGEX.test(bkEmail.value.trim())) {
                bkEmail.setCustomValidity("Enter a valid email.");
                valid = false;
            }

            const cleanedPhone = bkPhone.value.replace(/\s|-/g, "");
            if (!PHONE_REGEX.test(cleanedPhone)) {
                bkPhone.setCustomValidity("Enter a valid international phone number.");
                valid = false;
            }

            newBookingForm.classList.add("was-validated");

            if (!valid) {
                return;
            }

            submitBtn.disabled = true;
            btnText.classList.add("d-none");
            spinner.classList.remove("d-none");

            const payload = {
                full_name: bkFullName.value.trim(),
                email: bkEmail.value.trim(),
                phone: bkPhone.value.trim(),
                company_name: bkCompany.value.trim(),
                preferred_date: bkDate.value,
                preferred_time: bkTime.value,
                message: bkMessage.value.trim(),
            };

            fetch("/api/book-call", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(payload),
            })
                .then(function (response) {
                    return response.json().then(function (data) {
                        return { ok: response.ok, data: data };
                    });
                })
                .then(function (result) {

                    submitBtn.disabled = false;
                    btnText.classList.remove("d-none");
                    spinner.classList.add("d-none");

                    if (!result.ok || !result.data.success) {

                        const errors = (result.data && result.data.errors) || {};

                        if (errors._general) {
                            generalError.textContent = errors._general;
                            generalError.classList.remove("d-none");
                        } else {
                            generalError.textContent =
                                "Please correct the highlighted fields and try again.";
                            generalError.classList.remove("d-none");
                        }

                        return;
                    }

                    // Success: show confirmation state in place (no page reload).
                    newBookingForm.classList.add("d-none");
                    successBox.classList.remove("d-none");

                    successDetails.textContent =
                        result.data.preferred_date + " at " + result.data.preferred_time +
                        " (Booking ID: " + result.data.booking_id + ")";

                    if (result.data.meet_link) {
                        meetLinkBtn.href = result.data.meet_link;
                        meetLinkBtn.classList.remove("d-none");
                        // Automatically open Google Meet after booking
                        setTimeout(function () {
                             window.open(result.data.meet_link, "_blank");
                        }, 1500);
                    }

                })
                .catch(function () {

                    submitBtn.disabled = false;
                    btnText.classList.remove("d-none");
                    spinner.classList.add("d-none");

                    generalError.textContent =
                        "Something went wrong while booking your call. Please try again.";
                    generalError.classList.remove("d-none");

                });

        });

        // Reset the form/modal back to its initial state each time it's reopened.
        const newBookingModalEl = document.getElementById("newBookingModal");

        if (newBookingModalEl) {
            newBookingModalEl.addEventListener("hidden.bs.modal", function () {
                newBookingForm.classList.remove("d-none", "was-validated");
                newBookingForm.reset();
                successBox.classList.add("d-none");
                meetLinkBtn.classList.add("d-none");
                generalError.classList.add("d-none");
                submitBtn.disabled = false;
                btnText.classList.remove("d-none");
                spinner.classList.add("d-none");
            });
        }

    }

    const form = document.getElementById("consultationForm");

    if (!form) return;

    const submitBtn = document.getElementById("submitBtn");

    const spinner = document.getElementById("submitSpinner");

    const btnText = submitBtn.querySelector(".btn-text");

    // -------------------------------------------------
    // Inputs
    // -------------------------------------------------

    const fullName = document.getElementById("full_name");

    const email = document.getElementById("email");

    const phone = document.getElementById("phone");

    // -------------------------------------------------
    // Live Validation
    // -------------------------------------------------

    fullName.addEventListener("input", function () {

        this.value = this.value.replace(/[^A-Za-z ]/g, "");

        this.setCustomValidity("");

    });

    email.addEventListener("input", function () {

        this.setCustomValidity("");

    });

    phone.addEventListener("input", function () {

        this.setCustomValidity("");

    });

    description.addEventListener("input", function () {

        this.setCustomValidity("");

    });

    // -------------------------------------------------
    // Submit Validation
    // -------------------------------------------------

    form.addEventListener("submit", function (event) {

        let valid = form.checkValidity();

        // ----------------------------
        // Name
        // ----------------------------

        if (!NAME_REGEX.test(fullName.value.trim())) {

            fullName.setCustomValidity(
                "Please enter a valid name using letters only."
            );

            valid = false;

        } else {

            fullName.setCustomValidity("");

        }

        // ----------------------------
        // Email
        // ----------------------------

        if (!EMAIL_REGEX.test(email.value.trim())) {

            email.setCustomValidity(
                "Enter a valid email."
            );

            valid = false;

        } else {

            email.setCustomValidity("");

        }

        // ----------------------------
        // Phone
        // ----------------------------

        const cleanedPhone = phone.value.replace(/\s|-/g, "");

        if (!PHONE_REGEX.test(cleanedPhone)) {

            phone.setCustomValidity(
                "Enter a valid international phone number."
            );

            valid = false;

        } else {

            phone.setCustomValidity("");

        }

        // ----------------------------
        // Description
        // ----------------------------

        if (description.value.trim().length < 20) {

            description.setCustomValidity(
                "Please enter at least 20 characters."
            );

            valid = false;

        } else {

            description.setCustomValidity("");

        }

        // ----------------------------
        // Bootstrap
        // ----------------------------

        if (!valid) {

            event.preventDefault();

            event.stopPropagation();

        } else {

            submitBtn.disabled = true;

            btnText.classList.add("d-none");

            spinner.classList.remove("d-none");

        }

        form.classList.add("was-validated");

    });

    // -------------------------------------------------
    // Scroll Reveal
    // -------------------------------------------------

    const cards = document.querySelectorAll(

        ".why-card,.service-card,.info-card,.contact-info-card,.form-card"

    );

    cards.forEach(card => card.classList.add("reveal-on-scroll"));

    if ("IntersectionObserver" in window) {

        const observer = new IntersectionObserver(

            entries => {

                entries.forEach(entry => {

                    if (entry.isIntersecting) {

                        entry.target.classList.add("is-visible");

                        observer.unobserve(entry.target);

                    }

                });

            },

            {
                threshold: 0.15
            }

        );

        cards.forEach(card => observer.observe(card));

    } else {

        cards.forEach(card => card.classList.add("is-visible"));

    }

    // -------------------------------------------------
    // Smooth Scroll
    // -------------------------------------------------

    document.querySelectorAll('a[href^="#"]').forEach(anchor => {

        anchor.addEventListener("click", function (e) {

            const target = document.querySelector(this.getAttribute("href"));

            if (target) {

                e.preventDefault();

                target.scrollIntoView({

                    behavior: "smooth",

                    block: "start"

                });

            }

        });

    });

    // -------------------------------------------------
    // Book a Call — Calendly Modal
    // -------------------------------------------------
    // The Calendly widget script (assets.calendly.com) injects an
    // iframe into #calendlyWidget once it loads. If the script is
    // blocked (ad-blocker, offline, network policy) or fails to load,
    // show a fallback link to open Calendly in a new tab instead.

    const bookCallModal = document.getElementById("bookCallModal");

    if (bookCallModal) {

        bookCallModal.addEventListener("shown.bs.modal", function () {

            const widget = document.getElementById("calendlyWidget");
            const fallback = document.getElementById("calendlyFallback");

            if (!widget || !fallback) {
                return;
            }

            // Give the Calendly script a few seconds to inject its iframe.
            setTimeout(function () {

                const hasCalendlyFrame = widget.querySelector("iframe");
                const calendlyLoaded = typeof window.Calendly !== "undefined";

                if (!hasCalendlyFrame && !calendlyLoaded) {
                    widget.style.display = "none";
                    fallback.classList.remove("d-none");
                }

            }, 6000);

        });

    }


})();