# Legal Consultancy — Contact & Lead Capture System

A production-ready Flask web application for law firms to capture, store,
and respond to legal consultation leads. Submissions are validated on both
the client and server, saved automatically to a Google Sheet, and trigger
two professional HTML emails (one to the business owner, one to the client).

---

## Table of Contents

1. [Project Overview](#project-overview)
2. [Features](#features)
3. [Folder Structure](#folder-structure)
4. [Installation](#installation)
5. [Virtual Environment Setup](#virtual-environment-setup)
6. [Installing Dependencies](#installing-dependencies)
7. [Google Sheets Setup](#google-sheets-setup)
8. [Environment Variables](#environment-variables)
9. [SMTP / Gmail App Password Setup](#smtp--gmail-app-password-setup)
10. [Running the Project](#running-the-project)
11. [Deployment on Render](#deployment-on-render)
12. [Troubleshooting](#troubleshooting)

---

## Project Overview

This system allows visitors to a law firm's website to submit a legal
consultation request through a professional, validated web form. On
successful submission:

1. The lead is validated server-side (in addition to client-side checks).
2. The lead is appended as a new row to a Google Sheet.
3. The business owner receives an HTML email notification with the lead's details.
4. The customer receives a professional HTML confirmation email.
5. The visitor is redirected to a success page.

---

## Features

- Modern, responsive law-firm themed UI (dark blue / white / light gray / gold)
- Bootstrap 5 + Bootstrap Icons, subtle scroll/hover animations
- Full client-side **and** server-side validation
  - Name (min. 3 characters)
  - Proper email format
  - Pakistani phone number formats (`03XXXXXXXXX`, `+923XXXXXXXXX`)
  - Description (min. 20 characters)
  - Consultation date cannot be in the past
  - Required-field and Privacy Policy checkbox enforcement
- Automatic Google Sheets storage via a service account (`gspread`)
- Two professional HTML emails sent via SMTP (Gmail App Password compatible)
- Flash messages, custom 404 / 500 error pages
- Loading spinner on submit, smooth in-page navigation
- Render.com-ready (`gunicorn` compatible)

---

## Folder Structure

```
legal_consultancy/
├── app.py
├── config.py
├── requirements.txt
├── README.md
├── .env.example
├── .gitignore
├── credentials.json.example
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── success.html
│   ├── 404.html
│   ├── 500.html
│   └── emails/
│       ├── business_notification.html
│       └── customer_confirmation.html
├── static/
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   └── main.js
│   └── img/
│       └── logo.png
└── utils/
    ├── google_sheets.py
    ├── email_service.py
    └── validators.py
```

---

## Installation

Clone or copy this folder into VS Code, then open a terminal inside the
`legal_consultancy/` folder.

---

## Virtual Environment Setup

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS / Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

---

## Installing Dependencies

```bash
pip install -r requirements.txt
```

---

## Google Sheets Setup

### 1. Create a Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project (or select an existing one).
3. Navigate to **APIs & Services → Library**.
4. Enable **Google Sheets API** and **Google Drive API**.

### 2. Create a Service Account

1. Go to **APIs & Services → Credentials**.
2. Click **Create Credentials → Service Account**.
3. Give it a name (e.g. `legal-consultancy-sheets`).
4. Once created, open the service account, go to the **Keys** tab.
5. Click **Add Key → Create New Key → JSON**.
6. Download the JSON file.

### 3. Configure credentials.json

1. Rename the downloaded file to `credentials.json`.
2. Place it in the project root (same folder as `app.py`).
3. **Never commit this file to version control** — it's already excluded
   in `.gitignore`. A `credentials.json.example` is provided to show the
   expected structure.

### 4. Share Your Google Sheet

1. Create a new Google Sheet (or let the app create one automatically on
   first run — it will use the name from `GOOGLE_SHEET_NAME`).
2. Open the `credentials.json` file and copy the `client_email` value
   (looks like `xxxx@xxxx.iam.gserviceaccount.com`).
3. In your Google Sheet, click **Share** and paste that email address,
   giving it **Editor** access.
4. Set `GOOGLE_SHEET_NAME` in your `.env` file to match the sheet's exact name.

---

## Environment Variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env      # macOS/Linux
copy .env.example .env    # Windows
```

Then fill in every value:

| Variable | Description |
|---|---|
| `SECRET_KEY` | Random string used by Flask for sessions/flash messages |
| `FLASK_ENV` | `development` or `production` |
| `GOOGLE_CREDENTIALS_FILE` | Path to your `credentials.json` (default: `credentials.json`) |
| `GOOGLE_SHEET_NAME` | Exact name of your Google Sheet |
| `SMTP_SERVER` | SMTP host (default `smtp.gmail.com`) |
| `SMTP_PORT` | SMTP port (default `587`) |
| `SMTP_EMAIL` | The Gmail address emails are sent from |
| `SMTP_PASSWORD` | Gmail **App Password** (not your normal password) |
| `BUSINESS_OWNER_EMAIL` | Where new lead notifications are sent |
| `COMPANY_NAME` | Displayed throughout the site and emails |

---

## SMTP / Gmail App Password Setup

Gmail no longer allows normal account passwords for SMTP. You must generate
an **App Password**:

1. Enable 2-Step Verification on your Google Account: `myaccount.google.com/security`.
2. Go to `myaccount.google.com/apppasswords`.
3. Select **Mail** as the app and generate a password.
4. Copy the 16-character password and paste it into `SMTP_PASSWORD` in `.env`.
5. Set `SMTP_EMAIL` to the full Gmail address used to generate the app password.

---

## Running the Project

```bash
python app.py
```

The app will be available at `http://127.0.0.1:5000`.

For a production-style local run:

```bash
gunicorn app:app
```

---

## Deployment on Render

1. Push this project to a GitHub repository (`.env` and `credentials.json`
   are already excluded via `.gitignore` — do **not** commit them).
2. On [Render.com](https://render.com), create a **New Web Service** and
   connect your repository.
3. Set the **Build Command**:
   ```
   pip install -r requirements.txt
   ```
4. Set the **Start Command**:
   ```
   gunicorn app:app
   ```
5. Under **Environment**, add every variable from `.env.example` as a
   Render environment variable (Render's dashboard, not a committed file).
6. For `credentials.json`, use Render's **Secret Files** feature:
   - Add a secret file named `credentials.json` with the full JSON contents.
   - Render mounts it at the project root automatically, matching
     `GOOGLE_CREDENTIALS_FILE=credentials.json`.
7. Deploy. Render will build and start the app automatically on every push.

---

## NEW FEATURE: Analytics Menu &amp; "Book a Call" (Google Calendar)

This adds a new **Analytics** item to the navbar. Clicking it opens a
responsive modal with two choices:

* **Schedule a Meeting** — opens the existing Calendly modal (`#bookCallModal`),
  completely unchanged from before.
* **Book a Call** — opens a brand-new, independent modal/form that creates a
  real Google Calendar event with a Google Meet link (no Calendly involved),
  saves the booking to its own "Bookings" worksheet, and emails both the
  customer and the business team.

### New Modules

| File | Purpose |
|---|---|
| `utils/google_calendar.py` | Creates the Google Calendar event + Google Meet link, invites both parties |
| `utils/booking_sheets.py` | Appends bookings to a dedicated "Bookings" worksheet (separate from the consultation sheet) |
| `utils/booking_service.py` | Orchestrates calendar → sheet → email for each booking, with structured logging |
| `utils/analytics_service.py` | Structured logging for Analytics-menu interactions |

### Additional Setup for the Google Calendar API

1. In the same Google Cloud project used for Sheets, enable the **Google Calendar API**
   (APIs & Services → Library → "Google Calendar API" → Enable).
2. The existing service account (`credentials.json`) is reused — no new key file
   is required — but make sure the calendar you want events created on is
   either the service account's own "primary" calendar, or has been shared
   with the service account's `client_email` with **"Make changes to events"** permission.
3. (Optional, recommended for Google Workspace users) To have Google actually
   **email** the Meet invite to attendees, configure
   [domain-wide delegation](https://developers.google.com/identity/protocols/oauth2/service-account#delegatingauthority)
   for the service account, then set `GOOGLE_WORKSPACE_DELEGATED_USER` to a
   real mailbox in your Workspace. Without this, the event, attendees, and
   Meet link are still created correctly — Google may just not auto-send the
   email invite for a bare service account.

### New Environment Variables

Add these to your `.env` (all optional — sensible defaults are used if omitted):

| Variable | Default | Description |
|---|---|---|
| `GOOGLE_CALENDAR_ID` | `primary` | Calendar to create booking events on |
| `GOOGLE_WORKSPACE_DELEGATED_USER` | *(blank)* | Workspace user to impersonate for domain-wide delegation (optional) |
| `BOOKING_TIMEZONE` | `Asia/Karachi` | Time zone used for booking events |
| `BOOKING_DURATION_MINUTES` | `30` | Length of each booked call |
| `BOOKING_SHEET_ID` | *(falls back to `GOOGLE_SHEET_ID`)* | Spreadsheet ID to store bookings in |
| `BOOKING_WORKSHEET_NAME` | `Bookings` | Worksheet/tab name for bookings (auto-created if missing) |

### New Routes

| Route | Method | Purpose |
|---|---|---|
| `/api/book-call` | POST (JSON) | Validates and creates a booking (calendar event, sheet row, emails) |
| `/api/analytics/event` | POST (JSON) | Best-effort logging of Analytics-menu interactions |

---

## Troubleshooting

**"Google credentials file not found"**
Make sure `credentials.json` exists in the project root and
`GOOGLE_CREDENTIALS_FILE` in `.env` points to the correct path.

**`gspread.exceptions.SpreadsheetNotFound` / permission errors**
Confirm you shared the Google Sheet with the `client_email` from your
`credentials.json`, and that `GOOGLE_SHEET_NAME` matches exactly (case-sensitive).

**Emails not sending / `SMTPAuthenticationError`**
- Confirm you're using a Gmail **App Password**, not your regular password.
- Confirm 2-Step Verification is enabled on the Gmail account.
- Check `SMTP_EMAIL` and `SMTP_PASSWORD` are correct in `.env`.

**Form submits but nothing appears in the sheet**
Check the terminal/log output — the app logs Google Sheets errors but still
completes the request so the user isn't blocked. Look for
`Failed to save lead to Google Sheets` in the logs.

**Static files (CSS/JS) not loading**
Ensure you're running the app via `python app.py` or `gunicorn app:app`
from the project root, not from inside the `static/` folder.

**Phone validation rejecting valid numbers**
Only Pakistani formats are accepted: `03XXXXXXXXX`, `+923XXXXXXXXX`,
`923XXXXXXXXX`, or `00923XXXXXXXXX`. International numbers from other
countries are intentionally rejected per the project's requirements.

**"Book a Call" fails with a Calendar error**
Confirm the Google Calendar API is enabled in the same Cloud project as
Sheets, and that the service account's `client_email` has access to the
target calendar (`GOOGLE_CALENDAR_ID`). Check the logs for the exact
Google API error returned.

**Booking succeeds but attendees never receive an email invite**
This is expected for a bare service account without domain-wide
delegation. Set `GOOGLE_WORKSPACE_DELEGATED_USER` (see the Google
Calendar setup section above) if you need Google to auto-send invites.
The booking confirmation emails (sent via SMTP, same as the rest of the
site) still go out regardless.

---

Built with Flask, Bootstrap 5, gspread, and smtplib.
