"""
config.py
---------
Central configuration for the Legal Consultancy Flask application.
All values are pulled from environment variables (see .env.example)
so that no secrets are ever hard-coded into the source tree.
"""

import os
from dotenv import load_dotenv

# Load variables from a local .env file (if present) into os.environ
load_dotenv()


class Config:
    """Base configuration shared by every environment."""

    # --- Flask core settings -------------------------------------------------
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-secret-key-change-me")
    FLASK_ENV = os.environ.get("FLASK_ENV", "production")
    DEBUG = FLASK_ENV == "development"

    # --- Google Sheets settings ----------------------------------------------
    GOOGLE_CREDENTIALS_FILE = os.environ.get("GOOGLE_CREDENTIALS_FILE", "credentials.json")
    GOOGLE_SHEET_ID = os.environ.get("GOOGLE_SHEET_ID", "")

    # --- SMTP / Email settings ------------------------------------------------
    SMTP_SERVER = os.environ.get("SMTP_SERVER", "smtp.gmail.com")
    SMTP_PORT = int(os.environ.get("SMTP_PORT", 587))
    SMTP_EMAIL = os.environ.get("SMTP_EMAIL", "")
    SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")

    BUSINESS_OWNER_EMAIL = os.environ.get("BUSINESS_OWNER_EMAIL", "")
    COMPANY_NAME = os.environ.get("COMPANY_NAME", "Legal Consultancy")

    # --- Misc -------------------------------------------------------------
    # Column headers written to the Google Sheet, in order.
    # NOTE: "Consultation Date" has been removed (field no longer collected).
    # Order matches the order fields appear on the consultation form.
    SHEET_HEADERS = [
        "Timestamp",
        "Full Name",
        "Email",
        "Phone",
        "City",
        "Preferred Contact Method",
        "Legal Service",
        "Subject",
        "Description",
    ]

    LEGAL_SERVICES = [
        "Family Law",
        "Corporate Law",
        "Property Law",
        "Criminal Law",
        "Immigration",
        "Tax Law",
        "Civil Litigation",
        "Contract Review",
        "Other",
    ]

    # ---------------------------------------------------------------------
    # NEW: "Book a Call" workflow settings (Google Calendar + Meet).
    # Purely additive - none of the settings above were changed, and the
    # existing Calendly / consultation-sheet configuration is untouched.
    # ---------------------------------------------------------------------

    # Reuses the same service-account JSON already used for Google Sheets
    # (see GOOGLE_CREDENTIALS_FILE above). The service account additionally
    # needs the Google Calendar API enabled/scoped in Google Cloud Console,
    # and the target calendar shared with its client_email.
    GOOGLE_CALENDAR_ID = os.environ.get("GOOGLE_CALENDAR_ID", "primary")

    # Optional: a real Google Workspace user email to impersonate via
    # domain-wide delegation, so Calendar invites are actually emailed to
    # attendees. Leave blank if not using Google Workspace / delegation.
    GOOGLE_WORKSPACE_DELEGATED_USER = os.environ.get(
        "GOOGLE_WORKSPACE_DELEGATED_USER", ""
    )

    BOOKING_TIMEZONE = os.environ.get("BOOKING_TIMEZONE", "Asia/Karachi")
    BOOKING_DURATION_MINUTES = int(os.environ.get("BOOKING_DURATION_MINUTES", 30))

    # Same spreadsheet as GOOGLE_SHEET_ID by default, but written to a
    # separate worksheet tab so consultation data is never touched.
    BOOKING_SHEET_ID = os.environ.get("BOOKING_SHEET_ID", "") or os.environ.get(
        "GOOGLE_SHEET_ID", ""
    )
    BOOKING_WORKSHEET_NAME = os.environ.get("BOOKING_WORKSHEET_NAME", "Bookings")

    BOOKING_SHEET_HEADERS = [
        "Booking ID",
        "Full Name",
        "Email",
        "Phone",
        "Company Name",
        "Preferred Date",
        "Preferred Time",
        "Time Zone",
        "Google Calendar Event ID",
        "Google Meet Link",
        "Booking Status",
        "Created At",
    ]


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


config_map = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
}


def get_config():
    """Return the config class matching the current FLASK_ENV."""
    env = os.environ.get("FLASK_ENV", "production")
    return config_map.get(env, ProductionConfig)
