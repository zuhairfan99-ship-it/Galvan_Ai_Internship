"""
app.py
------
Main Flask application entry point for the
Legal Consultancy - Contact & Lead Capture System.

Run locally with:
    python app.py

Or with gunicorn (production / Render.com):
    gunicorn app:app
"""

import logging
from datetime import date

from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

from config import get_config
from utils.validators import validate_form
from utils.google_sheets import GoogleSheetsService
from utils.email_service import EmailService

# --- NEW: "Book a Call" (Google Calendar) + Analytics modal imports ----- #
# These are additive imports only; none of the imports above were changed.
from utils.validators import validate_booking_form
from utils.google_calendar import GoogleCalendarService
from utils.booking_sheets import BookingSheetsService
from utils.booking_service import BookingService, BookingServiceError
from utils.analytics_service import AnalyticsService

# --------------------------------------------------------------------- #
# App & configuration setup
# --------------------------------------------------------------------- #
app = Flask(__name__)
app.config.from_object(get_config())

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

# --------------------------------------------------------------------- #
# Service instances (lazily connect on first real use)
# --------------------------------------------------------------------- #
sheets_service = GoogleSheetsService(
    credentials_file=app.config["GOOGLE_CREDENTIALS_FILE"],
    sheet_id=app.config["GOOGLE_SHEET_ID"],
    headers=app.config["SHEET_HEADERS"],
)

email_service = EmailService(
    smtp_server=app.config["SMTP_SERVER"],
    smtp_port=app.config["SMTP_PORT"],
    smtp_email=app.config["SMTP_EMAIL"],
    smtp_password=app.config["SMTP_PASSWORD"],
    business_owner_email=app.config["BUSINESS_OWNER_EMAIL"],
    company_name=app.config["COMPANY_NAME"],
)

# --------------------------------------------------------------------- #
# NEW: "Book a Call" (Google Calendar) + Analytics service instances.
# Additive only - the sheets_service and email_service instances above
# are untouched and continue to serve the existing consultation flow.
# --------------------------------------------------------------------- #
calendar_service = GoogleCalendarService(
    credentials_file=app.config["GOOGLE_CREDENTIALS_FILE"],
    calendar_id=app.config["GOOGLE_CALENDAR_ID"],
    delegated_user=app.config["GOOGLE_WORKSPACE_DELEGATED_USER"],
    default_duration_minutes=app.config["BOOKING_DURATION_MINUTES"],
    timezone=app.config["BOOKING_TIMEZONE"],
)

booking_sheets_service = BookingSheetsService(
    credentials_file=app.config["GOOGLE_CREDENTIALS_FILE"],
    sheet_id=app.config["BOOKING_SHEET_ID"],
    worksheet_name=app.config["BOOKING_WORKSHEET_NAME"],
    headers=app.config["BOOKING_SHEET_HEADERS"],
)

booking_service = BookingService(
    calendar_service=calendar_service,
    booking_sheets_service=booking_sheets_service,
    email_service=email_service,
    business_owner_email=app.config["BUSINESS_OWNER_EMAIL"],
    company_name=app.config["COMPANY_NAME"],
    timezone=app.config["BOOKING_TIMEZONE"],
)

analytics_service = AnalyticsService(company_name=app.config["COMPANY_NAME"])


# --------------------------------------------------------------------- #
# Routes
# --------------------------------------------------------------------- #
@app.route("/", methods=["GET"])
def index():
    """Render the homepage with the legal consultation form."""
    return render_template(
        "index.html",
        legal_services=app.config["LEGAL_SERVICES"],
        today=date.today().isoformat(),
        company_name=app.config["COMPANY_NAME"],
        form_data={},
        errors={},
    )


@app.route("/submit-consultation", methods=["POST"])
def submit_consultation():
    """
    Handle the legal consultation form submission:
      1. Validate all fields server-side.
      2. On failure, re-render the form with error messages preserved.
      3. On success, save to Google Sheets and send both notification emails.
      4. Redirect to the success page.
    """
    form_data = {
    "full_name": request.form.get("full_name", "").strip(),
    "email": request.form.get("email", "").strip(),
    "phone": request.form.get("phone", "").strip(),
    "city": request.form.get("city", "").strip(),
    "contact_method": request.form.get("contact_method", "").strip(),
    "legal_service": request.form.get("legal_service", "").strip(),
    "subject": request.form.get("subject", "").strip(),
    "description": request.form.get("description", "").strip(),
    "privacy_agreement": request.form.get("privacy_agreement") == "on",}

    errors = validate_form(form_data, app.config["LEGAL_SERVICES"])

    if errors:
        flash("Please correct the errors below and try again.", "danger")
        return render_template(
            "index.html",
            legal_services=app.config["LEGAL_SERVICES"],
            today=date.today().isoformat(),
            company_name=app.config["COMPANY_NAME"],
            form_data=form_data,
            errors=errors,
        ), 400

    # --- Save to Google Sheets --------------------------------------- #
    try:
        sheets_service.append_lead(form_data)
        print("✅ GOOGLE SHEETS SUCCESS")
    except Exception as exc:  # noqa: BLE001
        print("❌ GOOGLE SHEETS ERROR:", repr(exc))
        logger.exception(exc)
        flash(f"Google Sheets Error: {exc}","warning",)

    # --- Send notification emails ------------------------------------- #
    email_errors = email_service.send_lead_emails(form_data)
    if email_errors:
        logger.warning("One or more lead emails failed to send: %s", email_errors)

    return redirect(url_for("success", name=form_data["full_name"]))


@app.route("/success", methods=["GET"])
def success():
    """Confirmation page shown after a successful submission."""
    name = request.args.get("name", "")
    return render_template(
        "success.html",
        company_name=app.config["COMPANY_NAME"],
        name=name,
    )


# --------------------------------------------------------------------- #
# NEW: "Book a Call" (Google Calendar) + Analytics routes.
# These are additive routes only - none of the routes above (index,
# submit_consultation, success) were changed in any way.
# --------------------------------------------------------------------- #
@app.route("/api/book-call", methods=["POST"])
def book_call():
    """
    Handle the new, independent "Book a Call" workflow submission.

    Unlike /submit-consultation, this is an AJAX/JSON endpoint so the
    Analytics > Book a Call modal can show a success/error state in
    place, without leaving the page or reloading it.
    """
    payload = request.get_json(silent=True) or request.form

    form_data = {
        "full_name": (payload.get("full_name") or "").strip(),
        "email": (payload.get("email") or "").strip(),
        "phone": (payload.get("phone") or "").strip(),
        "company_name": (payload.get("company_name") or "").strip(),
        "preferred_date": (payload.get("preferred_date") or "").strip(),
        "preferred_time": (payload.get("preferred_time") or "").strip(),
        "message": (payload.get("message") or "").strip(),
    }

    # --- Server-side validation (mirrors the existing form's pattern) --- #
    errors = validate_booking_form(form_data)
    if errors:
        return jsonify({"success": False, "errors": errors}), 400

    # --- Run the booking workflow: Calendar -> Sheet -> Emails --------- #
    try:
        booking = booking_service.create_booking(form_data)
    except BookingServiceError as exc:
        logger.exception(exc)
        return jsonify({"success": False, "errors": {"_general": str(exc)}}), 502

    return jsonify(
        {
            "success": True,
            "booking_id": booking["booking_id"],
            "meet_link": booking["meet_link"],
            "preferred_date": booking["preferred_date"],
            "preferred_time": booking["preferred_time"],
        }
    ), 201


@app.route("/api/analytics/event", methods=["POST"])
def analytics_event():
    """
    Lightweight endpoint used by the Analytics modal to log which
    scheduling option a visitor chose. Best-effort only: failures here
    never affect the visitor's experience.
    """
    payload = request.get_json(silent=True) or {}
    event_name = payload.get("event", "")

    logged = analytics_service.log_event(event_name, metadata=payload.get("metadata"))

    return jsonify({"logged": logged}), 200 if logged else 202


# --------------------------------------------------------------------- #
# Error handlers
# --------------------------------------------------------------------- #
@app.errorhandler(404)
def not_found(error):
    return render_template("404.html", company_name=app.config["COMPANY_NAME"]), 404


@app.errorhandler(500)
def server_error(error):
    logger.error("Internal server error: %s", error)
    return render_template("500.html", company_name=app.config["COMPANY_NAME"]), 500


# --------------------------------------------------------------------- #
# Entry point
# --------------------------------------------------------------------- #
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=app.config["DEBUG"])
