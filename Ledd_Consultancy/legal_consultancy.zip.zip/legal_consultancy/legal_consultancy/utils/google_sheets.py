"""
utils/google_sheets.py
-----------------------
Handles all communication with Google Sheets via the gspread library.

Uses a Google Service Account and opens the spreadsheet by
Spreadsheet ID (recommended) instead of spreadsheet name.
"""

import os
import logging
from datetime import datetime

import gspread
from oauth2client.service_account import ServiceAccountCredentials

logger = logging.getLogger(__name__)

SCOPES = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]


class GoogleSheetsService:
    """Google Sheets wrapper."""

    def __init__(self, credentials_file: str, sheet_id: str, headers: list):
        self.credentials_file = credentials_file
        self.sheet_id = sheet_id
        self.headers = headers
        self._client = None
        self._sheet = None

    # ------------------------------------------------------------
    # Authenticate
    # ------------------------------------------------------------
    def _authenticate(self):
        """Authenticate using the Service Account JSON file."""

        if not os.path.exists(self.credentials_file):
            raise FileNotFoundError(
                f"Credentials file not found: {self.credentials_file}"
            )

        credentials = ServiceAccountCredentials.from_json_keyfile_name(
            self.credentials_file,
            SCOPES,
        )

        return gspread.authorize(credentials)

    # ------------------------------------------------------------
    # Open Google Sheet
    # ------------------------------------------------------------
    def _get_sheet(self):

        if self._sheet is not None:
            return self._sheet

        self._client = self._authenticate()

        spreadsheet = self._client.open_by_key(self.sheet_id)

        self._sheet = spreadsheet.sheet1

        self._ensure_headers()

        return self._sheet

    # ------------------------------------------------------------
    # Ensure Header Row Exists
    # ------------------------------------------------------------
    def _ensure_headers(self):

        first_row = self._sheet.row_values(1)

        if len(first_row) == 0:
            # Brand new / empty sheet -> write the current headers.
            self._sheet.append_row(self.headers)
            logger.info("Header row created.")

        elif first_row != self.headers:
            # Sheet already has a header row (e.g. from before the form was
            # simplified, with the old "Consultation Date" column). We don't
            # want to silently reorder/overwrite a sheet that may already
            # contain data, so we just log a warning. Update row 1 manually
            # in Google Sheets (or delete it) if you want it regenerated
            # automatically to match the new column set.
            logger.warning(
                "Google Sheet header row does not match the configured "
                "SHEET_HEADERS. Expected: %s | Found: %s",
                self.headers,
                first_row,
            )

        else:
            logger.info("Header row already exists and matches.")

    # ------------------------------------------------------------
    # Append New Lead
    # ------------------------------------------------------------
    def append_lead(self, data: dict):

        sheet = self._get_sheet()

        # Order must match SHEET_HEADERS in config.py.
        row = [
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            data.get("full_name", ""),
            data.get("email", ""),
            data.get("phone", ""),
            data.get("city") or "",
            data.get("contact_method") or "No preference specified",
            data.get("legal_service", ""),
            data.get("subject", ""),
            data.get("description", ""),
        ]

        sheet.append_row(
            row,
            value_input_option="USER_ENTERED",
        )

        logger.info(
            "Lead saved successfully for %s",
            data.get("email", "Unknown"),
        )

        return True