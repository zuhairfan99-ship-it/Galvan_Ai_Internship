"""
utils/google_calendar.py
Simple Google Meet service using a fixed Meet link.
"""

import logging

logger = logging.getLogger(__name__)


class GoogleCalendarError(Exception):
    """Raised when a meeting cannot be created."""


class GoogleCalendarService:
    def __init__(
        self,
        credentials_file=None,
        calendar_id=None,
        delegated_user=None,
        default_duration_minutes=30,
        timezone="Asia/Karachi",
    ):
        self.default_duration_minutes = default_duration_minutes
        self.timezone = timezone

        # Your permanent Google Meet link
        self.meet_link = "https://meet.google.com/pmo-boqe-brt"

    def create_event(
        self,
        summary,
        description,
        start_datetime,
        customer_email,
        business_email,
        duration_minutes=None,
    ):
        """
        Simulate a successful meeting creation.

        No Google Calendar API is used.
        """

        logger.info(
            "Using fixed Google Meet link for %s",
            customer_email,
        )

        return {
            "event_id": "LOCAL-MEETING",
            "meet_link": self.meet_link,
            "html_link": self.meet_link,
            "start": start_datetime.isoformat(),
            "end": start_datetime.isoformat(),
        }