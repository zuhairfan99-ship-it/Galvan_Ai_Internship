"""
utils/validators.py
"""

import re
from datetime import datetime

from email_validator import validate_email, EmailNotValidError
import phonenumbers


# ---------------------------------------------------------
# Full Name
# ---------------------------------------------------------

NAME_REGEX = re.compile(r"^[A-Za-z ]+$")


def validate_full_name(name: str):

    if not name or not name.strip():
        return False, "Full name is required."

    name = name.strip()

    if len(name) < 3:
        return False, "Full name must be at least 3 characters."

    if not NAME_REGEX.fullmatch(name):
        return False, "Please enter a valid name using letters only."

    return True, ""


# ---------------------------------------------------------
# Email
# ---------------------------------------------------------

def validate_email_address(email: str):

    if not email or not email.strip():
        return False, "Email address is required."

    try:
        validate_email(
            email.strip(),
            check_deliverability=False
        )

    except EmailNotValidError:

        return False, "Please enter a valid email address."

    return True, ""


# ---------------------------------------------------------
# International Phone Number
# ---------------------------------------------------------


# Fallback region used ONLY when the number has no leading "+" / country
# code (e.g. "03430099556"), so that local-format numbers still validate.
# This does NOT force +92 on the input or output - numbers entered with
# their own country code (+1, +44, +92, ...) are parsed purely
# internationally and this default is never consulted for them.
DEFAULT_REGION = "PK"


def validate_phone(phone: str):

    if not phone or not phone.strip():
        return False, "Phone number is required."

    cleaned = phone.strip()

    # If the number already includes a country code (starts with "+"),
    # parse it as fully international with no default region. Otherwise,
    # assume the fallback region so local-format numbers are still valid.
    region = None if cleaned.startswith("+") else DEFAULT_REGION

    try:

        parsed = phonenumbers.parse(cleaned, region)

        if not phonenumbers.is_valid_number(parsed):

            return False, "Please enter a valid phone number."

    except phonenumbers.NumberParseException:

        return False, "Please enter a valid phone number."

    return True, ""


# ---------------------------------------------------------
# Legal Service
# ---------------------------------------------------------

def validate_legal_service(service, allowed_services):

    if not service:

        return False, "Please select a legal service."

    if service not in allowed_services:

        return False, "Invalid legal service."

    return True, ""


# ---------------------------------------------------------
# Subject
# ---------------------------------------------------------

def validate_subject(subject):

    if not subject or not subject.strip():

        return False, "Subject is required."

    return True, ""


# ---------------------------------------------------------
# Description
# ---------------------------------------------------------

def validate_description(description):

    if not description or not description.strip():

        return False, "Description is required."

    if len(description.strip()) < 20:

        return False, "Description must contain at least 20 characters."

    return True, ""


# ---------------------------------------------------------
# Privacy
# ---------------------------------------------------------

def validate_privacy_agreement(value):

    if not value:

        return False, "You must agree to the Privacy Policy."

    return True, ""


# ---------------------------------------------------------
# Main Validation
# ---------------------------------------------------------

def validate_form(form_data, allowed_services):

    errors = {}

    checks = [

        (
            "full_name",
            validate_full_name(
                form_data.get("full_name", "")
            )
        ),

        (
            "email",
            validate_email_address(
                form_data.get("email", "")
            )
        ),

        (
            "phone",
            validate_phone(
                form_data.get("phone", "")
            )
        ),

        (
            "legal_service",
            validate_legal_service(
                form_data.get("legal_service", ""),
                allowed_services
            )
        ),

        (
            "subject",
            validate_subject(
                form_data.get("subject", "")
            )
        ),

        (
            "description",
            validate_description(
                form_data.get("description", "")
            )
        ),

        (
            "privacy_agreement",
            validate_privacy_agreement(
                form_data.get("privacy_agreement")
            )
        )

    ]

    for field, (status, message) in checks:

        if not status:

            errors[field] = message

    return errors


# ===========================================================
# NEW: "Book a Call" (Google Calendar workflow) validators.
# Added below as new, standalone functions only - nothing above
# this line has been modified, so the existing Legal Consultation
# form validation is completely unaffected.
# ===========================================================

# Company name allows letters, numbers, spaces and common punctuation
# (e.g. "Smith & Co.", "ABC-123 Ltd.").
COMPANY_NAME_REGEX = re.compile(r"^[A-Za-z0-9&.,'\- ]+$")


def validate_company_name(company_name: str):
    """Company Name is optional, but if provided must be sane."""

    if not company_name or not company_name.strip():
        return True, ""

    company_name = company_name.strip()

    if len(company_name) < 2:
        return False, "Company name must be at least 2 characters."

    if len(company_name) > 150:
        return False, "Company name is too long."

    if not COMPANY_NAME_REGEX.fullmatch(company_name):
        return False, "Please enter a valid company name."

    return True, ""


def validate_preferred_date(preferred_date: str):
    """Preferred Date is required and cannot be in the past."""

    if not preferred_date or not preferred_date.strip():
        return False, "Preferred date is required."

    try:
        parsed_date = datetime.strptime(preferred_date.strip(), "%Y-%m-%d").date()
    except ValueError:
        return False, "Please enter a valid date (YYYY-MM-DD)."

    if parsed_date < datetime.now().date():
        return False, "Preferred date cannot be in the past."

    return True, ""


def validate_preferred_time(preferred_time: str):
    """Preferred Time is required and must be a valid HH:MM (24h) time."""

    if not preferred_time or not preferred_time.strip():
        return False, "Preferred time is required."

    try:
        datetime.strptime(preferred_time.strip(), "%H:%M")
    except ValueError:
        return False, "Please enter a valid time (HH:MM)."

    return True, ""


def validate_booking_message(message: str):
    """Message is optional free text describing the reason for the call."""

    if not message or not message.strip():
        return True, ""

    if len(message.strip()) > 1000:
        return False, "Message must be under 1000 characters."

    return True, ""


def validate_booking_form(form_data: dict):
    """
    Server-side validation for the new, independent "Book a Call" form.
    Mirrors the style of validate_form() above but is a fully separate
    function so the existing consultation validation is untouched.
    """

    errors = {}

    checks = [
        ("full_name", validate_full_name(form_data.get("full_name", ""))),
        ("email", validate_email_address(form_data.get("email", ""))),
        ("phone", validate_phone(form_data.get("phone", ""))),
        ("company_name", validate_company_name(form_data.get("company_name", ""))),
        ("preferred_date", validate_preferred_date(form_data.get("preferred_date", ""))),
        ("preferred_time", validate_preferred_time(form_data.get("preferred_time", ""))),
        ("message", validate_booking_message(form_data.get("message", ""))),
    ]

    for field, (status, message) in checks:
        if not status:
            errors[field] = message

    return errors