"""
utils/booking_service.py
--------------------------
NEW MODULE (added for the "Book a Call" workflow).

Orchestrates the full, independent "Book a Call" flow end-to-end:

  1. Create a Google Calendar event (with a Google Meet link) via
     utils/google_calendar.py.
  2. Persist the booking to a dedicated Google Sheets worksheet via
     utils/booking_sheets.py.
  3. Send confirmation emails (customer + business) via the existing
     utils/email_service.py (using its new, additive booking methods).
  4. Emit structured logs at every stage.

This mirrors the layering already used for the Legal Consultation flow
in app.py, but is kept in its own module/class so app.py only needs a
couple of new, thin route handlers.
"""

import logging
import uuid
from datetime import datetime

from utils.google_calendar import GoogleCalendarError

logger = logging.getLogger(__name__)


class BookingServiceError(Exception):
    """Raised when a booking cannot be completed."""


class BookingService:
    """Coordinates calendar, sheets, and email for a single booking."""

    def __init__(
        self,
        calendar_service,
        booking_sheets_service,
        email_service,
        business_owner_email: str,
        company_name: str,
        timezone: str,
    ):
        self.calendar_service = calendar_service
        self.booking_sheets_service = booking_sheets_service
        self.email_service = email_service
        self.business_owner_email = business_owner_email
        self.company_name = company_name
        self.timezone = timezone

    # ------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------
    def create_booking(self, form_data: dict) -> dict:
        """
        Run the full booking workflow for validated form data.

        Args:
            form_data: dict with keys full_name, email, phone,
                company_name, preferred_date, preferred_time, message.

        Returns:
            dict describing the completed booking (booking_id,
            calendar_event_id, meet_link, etc.) suitable for returning
            to the client as JSON.

        Raises:
            BookingServiceError: if the calendar event itself cannot be
                created (the core, non-optional part of this feature).
                Sheet/email failures are logged but do NOT raise, so a
                customer's meeting is never lost just because a
                secondary system (sheet/email) hiccuped - the same
                best-effort pattern already used for the consultation
                form in app.py.
        """
        booking_id = f"BKG-{uuid.uuid4().hex[:10].upper()}"

        logger.info(
            "Booking created (booking_id=%s, email=%s)",
            booking_id,
            form_data.get("email", "Unknown"),
        )

        # --- 1. Build the requested start datetime ------------------- #
        start_datetime = datetime.strptime(
            f"{form_data['preferred_date']} {form_data['preferred_time']}",
            "%Y-%m-%d %H:%M",
        )

        # --- 2. Create the Google Calendar event + Meet link ---------- #
        try:
            event = self.calendar_service.create_event(
                summary=f"Call with {form_data['full_name']} - {self.company_name}",
                description=(
                    f"Booking ID: {booking_id}\n"
                    f"Company: {form_data.get('company_name') or 'N/A'}\n"
                    f"Phone: {form_data.get('phone')}\n"
                    f"Message: {form_data.get('message') or 'N/A'}"
                ),
                start_datetime=start_datetime,
                customer_email=form_data["email"],
                business_email=self.business_owner_email,
            )
            logger.info("Meeting created successfully (booking_id=%s)", booking_id,)
        except Exception as exc:
            logger.error("Meeting creation failed: %s", exc)
            raise BookingServiceError("Unable to create the meeting. Please try again.")
            

        booking = {
            "booking_id": booking_id,
            "full_name": form_data["full_name"],
            "email": form_data["email"],
            "phone": form_data["phone"],
            "company_name": form_data.get("company_name", ""),
            "preferred_date": form_data["preferred_date"],
            "preferred_time": form_data["preferred_time"],
            "timezone": self.timezone,
            "message": form_data.get("message", ""),
            "calendar_event_id": event.get("event_id", ""),
            "meet_link": event.get("meet_link", ""),
            "status": "Confirmed",
        }

        # --- 3. Save to the dedicated Bookings worksheet --------------- #
        try:
            self.booking_sheets_service.append_booking(booking)
            logger.info("Google Sheet updated (booking_id=%s)", booking_id)
        except Exception as exc:  # noqa: BLE001
            logger.error(
                "Failed to save booking to Google Sheets (booking_id=%s): %s",
                booking_id,
                exc,
            )

        # --- 4. Send confirmation emails -------------------------------- #
        email_errors = self.email_service.send_booking_emails(booking)
        if email_errors:
            logger.warning(
                "One or more booking emails failed to send (booking_id=%s): %s",
                booking_id,
                email_errors,
            )
        else:
            logger.info("Emails sent (booking_id=%s)", booking_id)

        return booking
