"""
utils/analytics_service.py
----------------------------
NEW MODULE (added for the "Analytics" menu/modal feature).

The Analytics modal itself is a pure UI element (it just offers the
visitor a choice between "Schedule a Meeting" via Calendly, or
"Book a Call" via the new Google Calendar workflow) - it has no data
of its own to display. This service provides a small, reusable,
structured-logging layer so that:

  * Every time the Analytics menu is opened, and
  * Every time a visitor picks one of the two options,

...is recorded consistently in the application logs. This gives the
business owner visibility into which scheduling channel is more
popular, without requiring any new external dependency, database, or
third-party analytics platform. It is intentionally lightweight and
side-effect free beyond logging, in keeping with "add only the files
that are necessary".
"""

import logging

logger = logging.getLogger(__name__)

# Only these events are accepted, to keep the logs clean and prevent
# arbitrary/unbounded event names from client input.
ALLOWED_EVENTS = {
    "analytics_modal_opened",
    "schedule_meeting_selected",
    "book_call_selected",
    "booking_form_viewed",
}


class AnalyticsService:
    """Tiny structured-logging helper for Analytics-menu interactions."""

    def __init__(self, company_name: str = "Legal Consultancy"):
        self.company_name = company_name

    def log_event(self, event_name: str, metadata: dict = None) -> bool:
        """
        Record a single analytics event.

        Args:
            event_name: One of ALLOWED_EVENTS.
            metadata: Optional small dict of extra context (e.g. referrer).

        Returns:
            True if the event was recognized and logged, False otherwise.
        """
        metadata = metadata or {}

        if event_name not in ALLOWED_EVENTS:
            logger.warning("Ignored unrecognized analytics event: %s", event_name)
            return False

        logger.info(
            "Analytics event: %s | company=%s | metadata=%s",
            event_name,
            self.company_name,
            metadata,
        )
        return True
