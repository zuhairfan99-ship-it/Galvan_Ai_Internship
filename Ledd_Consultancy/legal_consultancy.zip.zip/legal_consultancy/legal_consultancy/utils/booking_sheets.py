"""
utils/booking_sheets.py
------------------------
NEW MODULE (added for the "Book a Call" workflow).

Persists "Book a Call" bookings to their OWN worksheet inside the same
(or a configurable) Google Spreadsheet, completely independent from the
existing consultation-lead sheet handled by utils/google_sheets.py.

The existing `GoogleSheetsService` in utils/google_sheets.py is left
100% untouched - this is a standalone class using the same gspread /
service-account pattern, but writing to a dedicated worksheet (tab)
named e.g. "Bookings" so consultation data is never mixed with, or put
at risk by, booking data.
"""

import os
import logging
from datetime import datetime

import gspread
from oauth2client.service_account import ServiceAccountCredentials

logger = logging.getLogger(__name__)

# Same scopes used by utils/google_sheets.py - kept identical for
# consistency, but declared independently so the two modules never
# share mutable state.
SCOPES = [
    "https://spreadsheets.google.com/feeds",
    "https://www.googleapis.com/auth/drive",
]


class BookingSheetsService:
    """Google Sheets wrapper for the dedicated 'Book a Call' worksheet."""

    def __init__(
        self,
        credentials_file: str,
        sheet_id: str,
        worksheet_name: str,
        headers: list,
    ):
        self.credentials_file = credentials_file
        self.sheet_id = sheet_id
        self.worksheet_name = worksheet_name
        self.headers = headers
        self._client = None
        self._worksheet = None

    # ------------------------------------------------------------
    # Authenticate
    # ------------------------------------------------------------
    def _authenticate(self):
        if not os.path.exists(self.credentials_file):
            raise FileNotFoundError(
                f"Credentials file not found: {self.credentials_file}"
            )

        credentials = ServiceAccountCredentials.from_json_keyfile_name(
            self.credentials_file,
            SCOPES,
        )

        return gspread.authorize(credentials)

    # ------------------------------------------------------------
    # Open (or create) the dedicated "Bookings" worksheet
    # ------------------------------------------------------------
    def _get_worksheet(self):
        if self._worksheet is not None:
            return self._worksheet

        self._client = self._authenticate()

        spreadsheet = self._client.open_by_key(self.sheet_id)

        try:
            self._worksheet = spreadsheet.worksheet(self.worksheet_name)
        except gspread.exceptions.WorksheetNotFound:
            # Worksheet/tab doesn't exist yet -> create it. This never
            # touches "Sheet1" (the existing consultation worksheet).
            self._worksheet = spreadsheet.add_worksheet(
                title=self.worksheet_name,
                rows=1000,
                cols=max(len(self.headers), 10),
            )
            logger.info("Created new worksheet tab: %s", self.worksheet_name)

        self._ensure_headers()

        return self._worksheet

    # ------------------------------------------------------------
    # Ensure Header Row Exists
    # ------------------------------------------------------------
    def _ensure_headers(self):
        first_row = self._worksheet.row_values(1)

        if len(first_row) == 0:
            self._worksheet.append_row(self.headers)
            logger.info("Booking sheet header row created.")
        elif first_row != self.headers:
            logger.warning(
                "Booking worksheet header row does not match the configured "
                "BOOKING_SHEET_HEADERS. Expected: %s | Found: %s",
                self.headers,
                first_row,
            )
        else:
            logger.info("Booking sheet header row already exists and matches.")

    # ------------------------------------------------------------
    # Append New Booking
    # ------------------------------------------------------------
    def append_booking(self, booking: dict):
        """
        Append a single "Book a Call" booking row.

        Expected keys in `booking`:
            booking_id, full_name, email, phone, company_name,
            preferred_date, preferred_time, timezone,
            calendar_event_id, meet_link, status
        """
        worksheet = self._get_worksheet()

        row = [
            booking.get("booking_id", ""),
            booking.get("full_name", ""),
            booking.get("email", ""),
            booking.get("phone", ""),
            booking.get("company_name", ""),
            booking.get("preferred_date", ""),
            booking.get("preferred_time", ""),
            booking.get("timezone", ""),
            booking.get("calendar_event_id", ""),
            booking.get("meet_link", ""),
            booking.get("status", "Confirmed"),
            datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        ]

        worksheet.append_row(row, value_input_option="USER_ENTERED")

        logger.info(
            "Booking saved successfully for %s (booking_id=%s)",
            booking.get("email", "Unknown"),
            booking.get("booking_id", "Unknown"),
        )

        return True
