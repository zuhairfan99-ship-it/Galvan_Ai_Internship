"""
utils/email_service.py
-----------------------
Handles outgoing email notifications via SMTP (designed for Gmail
with an App Password, but works with any standard SMTP server).

Sends two emails per submission:
  1. Business owner notification  -> templates/emails/business_notification.html
  2. Customer confirmation        -> templates/emails/customer_confirmation.html

Both templates are rendered with Flask/Jinja's render_template so they
can share the same templating engine as the rest of the site.
"""

import smtplib
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from flask import render_template

logger = logging.getLogger(__name__)


class EmailService:
    """Small wrapper around smtplib for sending the two lead-notification emails."""

    def __init__(self, smtp_server, smtp_port, smtp_email, smtp_password,
                 business_owner_email, company_name):
        self.smtp_server = smtp_server
        self.smtp_port = smtp_port
        self.smtp_email = smtp_email
        self.smtp_password = smtp_password
        self.business_owner_email = business_owner_email
        self.company_name = company_name

    # ------------------------------------------------------------------ #
    # Low-level send helper
    # ------------------------------------------------------------------ #
    def _send(self, to_address: str, subject: str, html_body: str):
        if not self.smtp_email or not self.smtp_password:
            raise RuntimeError(
                "SMTP credentials are not configured. Set SMTP_EMAIL and "
                "SMTP_PASSWORD in your .env file (see README.md)."
            )

        message = MIMEMultipart("alternative")
        message["Subject"] = subject
        message["From"] = f"{self.company_name} <{self.smtp_email}>"
        message["To"] = to_address

        message.attach(MIMEText(html_body, "html"))

        with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
            server.starttls()
            server.login(self.smtp_email, self.smtp_password)
            server.sendmail(self.smtp_email, to_address, message.as_string())

        logger.info("Email '%s' sent to %s", subject, to_address)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #
    def send_business_notification(self, lead: dict):
        """Notify the business owner that a new lead has come in."""
        html_body = render_template(
            "emails/business_notification.html",
            lead=lead,
            company_name=self.company_name,
        )
        self._send(
            to_address=self.business_owner_email,
            subject="New Legal Consultation Lead Received",
            html_body=html_body,
        )

    def send_customer_confirmation(self, lead: dict):
        """Send the customer a professional confirmation email."""
        html_body = render_template(
            "emails/customer_confirmation.html",
            lead=lead,
            company_name=self.company_name,
        )
        self._send(
            to_address=lead.get("email"),
            subject="Thank You for Contacting Our Legal Consultancy",
            html_body=html_body,
        )

    def send_lead_emails(self, lead: dict):
        """
        Convenience method that sends both emails.
        Each send is wrapped independently so a failure in one
        does not prevent the other from being attempted.
        """
        errors = []

        try:
            self.send_business_notification(lead)
        except Exception as exc:  # noqa: BLE001 - we want to log & continue
            logger.error("Failed to send business notification email: %s", exc)
            errors.append(str(exc))

        try:
            self.send_customer_confirmation(lead)
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to send customer confirmation email: %s", exc)
            errors.append(str(exc))

        return errors

    # ------------------------------------------------------------------ #
    # NEW: "Book a Call" (Google Calendar) workflow emails.
    # Added as new methods only - none of the methods above were changed.
    # ------------------------------------------------------------------ #
    def send_booking_business_notification(self, booking: dict):
        """Notify the business team that a new call has been booked."""
        html_body = render_template(
            "emails/booking_business_notification.html",
            booking=booking,
            company_name=self.company_name,
        )
        self._send(
            to_address=self.business_owner_email,
            subject="New Call Booking Received",
            html_body=html_body,
        )

    def send_booking_customer_confirmation(self, booking: dict):
        """Send the customer a confirmation email with their Meet link."""
        html_body = render_template(
            "emails/booking_customer_confirmation.html",
            booking=booking,
            company_name=self.company_name,
        )
        self._send(
            to_address=booking.get("email"),
            subject="Your Call Has Been Scheduled",
            html_body=html_body,
        )

    def send_booking_emails(self, booking: dict):
        """
        Convenience method that sends both booking-related emails.
        Mirrors send_lead_emails(): each send is independent so a
        failure in one does not prevent the other from being attempted.
        """
        errors = []

        try:
            self.send_booking_business_notification(booking)
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to send booking business notification email: %s", exc)
            errors.append(str(exc))

        try:
            self.send_booking_customer_confirmation(booking)
        except Exception as exc:  # noqa: BLE001
            logger.error("Failed to send booking customer confirmation email: %s", exc)
            errors.append(str(exc))

        return errors
