// Vercel serverless entry point — wraps the existing Express app.
// Vercel's Node runtime calls this exported handler per-request instead
// of the app listening on a port itself.
module.exports = require('../server.js');
