# Gravity Shift

A browser-based platformer with a server-side, database-backed Top 10 leaderboard.
Players register a **player name** and **company name** before playing; every
completed game is saved to a shared database so the leaderboard and CSV export
are consistent across every visitor and every serverless instance.

## What's in this project

- `index.html`, `style.css`, `game.js` — the game itself (registration screen,
  canvas gameplay, HUD, leaderboard panel).
- `server.js` — the Express app: static file serving + JSON API routes.
- `api/index.js` — the Vercel serverless entry point; it just re-exports the
  same Express app from `server.js` so Vercel can call it per-request.
- `db.js` — the database layer (Turso / libSQL, with a local SQLite fallback
  for development).
- `vercel.json` — routes `/api/*` to the serverless function; everything else
  is served as a static file by Vercel.

## How the game works now

1. On load, the player must enter **Player Name** and **Company Name** —
   both are required before the game will start.
2. Names are validated both in the browser and again on the server
   (`POST /api/validate-name` and `POST /api/games`) before anything is saved.
3. Every completed game is saved server-side via `POST /api/games` with:
   `id, player_name, company_name, score, timestamp` (plus a few optional
   gameplay fields such as level and control method).
4. The **Leaderboard** panel shows the Top 10 games, sorted by highest score
   first, then by newest timestamp to break ties.
5. The **Export CSV** button (top toolbar) downloads every played game as a
   CSV with columns `timestamp, player_name, company_name, score` — no login
   required.

There is no admin login anywhere in this build. The previous admin dashboard
(`admin.html`) and its Basic Auth–protected routes have been removed; nothing
else in the game depended on them, so gameplay, styling, and layout are
unchanged.

## Database

Score data is stored in a `game_records` table (Turso / libSQL, which is
SQLite-compatible):

- **Production (Vercel):** set `TURSO_DATABASE_URL` and `TURSO_AUTH_TOKEN` so
  every serverless invocation reads and writes the same hosted database. This
  is required — Vercel's filesystem is not persistent or shared between
  invocations, so without Turso the leaderboard would not survive a cold
  start.
- **Local development:** if `TURSO_DATABASE_URL` is not set, the app
  automatically falls back to a local SQLite file at `./data/leaderboard.db`
  (configurable via `DB_PATH`). No Turso account is needed to develop
  locally.

The table is created automatically on first request — there is no separate
migration step.

### Setting up Turso

```bash
curl -sSfL https://get.tur.so/install.sh | bash
turso auth login
turso db create gravity-shift
turso db show gravity-shift --url
turso db tokens create gravity-shift
```

Use the URL and token from the last two commands as `TURSO_DATABASE_URL` and
`TURSO_AUTH_TOKEN`.

## Environment variables

See `.env.example`. Copy it to `.env` for local development:

| Variable              | Required          | Purpose                                                   |
|------------------------|--------------------|-------------------------------------------------------------|
| `PORT`                 | No (local only)   | Port for `npm start` locally. Defaults to `3000`.           |
| `TURSO_DATABASE_URL`   | Yes, in production | Hosted database URL (`libsql://...`).                       |
| `TURSO_AUTH_TOKEN`     | Yes, in production | Auth token for the Turso database.                          |
| `DB_PATH`              | No                 | Local SQLite file path, used only when Turso is not set.    |

Never commit a real `.env` file — `.gitignore`/`.vercelignore` already exclude
it. Set the two `TURSO_*` variables in the Vercel dashboard (Project →
Settings → Environment Variables) instead.

## Local development

```bash
npm install
cp .env.example .env
npm start
```

Then open the local URL printed in the terminal. Leave `TURSO_DATABASE_URL`
blank in `.env` to use the local SQLite fallback, or fill it in to develop
against a real Turso database.

`npm run dev` restarts the server automatically on file changes (uses
Node's built-in `--watch`).

## Deploying to Vercel

**Option A — CLI**
```bash
npm install -g vercel
vercel login
vercel            # deploy a preview
vercel --prod     # promote to production
```

**Option B — GitHub + Vercel dashboard**
1. Push this project to a new GitHub repository.
2. In Vercel: **Add New Project** → import that repository.
3. Framework preset: **Other**. Leave the build command blank — this is
   plain Node/Express with no bundler.
4. Before the first deploy (or after, then redeploy), set
   `TURSO_DATABASE_URL` and `TURSO_AUTH_TOKEN` in Project → Settings →
   Environment Variables.
5. Deploy.

`vercel.json` routes `/api/*` to the serverless function in `api/index.js`;
every other path is served as a static file directly by Vercel, so the CSS
and JS load normally instead of being swallowed by the function.

### Verifying after deploy

- `https://<your-app>.vercel.app/` — the game should load, styled, and ask
  for a player name and company name before it starts.
- `https://<your-app>.vercel.app/api/health` — should return
  `{"ok":true,"status":"online"}`.
- Play a level and submit a score, then open the Leaderboard panel — it
  should appear there (and persist across future visits/cold starts, since
  it's stored in Turso rather than in memory).
- Click **Export CSV** — it should download a CSV of every game played so
  far.

## API reference

| Method | Route                | Description                                                        |
|--------|-----------------------|----------------------------------------------------------------------|
| GET    | `/api/health`         | Health check.                                                       |
| POST   | `/api/validate-name`  | Validates `{ player_name, company_name }` before the game starts.   |
| GET    | `/api/leaderboard/top10` | Top 10 games by score (desc), newest timestamp breaks ties.      |
| POST   | `/api/games`          | Saves a completed game. Validates player/company name and score server-side. |
| GET    | `/api/export/csv`     | Downloads all played games as CSV (`timestamp,player_name,company_name,score`). |

## Notes

- The game never relies on `localStorage` or the local filesystem for shared
  data — all scoring data goes through the API to the database, which is
  what makes it work correctly across multiple serverless instances on
  Vercel.
- `sessionStorage` is only used client-side to remember the player's own
  name/company between page reloads in the same browser tab; it is never the
  source of truth for the leaderboard.
