const fs = require('fs');
const path = require('path');
const { createClient } = require('@libsql/client');

// --- Connection -----------------------------------------------------------
//
// Uses Turso (hosted libSQL, SQLite-compatible) when TURSO_DATABASE_URL is
// set — this is what you want in production (Vercel), since it's a real
// network database that persists across cold starts and is shared by every
// serverless instance.
//
// When TURSO_DATABASE_URL is NOT set, it falls back to a local SQLite file
// on disk, so local development needs no Turso account at all. On a
// serverless filesystem (Vercel) that local file lives in /tmp, which is
// fine for quick testing but is NOT persistent — see DEPLOYMENT.md.
const isServerless = Boolean(process.env.VERCEL || process.env.AWS_LAMBDA_FUNCTION_NAME);
const usingTurso = Boolean(process.env.TURSO_DATABASE_URL);

let localFileUrl = null;
if (!usingTurso) {
  const dbDir = isServerless ? '/tmp' : path.join(__dirname, 'data');
  fs.mkdirSync(dbDir, { recursive: true });
  const dbPath = process.env.DB_PATH ? path.resolve(process.env.DB_PATH) : path.join(dbDir, 'leaderboard.db');
  localFileUrl = `file:${dbPath}`;

  if (isServerless) {
    console.warn('[gravity-shift] No TURSO_DATABASE_URL set — falling back to /tmp on a serverless filesystem. Leaderboard data will NOT persist across cold starts. Set TURSO_DATABASE_URL and TURSO_AUTH_TOKEN for a real deployment (see DEPLOYMENT.md).');
  }
}

const db = createClient(
  usingTurso
    ? { url: process.env.TURSO_DATABASE_URL, authToken: process.env.TURSO_AUTH_TOKEN }
    : { url: localFileUrl }
);

function sanitizeString(value, fallback = '') {
  if (value === undefined || value === null) return fallback;
  return String(value).replace(/[\u0000-\u001F\u007F]/g, '').trim();
}

const MAX_NAME_LENGTH = 80;

function normalizeParticipantName(input) {
  // Preferred path: structured { company_name, player_name } — this is what
  // the registration screen and the game UI send. Each field is validated
  // independently so a hyphen inside either name can never cause a mix-up.
  if (input && typeof input === 'object') {
    const companyName = sanitizeString(input.company_name, '').slice(0, MAX_NAME_LENGTH);
    const playerName = sanitizeString(input.player_name, '').slice(0, MAX_NAME_LENGTH);

    if (!companyName || !playerName) {
      throw new Error('Both player name and company name are required.');
    }

    return {
      company_name: companyName,
      player_name: playerName,
      display_name: `${companyName} - ${playerName}`
    };
  }

  // Legacy fallback: a single "Company Name - Player Name" string.
  const text = sanitizeString(input, '');
  if (!text) {
    throw new Error('Player name and company name are required.');
  }

  const normalized = text
    .replace(/\s*[-–—]\s*/g, ' - ')
    .replace(/\s+/g, ' ')
    .trim();

  const parts = normalized.split(' - ');
  if (parts.length !== 2) {
    throw new Error('Name must use the format: Company Name - Player Name');
  }

  const companyName = sanitizeString(parts[0], '').slice(0, MAX_NAME_LENGTH);
  const playerName = sanitizeString(parts[1], '').slice(0, MAX_NAME_LENGTH);

  if (!companyName || !playerName) {
    throw new Error('Both player name and company name are required.');
  }

  return {
    company_name: companyName,
    player_name: playerName,
    display_name: `${companyName} - ${playerName}`
  };
}

// --- Schema -----------------------------------------------------------

let readyPromise = null;

function ensureReady() {
  if (!readyPromise) {
    readyPromise = (async () => {
      await db.execute(`
        CREATE TABLE IF NOT EXISTS game_records (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          game_id TEXT NOT NULL UNIQUE,
          company_name TEXT NOT NULL,
          player_name TEXT NOT NULL,
          display_name TEXT NOT NULL,
          level_number INTEGER NOT NULL DEFAULT 1,
          score INTEGER NOT NULL,
          completion_time_ms INTEGER NOT NULL DEFAULT 0,
          timestamp TEXT NOT NULL,
          game_start_time TEXT,
          game_end_time TEXT,
          duration INTEGER,
          control_method TEXT,
          session_id TEXT,
          device_id TEXT,
          external_controller_used INTEGER DEFAULT 0,
          connection_status TEXT,
          reached_stage TEXT,
          combo INTEGER DEFAULT 0,
          mistakes INTEGER DEFAULT 0,
          game_version TEXT,
          created_at TEXT NOT NULL,
          idempotency_key TEXT UNIQUE
        );
      `);

      await db.execute('CREATE INDEX IF NOT EXISTS idx_game_records_score ON game_records(score DESC);');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_game_records_timestamp ON game_records(timestamp);');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_game_records_company ON game_records(company_name);');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_game_records_player ON game_records(player_name);');
      await db.execute('CREATE INDEX IF NOT EXISTS idx_game_records_game_id ON game_records(game_id);');

      // Leaderboard reset cycle:
      // Keep every game record for CSV/history, but only show records from
      // the current 10-lead leaderboard cycle. The first deployment of this
      // version starts a fresh cycle automatically.
      await db.execute(`
        CREATE TABLE IF NOT EXISTS leaderboard_state (
          id INTEGER PRIMARY KEY CHECK (id = 1),
          submission_count INTEGER NOT NULL DEFAULT 0,
          batch_started_at TEXT NOT NULL
        );
      `);

      await db.execute({
        sql: `
          INSERT OR IGNORE INTO leaderboard_state (id, submission_count, batch_started_at)
          VALUES (1, 0, ?)
        `,
        args: [new Date().toISOString()]
      });
    })();
  }
  return readyPromise;
}

async function recordLeaderboardSubmission() {
  await ensureReady();

  // Count each completed score submission as one lead. When the 10th lead
  // is submitted, immediately start a fresh leaderboard cycle. Historical
  // game_records are intentionally NOT deleted.
  const resetTime = new Date().toISOString();

  await db.execute({
    sql: `
      UPDATE leaderboard_state
      SET
        submission_count = CASE
          WHEN submission_count >= 9 THEN 0
          ELSE submission_count + 1
        END,
        batch_started_at = CASE
          WHEN submission_count >= 9 THEN ?
          ELSE batch_started_at
        END
      WHERE id = 1
    `,
    args: [resetTime]
  });
}

async function getLeaderboardBatchStart() {
  await ensureReady();
  const result = await db.execute(
    'SELECT batch_started_at FROM leaderboard_state WHERE id = 1 LIMIT 1'
  );
  return result.rows[0]?.batch_started_at || new Date(0).toISOString();
}

async function generateGameId() {
  await ensureReady();
  const result = await db.execute(
    "SELECT COALESCE(MAX(CAST(SUBSTR(game_id, 6) AS INTEGER)), 0) AS max_id FROM game_records"
  );
  const nextNumber = Number(result.rows[0]?.max_id || 0) + 1;
  return `GAME-${String(nextNumber).padStart(6, '0')}`;
}

function buildRecord(record, gameId) {
  const nowIso = new Date().toISOString();
  const { company_name, player_name, display_name } = normalizeParticipantName(
    record.company_name && record.player_name
      ? { company_name: record.company_name, player_name: record.player_name }
      : record.participant || `${record.company_name || ''} - ${record.player_name || ''}`
  );

  const score = Number(record.score || 0);
  const levelNumber = Number(record.level_number || record.level || 1);
  const completionTimeMs = Number(record.completion_time_ms || 0);
  const controlMethod = sanitizeString(record.control_method || 'Backup', 'Backup');
  const idempotencyKey = sanitizeString(record.idempotency_key || record.session_id || '', '');
  const timestamp = sanitizeString(record.timestamp || nowIso, nowIso);
  const startTime = sanitizeString(record.game_start_time || '', '');
  const endTime = sanitizeString(record.game_end_time || '', '');
  const duration = Number(record.duration || completionTimeMs || 0);
  const sessionId = sanitizeString(record.session_id || '', '');
  const deviceId = sanitizeString(record.device_id || '', '');
  const externalControllerUsed = Number(record.external_controller_used || 0);
  const connectionStatus = sanitizeString(record.connection_status || 'unknown', 'unknown');
  const reachedStage = sanitizeString(record.reached_stage || '', '');
  const combo = Number(record.combo || 0);
  const mistakes = Number(record.mistakes || 0);
  const gameVersion = sanitizeString(record.game_version || '1.0.0', '1.0.0');

  if (!Number.isFinite(score) || score < 0) {
    throw new Error('Score must be a non-negative number.');
  }

  return {
    game_id: sanitizeString(record.game_id || '', '') || gameId,
    company_name: company_name || sanitizeString(record.company_name, ''),
    player_name: player_name || sanitizeString(record.player_name, ''),
    display_name: display_name || sanitizeString(record.display_name, ''),
    level_number: Number.isFinite(levelNumber) && levelNumber > 0 ? Math.floor(levelNumber) : 1,
    score,
    completion_time_ms: Number.isFinite(completionTimeMs) && completionTimeMs >= 0 ? Math.floor(completionTimeMs) : 0,
    timestamp,
    game_start_time: startTime,
    game_end_time: endTime,
    duration,
    control_method: controlMethod,
    session_id: sessionId,
    device_id: deviceId,
    external_controller_used: externalControllerUsed,
    connection_status: connectionStatus,
    reached_stage: reachedStage,
    combo,
    mistakes,
    game_version: gameVersion,
    created_at: nowIso,
    idempotency_key: idempotencyKey
  };
}

async function saveGameRecord(record) {
  await ensureReady();

  const idempotencyKey = sanitizeString(record.idempotency_key || record.session_id || '', '');
  if (idempotencyKey) {
    const existing = await db.execute({
      sql: 'SELECT * FROM game_records WHERE idempotency_key = ? LIMIT 1',
      args: [idempotencyKey]
    });
    if (existing.rows.length) {
      return existing.rows[0];
    }
  }

  const gameId = record.game_id ? sanitizeString(record.game_id) : await generateGameId();
  const prepared = buildRecord(record, gameId);

  await db.execute({
    sql: `
      INSERT INTO game_records (
        game_id, company_name, player_name, display_name, level_number, score, completion_time_ms, timestamp, game_start_time,
        game_end_time, duration, control_method, session_id, device_id, external_controller_used,
        connection_status, reached_stage, combo, mistakes, game_version, created_at, idempotency_key
      ) VALUES (
        :game_id, :company_name, :player_name, :display_name, :level_number, :score, :completion_time_ms, :timestamp, :game_start_time,
        :game_end_time, :duration, :control_method, :session_id, :device_id, :external_controller_used,
        :connection_status, :reached_stage, :combo, :mistakes, :game_version, :created_at, :idempotency_key
      )
    `,
    args: prepared
  });

  // Advance the 10-lead leaderboard cycle only after the score is saved.
  await recordLeaderboardSubmission();

  return prepared;
}

// Top 10 leaderboard: highest score first, newest submission breaks ties.
async function getTopRecords(limit = 10) {
  const batchStartedAt = await getLeaderboardBatchStart();

  const result = await db.execute({
    sql: `
      SELECT * FROM game_records
      WHERE created_at >= ?
      ORDER BY score DESC, timestamp DESC, created_at DESC
      LIMIT ?
    `,
    args: [batchStartedAt, Number(limit)]
  });

  return result.rows.map((row, index) => ({
    rank: index + 1,
    ...row
  }));
}

// Every played game, newest first — this is the source for the CSV export.
async function getAllRecords() {
  await ensureReady();
  const result = await db.execute(`
    SELECT * FROM game_records
    ORDER BY timestamp DESC, created_at DESC
  `);
  return result.rows;
}

function escapeCsvValue(value) {
  const safeValue = value === null || value === undefined ? '' : String(value);
  if (safeValue.includes(',') || safeValue.includes('"') || safeValue.includes('\n')) {
    return `"${safeValue.replace(/"/g, '""')}"`;
  }
  return safeValue;
}

// CSV export of every played game: timestamp, player_name, company_name, score.
async function exportGamesCsv() {
  const rows = await getAllRecords();

  const header = ['timestamp', 'player_name', 'company_name', 'score'];
  const csvRows = [header.join(',')];

  rows.forEach((row) => {
    csvRows.push([
      row.timestamp,
      row.player_name,
      row.company_name,
      row.score
    ].map(escapeCsvValue).join(','));
  });

  return csvRows.join('\n');
}

module.exports = {
  db,
  usingTurso,
  sanitizeString,
  normalizeParticipantName,
  generateGameId,
  saveGameRecord,
  getTopRecords,
  getAllRecords,
  exportGamesCsv
};
