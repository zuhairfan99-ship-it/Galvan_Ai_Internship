require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const {
  normalizeParticipantName,
  saveGameRecord,
  getTopRecords,
  exportGamesCsv
} = require('./db');

const app = express();
const port = Number(process.env.PORT || 3000);
const ROOT = __dirname;

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static(ROOT));

app.get('/api/health', (req, res) => {
  res.json({ ok: true, status: 'online' });
});

// Validates a player/company name pair before the game is allowed to start.
// Accepts the structured { player_name, company_name } shape sent by the
// registration screen, and — for backward compatibility — a single
// "Company Name - Player Name" string.
app.post('/api/validate-name', (req, res) => {
  try {
    const body = req.body || {};
    const value = (body.company_name || body.player_name)
      ? { company_name: body.company_name, player_name: body.player_name }
      : (body.participant || body.display_name || body.name || '');

    const parsed = normalizeParticipantName(value);
    res.json({
      valid: true,
      company_name: parsed.company_name,
      player_name: parsed.player_name,
      display_name: parsed.display_name
    });
  } catch (error) {
    res.status(400).json({ valid: false, error: error.message });
  }
});

// Global Top 10 leaderboard: highest score first, newest timestamp breaks ties.
app.get('/api/leaderboard/top10', async (req, res) => {
  try {
    const rows = await getTopRecords(10);
    res.json({
      leaderboard: rows,
      total: rows.length
    });
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to load leaderboard.' });
  }
});

app.post('/api/games', async (req, res) => {
  try {
    const payload = req.body || {};

    const companyName = String(payload.company_name || '').trim();
    const playerName = String(payload.player_name || '').trim();
    if (!companyName || !playerName) {
      return res.status(400).json({ error: 'Player name and company name are required.' });
    }

    const score = Number(payload.score);
    if (!Number.isFinite(score) || score < 0) {
      return res.status(400).json({ error: 'Score must be a non-negative number.' });
    }

    const record = await saveGameRecord({
      ...payload,
      company_name: companyName,
      player_name: playerName,
      score,
      level_number: Number(payload.level_number || payload.level || 1),
      completion_time_ms: Number(payload.completion_time_ms || 0),
      timestamp: new Date().toISOString(),
      control_method: payload.control_method || 'Backup',
      session_id: payload.session_id || `session-${Date.now()}`,
      idempotency_key: payload.idempotency_key || payload.session_id || `game-${Date.now()}-${Math.random().toString(16).slice(2)}`
    });

    res.status(201).json({
      message: 'Game score saved successfully.',
      record
    });
  } catch (error) {
    res.status(400).json({ error: error.message || 'Unable to record game.' });
  }
});

// Public CSV export of every played game: timestamp, player_name, company_name, score.
app.get('/api/export/csv', async (req, res) => {
  try {
    const csv = await exportGamesCsv();
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="gravity-shift-games.csv"');
    res.send(csv);
  } catch (error) {
    res.status(500).json({ error: error.message || 'Unable to export games.' });
  }
});

app.get('*', (req, res) => {
  const indexPath = path.join(ROOT, 'index.html');
  res.sendFile(indexPath);
});

// Only bind a port when run directly (local dev / a normal Node host).
// On Vercel, this file is imported as a serverless function handler via
// api/index.js instead, and app.listen() must NOT be called there.
if (require.main === module) {
  app.listen(port, () => {
    console.log(`Gravity Shift server listening on http://localhost:${port}`);
  });
}

module.exports = app;
