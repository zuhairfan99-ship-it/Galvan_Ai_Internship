const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const debugText = document.getElementById('debugText');
const loadingOverlay = document.getElementById('loadingOverlay');
const fullscreenButton = document.getElementById('fullscreenButton');
const levelCompleteModal = document.getElementById('levelCompleteModal');
const levelResultTitle = document.getElementById('levelResultTitle');
const levelResultMessage = document.getElementById('levelResultMessage');
const replayLevelBtn = document.getElementById('replayLevelBtn');
const nextLevelBtn = document.getElementById('nextLevelBtn');
const leaderboardPanel = document.getElementById('leaderboardPanel');
const leaderboardList = document.getElementById('leaderboardList');
const registrationScreen = document.getElementById('registrationScreen');
const registrationPlayerInput = document.getElementById('registrationPlayerInput');
const registrationCompanyInput = document.getElementById('registrationCompanyInput');
const startGameBtn = document.getElementById('startGameBtn');
const registrationError = document.getElementById('registrationError');
const gameShell = document.getElementById('gameShell');
const instructionsScreen = document.getElementById('instructionsScreen');
const beginPlayBtn = document.getElementById('beginPlayBtn');

// Tracks whether gameplay has actually begun yet, so the instructions
// overlay knows whether reopening it (via the header button) should just
// close again, versus kicking off level 1 for the first time.
let gameStarted = false;

const TOTAL_LEVELS = 100;

// Set once registration succeeds; used for every score submission so the
// player never has to re-enter their identity mid-game.
let registeredPlayer = { player_name: '', company_name: '', display_name: '' };

function buildLevel(levelNumber) {
  const sectorNames = [
    'Broken Gravity Lab', 'Laser Research Room', 'Flux Relay Vault', 'Neon Drift Hall',
    'Magnet Tunnel', 'Orbital Lift', 'Solar Anomaly', 'Echo Core', 'Signal Breaker',
    'Zero-G Foundry', 'Prism Chamber', 'Violet Pulse', 'Crystal Nursery', 'Gravity Fork',
    'Trajectory Gate', 'Helix Basin', 'Comet Lattice', 'Aether Forge', 'Ion Lattice',
    'Nova Rift', 'Cipher Room', 'Cyclone Array', 'Xenon Lift', 'Photon Maze', 'Steel Orbit',
    'Sable Vault', 'Kinetic Loop', 'Quantum Steps', 'Sunken Relay', 'Pulse Alley',
    'Mirage Dock', 'Starline Lab', 'Arc Reactor', 'Fission Hall', 'Delta Drift', 'Horizon Glass',
    'Titan Coil', 'Ember Corridor', 'Zenith Lab', 'Polar Shift', 'Abyss Relay', 'Orbit Testbed',
    'Cinder Circuit', 'Velocity Gate', 'Moonwell Chamber', 'Drift Station', 'Gravity Hearth',
    'Spectra Lift', 'Null Harbor', 'Radiant Loop', 'Vector Yard', 'Mantis Room', 'Skyline Array',
    'Blackwater Coil', 'Kindred Lab', 'Phase Tunnel', 'Hammer Vault', 'Deep Echo', 'Elemental Ring',
    'Perpetual Engine', 'Neutrino Yard', 'Starlight Cube', 'Glacier Run', 'Luminous Hall',
    'Cold Current', 'Shatter Bay', 'Night Shift', 'Atlas Lift', 'Prism Drive', 'Shadow Well',
    'Resonance Gate', 'Storm Engine', 'Quartz Run', 'Pulse Harbor', 'Gravity Bloom', 'Silver Rift',
    'Afterglow Lab', 'Runic Lift', 'Inferno Dock', 'Temple of Shift', 'Rogue Circuit', 'Solar Wells',
    'Crimson Loop', 'Nimbus Field', 'Tidal Relay', 'Echoing Core', 'Iron Bloom', 'Aurora Gate',
    'Bastion Run', 'Drift Prism', 'Kite Vault', 'High Voltage', 'Starlit Drift', 'Alpha Pulse',
    'Blackout Lab', 'Torque Valley', 'Frost Valve', 'Comet Gate', 'Quantum Bloom', 'Flux Harbor',
    'Mosaic Relay', 'Gravity Furnace', 'Blue Plasma', 'Voltage Vault', 'Cobalt Drift', 'Halo Circuit'
  ];

  const levelLabel = sectorNames[(levelNumber - 1) % sectorNames.length];
  const allowedGravity = levelNumber <= 10
    ? ['DOWN', 'UP']
    : levelNumber <= 35
      ? ['DOWN', 'UP', 'LEFT']
      : ['DOWN', 'UP', 'LEFT', 'RIGHT'];

  const platforms = [{ x: 0, y: 560, w: 1024, h: 80 }];
  const crystalCount = 2 + Math.min(4, Math.floor((levelNumber - 1) / 18));

  for (let i = 0; i < 4 + Math.min(6, Math.floor(levelNumber / 12)); i += 1) {
    const slope = (levelNumber * 17 + i * 31) % 120;
    const x = 100 + i * (150 + ((levelNumber * 21 + i * 41) % 70));
    const y = 520 - (i * 52) - (levelNumber % 5) * 8 - (i % 2) * 25 - (slope % 30) * 0.4;
    const w = 120 + ((levelNumber + i * 9) % 70);
    if (x + w < 980) {
      platforms.push({ x, y, w, h: 18 });
    }
  }

  const goalX = clamp(860 - ((levelNumber * 7) % 120), 760, 930);
  const goalY = Math.max(120, 150 - ((levelNumber - 1) % 6) * 8);

  const crystals = [];
  for (let i = 0; i < crystalCount; i += 1) {
    const px = platforms[(i % (platforms.length - 1)) + 1];
    const x = clamp((px.x + px.w / 2) + ((i % 2 === 0 ? -1 : 1) * 40) + (levelNumber % 7) * 2, 120, 900);
    const y = clamp(px.y - 28 - (i % 3) * 12, 80, 520);
    crystals.push({ x, y });
  }

  // Hazards are mounted on whichever "wall" the player gets pressed against
  // for a given gravity direction (the ground for DOWN, the ceiling for UP,
  // and the side walls for LEFT/RIGHT). A level only gets hazards on walls
  // its gravity can actually reach, so the danger is always tactically
  // placed where the player will be. More hazards spawn dynamically over
  // time on the player's *current* wall as the level is played (see
  // spawnDynamicHazard / updateGameLoop).
  const hazards = [];
  const wallSpan = { DOWN: 1024, UP: 1024, LEFT: 640, RIGHT: 640 };

  ['DOWN', 'UP', 'LEFT', 'RIGHT'].forEach((wall, wallIndex) => {
    if (!allowedGravity.includes(wall)) return;

    const baseCount = wall === 'DOWN'
      ? 1 + Math.floor((levelNumber - 1) / 6)
      : 1 + Math.floor((levelNumber - 1) / 12);
    const count = Math.min(4, baseCount);
    const span = wallSpan[wall];

    for (let i = 0; i < count; i += 1) {
      const length = 90 + ((levelNumber + i * 13 + wallIndex * 5) % 70);
      const usable = Math.max(1, span - length - 240);
      const pos = clamp(180 + ((levelNumber * 53 + i * 97 + wallIndex * 211) % usable), 0, span - length);
      hazards.push({ wall, pos, length, thickness: 20 });
    }
  });

  return {
    id: levelNumber,
    name: `${levelLabel} ${levelNumber}`,
    allowedGravity,
    playerStart: { x: 70, y: 500 },
    goal: { x: goalX, y: goalY, r: 22 + (levelNumber % 3) },
    crystals,
    platforms,
    hazards
  };
}

const levelData = Array.from({ length: TOTAL_LEVELS }, (_, index) => buildLevel(index + 1));

const controls = {
  left: false,
  right: false,
  jump: false
};

const game = {
  currentLevel: 0,
  highestUnlockedLevel: 1,
  gravity: 'DOWN',
  score: 0,
  crystals: 0,
  totalCrystals: 2,
  lives: 3,
  shiftTimer: 4,
  shiftInterval: 4,
  won: false,
  gameOver: false,
  dying: false,
  deathBlinkTimer: 0,
  hitFlashTimer: 0,
  externalControllerConnected: true,
  controlMode: 'External Controller Connected',
  player: null,
  intervalId: null,
  levelStartTime: 0,
  levelCompletionMs: 0,
  levelStartScore: 0,
  hazardSpawnTimer: 0,
  hazardSpawnInterval: 12,
  dynamicHazardsAdded: 0,
  maxDynamicHazards: 3,
  runEnded: false
};

function setDebugText(message) {
  if (debugText) {
    debugText.textContent = message;
  }
}

function showLoading(show) {
  if (!loadingOverlay) return;
  loadingOverlay.classList.toggle('hidden', !show);
}

function showLevelCompletePanel(show) {
  if (!levelCompleteModal) return;
  levelCompleteModal.classList.toggle('hidden', !show);
}

function showLevelResult(type) {
  const hasNextLevel = game.currentLevel < levelData.length - 1;
  const isWin = type === 'win';
  const isFinalWin = isWin && !hasNextLevel;

  game.won = isWin;
  game.gameOver = !isWin;

  const completePanel = document.querySelector('.level-complete-panel');
  if (completePanel) {
    completePanel.classList.toggle('winner', isFinalWin);
  }

  if (levelResultTitle) {
    levelResultTitle.textContent = isWin ? (isFinalWin ? 'YOU WIN THE GAME!' : 'LEVEL CLEAR!') : 'GAME OVER';
  }

  if (levelResultMessage) {
    levelResultMessage.textContent = isWin
      ? (isFinalWin ? 'You beat every level and completed the full challenge.' : 'Great job. Ready for the next challenge?')
      : 'You ran out of lives. Your run has ended.';
  }

  if (replayLevelBtn) {
    replayLevelBtn.textContent = isWin ? (isFinalWin ? 'Play Again' : 'Replay Level') : 'Try Again';
  }

  if (nextLevelBtn) {
    const canAdvance = isWin && hasNextLevel;
    nextLevelBtn.disabled = !canAdvance;
    nextLevelBtn.classList.toggle('hidden', !isWin || isFinalWin);
    nextLevelBtn.textContent = hasNextLevel ? 'Next Level' : 'Final Level';
  }

  if (isWin) {
    audio.playWinSound();
  } else {
    audio.playLoseSound();
  }

  showLevelCompletePanel(true);

  // A run truly ends when the player runs out of lives, or beats the
  // final level. Either way, save the final score right away and show
  // the player where it landed.
  if (isFinalWin || !isWin) {
    finalizeRun(isFinalWin ? 'win' : 'gameover');
  }
}

async function finalizeRun(outcome) {
  game.runEnded = true;
  const finalScore = game.score;

  const outcomeBase = outcome === 'win'
    ? 'You beat every level and completed the full challenge.'
    : 'You ran out of lives. Your run has ended.';

  if (levelResultMessage) {
    levelResultMessage.textContent = `${outcomeBase} Final score: ${finalScore.toLocaleString()}. Saving to the leaderboard...`;
  }

  const saved = await submitScoreToBackend();
  const rank = saved ? await findLeaderboardRank(finalScore) : null;

  if (levelResultMessage) {
    let scoreLine = `Final score: ${finalScore.toLocaleString()}.`;
    if (!saved) {
      scoreLine += ' (Your score could not be saved to the server — check your connection.)';
    } else if (rank) {
      scoreLine += ` You made the Top 10 — rank #${rank}!`;
    } else {
      scoreLine += ' Not in the Top 10 this time.';
    }
    levelResultMessage.textContent = `${outcomeBase} ${scoreLine}`;
  }
}

async function findLeaderboardRank(score) {
  try {
    const response = await fetch('/api/leaderboard/top10');
    if (!response.ok) return null;
    const data = await response.json();
    const rows = data.leaderboard || [];
    const match = rows.find((row) => Number(row.score) === Number(score)
      && (row.display_name === registeredPlayer.display_name || row.player_name === registeredPlayer.player_name));
    return match ? match.rank : null;
  } catch (error) {
    return null;
  }
}

function startNewRun() {
  game.score = 0;
  game.lives = 3;
  resetLevel(0);
}

function makePlayer(x, y) {
  return {
    x, y,
    w: 26,
    h: 38,
    vx: 0,
    vy: 0,
    grounded: false,
    facing: 1
  };
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

const audio = {
  ctx: null,

  init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  },

  tone({ frequency = 440, duration = 0.18, type = 'sine', volume = 0.05, sweep = 0 }) {
    if (!this.ctx) return;

    const oscillator = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, this.ctx.currentTime);

    if (sweep !== 0) {
      oscillator.frequency.linearRampToValueAtTime(
        frequency + sweep,
        this.ctx.currentTime + duration
      );
    }

    gainNode.gain.setValueAtTime(0.0001, this.ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(volume, this.ctx.currentTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(this.ctx.destination);
    oscillator.start();
    oscillator.stop(this.ctx.currentTime + duration);
  },

  playWinSound() {
    this.init();
    if (!this.ctx) return;
    this.tone({ frequency: 660, duration: 0.12, type: 'triangle', volume: 0.05, sweep: 120 });
    setTimeout(() => {
      this.tone({ frequency: 880, duration: 0.16, type: 'triangle', volume: 0.05, sweep: 140 });
    }, 90);
  },

  playLoseSound() {
    this.init();
    if (!this.ctx) return;
    this.tone({ frequency: 260, duration: 0.25, type: 'sawtooth', volume: 0.05, sweep: -180 });
  }
};

// The ground platform's top surface — this is where the player's feet
// actually rest under DOWN gravity. Hazards on the DOWN wall have to sit
// just above this line (poking up out of the ground) or they end up
// buried inside the solid platform below the player and can never
// register a hit.
const GROUND_LINE = 560;

function rectIntersect(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

// Hazards are stored relative to the wall they're mounted on (DOWN/UP/
// LEFT/RIGHT) rather than fixed canvas coordinates, so this converts one
// into an actual {x, y, w, h} rectangle for collision + drawing.
function getHazardRect(hazard) {
  const thickness = hazard.thickness || 20;
  switch (hazard.wall) {
    case 'UP':
      return { x: hazard.pos, y: 0, w: hazard.length, h: thickness };
    case 'LEFT':
      return { x: 0, y: hazard.pos, w: thickness, h: hazard.length };
    case 'RIGHT':
      return { x: canvas.width - thickness, y: hazard.pos, w: thickness, h: hazard.length };
    case 'DOWN':
    default:
      return { x: hazard.pos, y: GROUND_LINE - thickness, w: hazard.length, h: thickness };
  }
}

function setControlMode(mode) {
  const isValidMode = ['External Controller Connected', 'Backup Controls Active', 'External Controller Reconnected'].includes(mode);
  if (!isValidMode) return;

  game.controlMode = mode;
  const controlModeValue = document.getElementById('controlModeValue');
  if (controlModeValue) {
    controlModeValue.textContent = mode;
    controlModeValue.style.color = mode === 'Backup Controls Active' ? '#ffbd66' : '#68f7d0';
  }
}

function updateHUD() {
  document.getElementById('hud-score').textContent = String(game.score);
  document.getElementById('hud-crystals').textContent = String(game.crystals);
  document.getElementById('gravity-indicator').textContent = `GRAVITY: ${game.gravity}`;
  document.getElementById('hud-gravity').textContent = `GRAVITY: ${game.gravity}`;
  document.getElementById('shift-text').textContent = `SHIFT IN: ${Math.ceil(game.shiftTimer)}s`;

  document.querySelectorAll('#livesDisplay .life-icon').forEach((icon, idx) => {
    icon.classList.toggle('lost', idx >= game.lives);
  });

  const hasNextLevel = game.currentLevel < levelData.length - 1;
  if (nextLevelBtn) {
    if (game.won) {
      nextLevelBtn.disabled = !hasNextLevel;
      nextLevelBtn.textContent = hasNextLevel ? 'Next Level' : 'Final Level';
      nextLevelBtn.classList.toggle('hidden', !game.won);
    } else {
      nextLevelBtn.disabled = true;
      nextLevelBtn.classList.add('hidden');
    }
  }
}

// Briefly flashes the just-lost heart icon so losing a life reads clearly.
function animateLifeLost(remainingLives) {
  const icons = document.querySelectorAll('#livesDisplay .life-icon');
  const lostIcon = icons[remainingLives];
  if (!lostIcon) return;
  lostIcon.classList.add('just-lost');
  setTimeout(() => lostIcon.classList.remove('just-lost'), 550);
}

// Quick full-board red flash so a hazard hit is unmistakable, independent
// of the player-sprite blink.
function flashHazardOverlay() {
  const flashEl = document.getElementById('hazardFlash');
  if (!flashEl) return;
  flashEl.classList.add('active');
  setTimeout(() => flashEl.classList.remove('active'), 160);
}

function getSafeLevelIndex(levelIndex) {
  const normalized = Number(levelIndex);
  if (!Number.isFinite(normalized)) return 0;
  return clamp(Math.floor(normalized), 0, Math.max(levelData.length - 1, 0));
}

function resetLevel(levelIndex = game.currentLevel) {
  const safeIndex = getSafeLevelIndex(levelIndex);

  // Rebuild the level from scratch so crystals collected in a previous
  // attempt (spliced out of the old level object) come back on replay
  // or when revisiting a level from the level select screen.
  levelData[safeIndex] = buildLevel(safeIndex + 1);
  const level = levelData[safeIndex];

  if (!level) {
    setDebugText('Level data unavailable');
    return;
  }

  game.currentLevel = safeIndex;
  game.gravity = 'DOWN';
  // Gravity flips automatically, starting every 4 seconds and ramping up
  // to every 1.5 seconds by the later levels.
  game.shiftInterval = Math.max(1.5, 4 - (level.id - 1) * 0.025);
  game.shiftTimer = game.shiftInterval;
  game.won = false;
  game.gameOver = false;
  game.runEnded = false;
  game.dying = false;
  game.deathBlinkTimer = 0;
  game.hitFlashTimer = 0;
  // Hazards escalate the longer a level runs: the interval between new
  // hazard spawns starts shorter (and more hazards are allowed) on later
  // levels, so danger keeps building the longer the player lingers.
  game.hazardSpawnInterval = Math.max(6, 14 - Math.floor(level.id / 10));
  game.hazardSpawnTimer = game.hazardSpawnInterval;
  game.dynamicHazardsAdded = 0;
  game.maxDynamicHazards = 3 + Math.min(3, Math.floor(level.id / 20));
  showLevelCompletePanel(false);
  game.levelStartTime = performance.now();
  game.levelCompletionMs = 0;
  if (nextLevelBtn) {
    nextLevelBtn.classList.remove('hidden');
    nextLevelBtn.disabled = true;
    nextLevelBtn.textContent = 'Next Level';
  }
  game.player = makePlayer(level.playerStart.x, level.playerStart.y);
  game.totalCrystals = level.crystals.length;
  game.crystals = 0;

  if (game.score === 0 || game.currentLevel === 0) {
    game.score = 0;
  }
  // Snapshot the score at the start of this attempt so a hazard death can
  // roll back any crystals collected during the failed attempt, instead of
  // letting the player farm points by dying and re-collecting on replay.
  game.levelStartScore = game.score;

  document.getElementById('level-name').textContent = `${level.id}. ${level.name}`;
  document.querySelectorAll('.level-btn').forEach((button) => {
    const buttonLevel = Number(button.dataset.level);
    const available = buttonLevel <= Math.min(game.highestUnlockedLevel, levelData.length);
    button.disabled = !available;
    button.classList.toggle('current', buttonLevel === level.id);
    button.classList.toggle('locked', !available);
    button.style.opacity = available ? '1' : '0.45';
  });
  updateHUD();
  setDebugText(`Level ${level.id}: ${level.name}`);
}

function setGravity(dir) {
  const level = levelData[game.currentLevel];
  if (!level.allowedGravity.includes(dir)) return;
  game.gravity = dir;
  updateHUD();
}

function triggerJump() {
  const player = game.player;
  if (!player.grounded) return;

  if (game.gravity === 'DOWN') player.vy = -10.5;
  if (game.gravity === 'UP') player.vy = 10.5;
  if (game.gravity === 'LEFT') player.vx = 10.5;
  if (game.gravity === 'RIGHT') player.vx = -10.5;

  player.grounded = false;
}

function handleMovementInput() {
  const player = game.player;

  if (controls.left) {
    player.vx = -3.2;
    player.facing = -1;
  } else if (controls.right) {
    player.vx = 3.2;
    player.facing = 1;
  } else {
    player.vx *= 0.78;
    if (Math.abs(player.vx) < 0.1) player.vx = 0;
  }

  if (controls.jump) {
    triggerJump();
    controls.jump = false;
  }
}

function movePlayer() {
  const player = game.player;
  const level = levelData[game.currentLevel];
  const gravityVector = {
    DOWN: { x: 0, y: 0.45 },
    UP: { x: 0, y: -0.45 },
    LEFT: { x: -0.45, y: 0 },
    RIGHT: { x: 0.45, y: 0 }
  };

  const g = gravityVector[game.gravity];
  player.vx += g.x;
  player.vy += g.y;

  const maxSpeed = 7;
  if (Math.abs(player.vx) > maxSpeed) player.vx = Math.sign(player.vx) * maxSpeed;
  if (Math.abs(player.vy) > 11) player.vy = Math.sign(player.vy) * 11;

  player.x += player.vx;
  for (const platform of level.platforms) {
    if (rectIntersect(player, platform)) {
      if (player.vx > 0) player.x = platform.x - player.w;
      if (player.vx < 0) player.x = platform.x + platform.w;
      player.vx = 0;
    }
  }

  player.y += player.vy;
  player.grounded = false;

  for (const platform of level.platforms) {
    if (rectIntersect(player, platform)) {
      if (player.vy > 0 && game.gravity === 'DOWN') {
        player.y = platform.y - player.h;
        player.vy = 0;
        player.grounded = true;
      } else if (player.vy < 0 && game.gravity === 'UP') {
        player.y = platform.y + platform.h;
        player.vy = 0;
        player.grounded = true;
      } else if (player.vx < 0 && game.gravity === 'LEFT') {
        player.x = platform.x + platform.w;
        player.vx = 0;
        player.grounded = true;
      } else if (player.vx > 0 && game.gravity === 'RIGHT') {
        player.x = platform.x - player.w;
        player.vx = 0;
        player.grounded = true;
      }
    }
  }

  player.x = clamp(player.x, 0, canvas.width - player.w);
  player.y = clamp(player.y, 0, canvas.height - player.h);

  if (game.gravity === 'DOWN' && player.y >= canvas.height - player.h) {
    player.y = canvas.height - player.h;
    player.vy = 0;
    player.grounded = true;
  }

  if (game.gravity === 'UP' && player.y <= 0) {
    player.y = 0;
    player.vy = 0;
    player.grounded = true;
  }

  if (game.gravity === 'LEFT' && player.x <= 0) {
    player.x = 0;
    player.vx = 0;
    player.grounded = true;
  }

  if (game.gravity === 'RIGHT' && player.x >= canvas.width - player.w) {
    player.x = canvas.width - player.w;
    player.vx = 0;
    player.grounded = true;
  }

  collectCrystals();
  checkGoal();
  checkHazards();
}

function collectCrystals() {
  const level = levelData[game.currentLevel];
  const player = game.player;

  for (let i = level.crystals.length - 1; i >= 0; i -= 1) {
    const crystal = level.crystals[i];
    const dx = player.x + player.w / 2 - crystal.x;
    const dy = player.y + player.h / 2 - crystal.y;
    if (Math.hypot(dx, dy) < 28) {
      level.crystals.splice(i, 1);
      game.crystals += 1;
      game.score += 100;
      updateHUD();
    }
  }
}

function checkGoal() {
  const level = levelData[game.currentLevel];
  const player = game.player;
  const goal = level.goal;

  const hitGoal = Math.hypot(player.x + player.w / 2 - goal.x, player.y + player.h / 2 - goal.y) < 42;
  if (hitGoal && game.crystals >= game.totalCrystals && !game.won && !game.gameOver) {
    game.levelCompletionMs = Math.max(0, performance.now() - game.levelStartTime);
    game.score += 250;
    game.highestUnlockedLevel = Math.min(levelData.length, Math.max(game.highestUnlockedLevel, level.id + 1));
    updateHUD();
    setDebugText(`Goal reached on ${level.name} in ${formatTime(game.levelCompletionMs)}`);
    showLevelResult('win');
  }
}

function spawnDynamicHazard(level) {
  // Tactically place new hazards on whichever wall the player is currently
  // resting against (the current gravity direction) — that's where they're
  // exposed right now, so that's where new danger shows up.
  const wall = level.allowedGravity.includes(game.gravity) ? game.gravity : 'DOWN';
  const wallSpan = { DOWN: 1024, UP: 1024, LEFT: 640, RIGHT: 640 };
  const span = wallSpan[wall];
  const length = 80 + Math.floor(Math.random() * 60);
  const pos = clamp(Math.random() * (span - length), 0, span - length);
  level.hazards.push({ wall, pos, length, thickness: 20, dynamic: true });
}

function checkHazards() {
  if (game.dying || game.won || game.gameOver) return;

  const level = levelData[game.currentLevel];
  const player = game.player;

  for (const hazard of level.hazards) {
    if (rectIntersect(player, getHazardRect(hazard))) {
      triggerHazardDeath();
      break;
    }
  }
}

// A hazard touch is instant death: freeze the player, flash the screen,
// blink the sprite briefly so the hit reads clearly, then resolve into
// either a level restart (life remaining) or a full run-ending game over.
function triggerHazardDeath() {
  game.dying = true;
  game.deathBlinkTimer = 42;
  game.hitFlashTimer = 14;
  flashHazardOverlay();
  audio.playLoseSound();
}

function resolveDeath() {
  game.dying = false;
  game.lives = Math.max(0, game.lives - 1);
  animateLifeLost(game.lives);
  updateHUD();

  if (game.lives <= 0) {
    game.gameOver = true;
    showLevelResult('gameover');
    return;
  }

  const level = levelData[game.currentLevel];
  setDebugText(`Hazard hit! ${game.lives} ${game.lives === 1 ? 'life' : 'lives'} left. Restarting ${level.name}.`);
  // Roll back any score earned this attempt (crystals collected before the
  // hit) so dying can't be used to farm points by re-collecting on restart.
  game.score = game.levelStartScore;
  resetLevel(game.currentLevel);
}

function drawGrid() {
  ctx.strokeStyle = 'rgba(73, 221, 255, 0.30)';
  ctx.lineWidth = 1;

  for (let x = 0; x <= canvas.width; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  for (let y = 0; y <= canvas.height; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
}

function drawPlatform(platform) {
  ctx.fillStyle = 'rgba(15, 31, 42, 0.5)';
  ctx.strokeStyle = '#46d6ff';
  ctx.lineWidth = 2;
  ctx.fillRect(platform.x, platform.y, platform.w, platform.h);
  ctx.strokeRect(platform.x, platform.y, platform.w, platform.h);
}

function drawCrystal(crystal) {
  ctx.save();
  ctx.translate(crystal.x, crystal.y);
  ctx.fillStyle = '#4ed8ff';
  ctx.beginPath();
  ctx.moveTo(0, -12);
  ctx.lineTo(10, 0);
  ctx.lineTo(0, 12);
  ctx.lineTo(-10, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawGoal(goal) {
  ctx.save();
  ctx.translate(goal.x, goal.y);
  ctx.fillStyle = '#de8af9';
  ctx.beginPath();
  ctx.arc(0, 0, goal.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawHazard(hazard) {
  const rect = getHazardRect(hazard);
  ctx.fillStyle = '#ff5a41';

  const isHorizontal = hazard.wall === 'DOWN' || hazard.wall === 'UP' || !hazard.wall;
  const spikeSpan = isHorizontal ? rect.w : rect.h;
  const spikeCount = Math.max(1, Math.round(spikeSpan / 36));

  if (isHorizontal) {
    const spikeW = rect.w / spikeCount;
    const apexY = hazard.wall === 'UP' ? rect.y + rect.h : rect.y;
    const baseY = hazard.wall === 'UP' ? rect.y : rect.y + rect.h;
    for (let i = 0; i < spikeCount; i += 1) {
      ctx.beginPath();
      ctx.moveTo(rect.x + i * spikeW, baseY);
      ctx.lineTo(rect.x + i * spikeW + spikeW / 2, apexY);
      ctx.lineTo(rect.x + i * spikeW + spikeW, baseY);
      ctx.closePath();
      ctx.fill();
    }
  } else {
    const spikeH = rect.h / spikeCount;
    const apexX = hazard.wall === 'LEFT' ? rect.x + rect.w : rect.x;
    const baseX = hazard.wall === 'LEFT' ? rect.x : rect.x + rect.w;
    for (let i = 0; i < spikeCount; i += 1) {
      ctx.beginPath();
      ctx.moveTo(baseX, rect.y + i * spikeH);
      ctx.lineTo(apexX, rect.y + i * spikeH + spikeH / 2);
      ctx.lineTo(baseX, rect.y + i * spikeH + spikeH);
      ctx.closePath();
      ctx.fill();
    }
  }
}

function drawPlayer() {
  // Blink the sprite on/off while the death sequence plays so getting hit
  // by a hazard reads unmistakably.
  if (game.dying && Math.floor(game.deathBlinkTimer / 4) % 2 === 1) {
    return;
  }

  const player = game.player;
  ctx.fillStyle = '#1bcfff';
  ctx.fillRect(player.x + 8, player.y, player.w - 16, player.h - 10);

  ctx.fillStyle = '#3f1f2b';
  ctx.fillRect(player.x + 6, player.y + 10, 4, 4);
  ctx.fillRect(player.x + player.w - 10, player.y + 10, 4, 4);

  ctx.fillStyle = '#f5d4a5';
  ctx.fillRect(player.x + 13, player.y + 6, player.w - 26, 8);

  ctx.fillStyle = '#000';
  ctx.fillRect(player.x + 6, player.y + player.h - 4, 5, 4);
  ctx.fillRect(player.x + player.w - 11, player.y + player.h - 4, 5, 4);
}

function drawHUDText() {
  ctx.fillStyle = '#dff9ff';
  ctx.font = 'bold 13px Segoe UI';
  ctx.fillText(`LEVEL ${game.currentLevel + 1}`, 22, 30);
  ctx.fillText(`CRYSTALS ${game.crystals}/${game.totalCrystals}`, 22, 52);
}

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();

  const level = levelData[game.currentLevel];
  level.platforms.forEach(drawPlatform);
  level.hazards.forEach(drawHazard);
  drawGoal(level.goal);
  level.crystals.forEach(drawCrystal);
  drawPlayer();
  drawHUDText();

  if (game.won) {
    const finalGameWin = game.currentLevel === levelData.length - 1;
    const bannerWidth = finalGameWin ? 560 : 500;
    const bannerX = (canvas.width - bannerWidth) / 2;
    const panelY = 210;

    ctx.fillStyle = 'rgba(5, 15, 25, 0.75)';
    ctx.fillRect(bannerX, panelY, bannerWidth, 130);
    ctx.strokeStyle = finalGameWin ? '#ffd76a' : '#5ee3ff';
    ctx.strokeRect(bannerX, panelY, bannerWidth, 130);
    ctx.fillStyle = finalGameWin ? '#ffd76a' : '#dffaff';
    ctx.font = finalGameWin ? 'bold 30px Segoe UI' : 'bold 36px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText(finalGameWin ? 'YOU WIN THE GAME!' : 'LEVEL CLEAR!', canvas.width / 2, 280);
    ctx.font = '18px Segoe UI';
    ctx.fillText(finalGameWin ? 'The full challenge is complete.' : 'Choose Replay or Next Level below.', canvas.width / 2, 315);
    ctx.textAlign = 'left';
  }
}

function updateGameLoop() {
  const level = levelData[game.currentLevel];

  if (game.dying) {
    game.deathBlinkTimer -= 1;
    if (game.hitFlashTimer > 0) game.hitFlashTimer -= 1;
    if (game.deathBlinkTimer <= 0) {
      resolveDeath();
    }
    updateHUD();
    render();
    return;
  }

  if (!game.won && !game.gameOver) {
    handleMovementInput();
    movePlayer();
    game.shiftTimer = Math.max(0, game.shiftTimer - 0.016);

    if (game.hitFlashTimer > 0) game.hitFlashTimer -= 1;

    game.hazardSpawnTimer -= 0.016;
    if (game.hazardSpawnTimer <= 0 && game.dynamicHazardsAdded < game.maxDynamicHazards) {
      spawnDynamicHazard(level);
      game.dynamicHazardsAdded += 1;
      // Each new hazard arrives a little sooner than the last, so danger
      // keeps ramping up the longer the player stays in the level.
      game.hazardSpawnInterval = Math.max(4, game.hazardSpawnInterval * 0.75);
      game.hazardSpawnTimer = game.hazardSpawnInterval;
    }
  }

  if (game.shiftTimer <= 0) {
    // Cycle within THIS level's allowed directions only. Cycling through the
    // full DOWN/UP/LEFT/RIGHT list would land on a locked direction (e.g.
    // LEFT right after UP on an early level), silently no-op, and leave
    // gravity stuck forever instead of wrapping back around to DOWN.
    const options = level.allowedGravity;
    const currentIndex = options.indexOf(game.gravity);
    const nextGravity = options[(currentIndex + 1) % options.length];
    setGravity(nextGravity);
    game.shiftTimer = game.shiftInterval;
  }

  updateHUD();
  render();
}

function handleButtonAction(action) {
  if (action === 'left') controls.left = true;
  if (action === 'right') controls.right = true;
  if (action === 'jump') controls.jump = true;
}

function populateLevelButtons() {
  const levelList = document.querySelector('.level-list');
  if (!levelList) return;

  levelList.innerHTML = '';

  for (let levelNumber = 1; levelNumber <= TOTAL_LEVELS; levelNumber += 1) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'level-btn';
    button.dataset.level = String(levelNumber);
    button.textContent = `L${levelNumber}`;
    const isLocked = levelNumber > game.highestUnlockedLevel;
    button.disabled = isLocked;
    button.classList.toggle('locked', isLocked);
    button.style.opacity = isLocked ? '0.45' : '1';
    button.addEventListener('click', () => {
      audio.init();
      if (isLocked) {
        return;
      }
      resetLevel(levelNumber - 1);
    });
    levelList.appendChild(button);
  }
}

async function submitScoreToBackend() {
  if (!registeredPlayer.player_name || !registeredPlayer.company_name) {
    setDebugText('Register a player and company name before submitting a score.');
    return false;
  }

  try {
    const payload = {
      company_name: registeredPlayer.company_name,
      player_name: registeredPlayer.player_name,
      display_name: registeredPlayer.display_name,
      score: game.score,
      control_method: game.controlMode,
      external_controller_used: game.externalControllerConnected ? 1 : 0,
      connection_status: game.controlMode,
      reached_stage: `Level ${game.currentLevel + 1}`,
      duration: 0,
      game_version: '1.0.0'
    };

    const response = await fetch('/api/games', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      const errorPayload = await response.json().catch(() => ({}));
      throw new Error(errorPayload.error || 'Unable to save score to the backend.');
    }

    setDebugText(`Score saved for ${registeredPlayer.display_name}`);
    loadLeaderboard();
    return true;
  } catch (error) {
    setDebugText(error.message || 'Score sync failed.');
    return false;
  }
}

function formatTime(ms) {
  const safeMs = Number(ms || 0);
  const totalSeconds = Math.max(0, Math.floor(safeMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const hundredths = Math.floor((safeMs % 1000) / 10);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(hundredths).padStart(2, '0')}`;
}

function renderLeaderboard(rows = []) {
  if (!leaderboardList) return;
  leaderboardList.innerHTML = '';

  if (!rows.length) {
    const emptyItem = document.createElement('li');
    emptyItem.innerHTML = '<span class="rank">—</span><span class="name">No records yet</span><span class="score">--</span>';
    leaderboardList.appendChild(emptyItem);
    return;
  }

  rows.slice(0, 10).forEach((entry, index) => {
    const item = document.createElement('li');
    const rankSpan = document.createElement('span');
    const nameSpan = document.createElement('span');
    const scoreSpan = document.createElement('span');

    rankSpan.className = 'rank';
    nameSpan.className = 'name';
    scoreSpan.className = 'score';
    item.classList.toggle('top-ranked', index < 10);

    rankSpan.textContent = `#${entry.rank ?? index + 1}`;
    nameSpan.textContent = entry.display_name || entry.company_name || 'Player';
    scoreSpan.textContent = Number(entry.score ?? 0).toLocaleString();

    item.append(rankSpan, nameSpan, scoreSpan);
    leaderboardList.appendChild(item);
  });
}

async function loadLeaderboard() {
  try {
    const response = await fetch('/api/leaderboard/top10');
    if (!response.ok) {
      renderLeaderboard([]);
      return;
    }

    const data = await response.json();
    renderLeaderboard(data.leaderboard || []);
  } catch (error) {
    renderLeaderboard([]);
  }
}

function toggleLeaderboard(show) {
  if (!leaderboardPanel) return;
  leaderboardPanel.classList.toggle('hidden', !show);
}

function exportGamesCsv() {
  window.open('/api/export/csv', '_blank');
}

function bindUI() {
  populateLevelButtons();
  setControlMode(navigator.onLine ? 'External Controller Connected' : 'Backup Controls Active');
  loadLeaderboard();

  window.addEventListener('online', () => {
    game.externalControllerConnected = true;
    setControlMode('External Controller Reconnected');
  });

  window.addEventListener('offline', () => {
    game.externalControllerConnected = false;
    setControlMode('Backup Controls Active');
  });

  document.getElementById('leaderboardBtn')?.addEventListener('click', () => {
    toggleLeaderboard(true);
    loadLeaderboard();
  });
  document.getElementById('closeLeaderboardBtn')?.addEventListener('click', () => toggleLeaderboard(false));
  document.getElementById('exportCsvBtn')?.addEventListener('click', exportGamesCsv);
  document.getElementById('submitScoreBtn')?.addEventListener('click', submitScoreToBackend);

  document.querySelectorAll('.control-btn').forEach((button) => {
    const press = (event) => {
      event.preventDefault();
      audio.init();
      const action = button.dataset.action;
      if (['left', 'right', 'jump'].includes(action)) {
        handleButtonAction(action);
      }
    };

    const release = (event) => {
      event.preventDefault();
      const action = button.dataset.action;
      if (action === 'left') controls.left = false;
      if (action === 'right') controls.right = false;
    };

    button.addEventListener('mousedown', press);
    button.addEventListener('touchstart', press, { passive: false });
    button.addEventListener('mouseup', release);
    button.addEventListener('mouseleave', release);
    button.addEventListener('touchend', release);
    button.addEventListener('touchcancel', release);
  });

  replayLevelBtn.addEventListener('click', () => {
    audio.init();
    if (game.runEnded) {
      startNewRun();
    } else {
      resetLevel(game.currentLevel);
    }
  });

  nextLevelBtn.addEventListener('click', () => {
    audio.init();
    if (!game.won || game.gameOver) {
      setDebugText('You must win the level before continuing.');
      return;
    }

    if (game.currentLevel < levelData.length - 1) {
      resetLevel(game.currentLevel + 1);
      return;
    }

    setDebugText('Final level complete');
    showLevelCompletePanel(false);
  });

  window.addEventListener('keydown', (event) => {
    audio.init();
    if (event.key === 'ArrowLeft') controls.left = true;
    if (event.key === 'ArrowRight') controls.right = true;
    // Jump always pushes the player away from whatever surface gravity has
    // them stuck to, so Down works just as well as Up/Space — that's the
    // intuitive key to "jump down" off the ceiling when gravity is UP.
    if (event.key === ' ' || event.key === 'ArrowUp' || event.key === 'ArrowDown') {
      controls.jump = true;
      event.preventDefault();
    }
  });

  window.addEventListener('keyup', (event) => {
    if (event.key === 'ArrowLeft') controls.left = false;
    if (event.key === 'ArrowRight') controls.right = false;
  });

  fullscreenButton.addEventListener('click', () => {
    const root = document.documentElement;
    if (!document.fullscreenElement) {
      root.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  });
}

async function startRegisteredGame() {
  const playerName = registrationPlayerInput?.value.trim() || '';
  const companyName = registrationCompanyInput?.value.trim() || '';

  if (!playerName || !companyName) {
    if (registrationError) registrationError.textContent = 'Enter both your player name and company name.';
    return;
  }

  if (startGameBtn) {
    startGameBtn.disabled = true;
    startGameBtn.textContent = 'Checking details...';
  }
  if (registrationError) registrationError.textContent = '';

  let displayName = `${companyName} - ${playerName}`;
  try {
    const response = await fetch('/api/validate-name', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ player_name: playerName, company_name: companyName })
    });

    if (!response.ok) {
      const payload = await response.json().catch(() => ({}));
      throw new Error(payload.error || 'Enter both your player name and company name.');
    }

    const data = await response.json();
    displayName = data.display_name || displayName;
    registeredPlayer = {
      player_name: data.player_name || playerName,
      company_name: data.company_name || companyName,
      display_name: displayName
    };
  } catch (error) {
    if (registrationError) registrationError.textContent = error.message || 'Enter both your player name and company name.';
    if (startGameBtn) { startGameBtn.disabled = false; startGameBtn.textContent = 'Start Game'; }
    return;
  }

  const participantInput = document.getElementById('participantInput');
  if (participantInput) participantInput.value = displayName;
  try {
    sessionStorage.setItem('gravityShiftPlayerName', registeredPlayer.player_name);
    sessionStorage.setItem('gravityShiftCompanyName', registeredPlayer.company_name);
  } catch (_) {}

  registrationScreen?.classList.add('hidden');
  toggleInstructions(true);
}

function toggleInstructions(show) {
  if (!instructionsScreen) return;
  instructionsScreen.classList.toggle('hidden', !show);
  if (beginPlayBtn) {
    beginPlayBtn.textContent = gameStarted ? 'Close' : 'Start Playing';
  }
}

function launchGameplay() {
  gameStarted = true;
  toggleInstructions(false);
  if (gameShell) gameShell.classList.remove('pre-game');

  game.score = 0;
  game.lives = 3;
  showLoading(true);
  bindUI();
  resetLevel(0);
  showLoading(false);
  setDebugText('Gravity Shift loaded');
  game.intervalId = setInterval(updateGameLoop, 1000 / 60);
}

function init() {
  const savedPlayer = (() => { try { return sessionStorage.getItem('gravityShiftPlayerName') || ''; } catch (_) { return ''; } })();
  const savedCompany = (() => { try { return sessionStorage.getItem('gravityShiftCompanyName') || ''; } catch (_) { return ''; } })();
  if (registrationPlayerInput) registrationPlayerInput.value = savedPlayer;
  if (registrationCompanyInput) registrationCompanyInput.value = savedCompany;

  startGameBtn?.addEventListener('click', startRegisteredGame);
  [registrationPlayerInput, registrationCompanyInput].forEach((input) => {
    input?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') startRegisteredGame();
    });
  });

  beginPlayBtn?.addEventListener('click', () => {
    if (!gameStarted) {
      launchGameplay();
    } else {
      toggleInstructions(false);
    }
  });

  document.getElementById('howToPlayBtn')?.addEventListener('click', () => {
    toggleInstructions(true);
  });
}

init();
