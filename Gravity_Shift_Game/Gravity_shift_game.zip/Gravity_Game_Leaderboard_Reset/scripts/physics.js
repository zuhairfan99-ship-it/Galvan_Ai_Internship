// Physics system for 4-way gravity
window.GRAVITY_ACCEL = 0.45;
window.MAX_FALL_SPEED = 9.5;
window.JUMP_POWER = 9.8;

window.getGravityVector = function(dir) {
  switch (dir) {
    case 'DOWN': return { x: 0, y: window.GRAVITY_ACCEL };
    case 'UP': return { x: 0, y: -window.GRAVITY_ACCEL };
    case 'LEFT': return { x: -window.GRAVITY_ACCEL, y: 0 };
    case 'RIGHT': return { x: window.GRAVITY_ACCEL, y: 0 };
    default: return { x: 0, y: window.GRAVITY_ACCEL };
  }
};
