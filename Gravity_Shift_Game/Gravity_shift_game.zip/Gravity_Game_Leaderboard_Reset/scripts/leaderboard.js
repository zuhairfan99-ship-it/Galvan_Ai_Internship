// LocalStorage leaderboard manager
window.getSavedScores = function() {
  try {
    return JSON.parse(localStorage.getItem('gs_leaderboard')) || [];
  } catch(e) { return []; }
};
