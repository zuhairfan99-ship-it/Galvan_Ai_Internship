// Particle and visual effects generator
window.createParticle = function(x, y, color) {
  return { x: x, y: y, vx: (Math.random()-0.5)*4, vy: (Math.random()-0.5)*4, life: 1, color: color };
};
