// Player state and movement logic
window.createPlayer = function(x, y) {
  return {
    x: x, y: y, width: 32, height: 42,
    vx: 0, vy: 0, health: 100, maxHealth: 100,
    isGrounded: false, facing: 'right', invulnerableTimer: 0
  };
};
