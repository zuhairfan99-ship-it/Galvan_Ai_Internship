// Enemy AI and behavior
window.updateEnemyAI = function(enemy, player, level) {
  if (enemy.type === 'robot') {
    enemy.x += enemy.vx;
    if (enemy.patrolMinX && enemy.x < enemy.patrolMinX) { enemy.x = enemy.patrolMinX; enemy.vx = Math.abs(enemy.vx); }
    if (enemy.patrolMaxX && enemy.x > enemy.patrolMaxX) { enemy.x = enemy.patrolMaxX; enemy.vx = -Math.abs(enemy.vx); }
  }
};
