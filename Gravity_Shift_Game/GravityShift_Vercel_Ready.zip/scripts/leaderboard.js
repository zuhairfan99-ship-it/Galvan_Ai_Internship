// Backend leaderboard helper. Official records are never stored in browser storage.
window.getLevelLeaderboard = async function(levelNumber) {
  const response = await fetch(`/api/leaderboard/level/${Number(levelNumber)}`, { cache: 'no-store' });
  if (!response.ok) throw new Error('Leaderboard unavailable.');
  const data = await response.json();
  return data.leaderboard || [];
};
