require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { DatabaseSync } = require('node:sqlite');
const { Pool } = require('pg');

const dbPath = path.resolve(process.env.DB_PATH || './data/leaderboard.db');
if (!process.env.DATABASE_URL) {
  console.error('DATABASE_URL is required for this migration.');
  process.exit(1);
}
if (!fs.existsSync(dbPath)) {
  console.error(`SQLite database not found: ${dbPath}`);
  process.exit(1);
}

const sqlite = new DatabaseSync(dbPath);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false } });

const schema = fs.readFileSync(path.join(__dirname, '..', 'schema.sql'), 'utf8');

(async () => {
  const client = await pool.connect();
  try {
    await client.query(schema);
    const sessions = sqlite.prepare('SELECT * FROM player_sessions ORDER BY created_at').all();
    const attempts = sqlite.prepare('SELECT * FROM level_attempts ORDER BY created_at').all();
    const records = sqlite.prepare('SELECT * FROM game_records ORDER BY id').all();

    await client.query('BEGIN');
    for (const s of sessions) {
      await client.query(`INSERT INTO player_sessions(session_id,company_name,player_name,display_name,created_at,last_seen_at)
        VALUES($1,$2,$3,$4,$5,$6) ON CONFLICT(session_id) DO NOTHING`,
        [s.session_id,s.company_name,s.player_name,s.display_name,s.created_at,s.last_seen_at]);
    }
    for (const a of attempts) {
      await client.query(`INSERT INTO level_attempts(attempt_id,session_id,level_number,started_at,completed_at,completion_time_ms,status,control_method,connection_status,game_version,metadata_json,created_at)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) ON CONFLICT(attempt_id) DO NOTHING`,
        [a.attempt_id,a.session_id,a.level_number,a.started_at,a.completed_at,a.completion_time_ms,a.status,a.control_method,a.connection_status,a.game_version,a.metadata_json,a.created_at]);
    }
    for (const r of records) {
      await client.query(`INSERT INTO game_records(
        game_id,attempt_id,session_id,company_name,player_name,display_name,level_number,score,completion_time_ms,
        level_start_time,level_completion_time,completed_at,"timestamp",game_start_time,game_end_time,duration,
        control_method,device_id,external_controller_used,connection_status,reached_stage,combo,mistakes,
        game_version,valid_completion,metadata_json,created_at,idempotency_key
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)
      ON CONFLICT(game_id) DO NOTHING`, [
        r.game_id,r.attempt_id,r.session_id,r.company_name,r.player_name,r.display_name,r.level_number,r.score,r.completion_time_ms,
        r.level_start_time,r.level_completion_time,r.completed_at,r.timestamp,r.game_start_time,r.game_end_time,r.duration,
        r.control_method,r.device_id,r.external_controller_used,r.connection_status,r.reached_stage,r.combo,r.mistakes,
        r.game_version,r.valid_completion,r.metadata_json,r.created_at,r.idempotency_key
      ]);
    }
    await client.query('COMMIT');
    console.log(`Migration complete: ${sessions.length} sessions, ${attempts.length} attempts, ${records.length} completed records.`);
  } catch (error) {
    await client.query('ROLLBACK').catch(()=>{});
    console.error(error);
    process.exitCode=1;
  } finally {
    client.release();
    await pool.end();
    sqlite.close();
  }
})();
