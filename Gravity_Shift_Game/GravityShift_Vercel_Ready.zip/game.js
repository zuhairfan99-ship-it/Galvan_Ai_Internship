const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const debugText = document.getElementById('debugText');
const loadingOverlay = document.getElementById('loadingOverlay');
const fullscreenButton = document.getElementById('fullscreenButton');
const levelCompleteModal = document.getElementById('levelCompleteModal');
const levelResultTitle = document.getElementById('levelResultTitle');
const levelResultMessage = document.getElementById('levelResultMessage');
const replayLevelBtn = document.getElementById('replayLevelBtn');
const nextLevelBtn = document.getElementById('nextLevelBtn');
const leaderboardPanel = document.getElementById('leaderboardPanel');
const leaderboardList = document.getElementById('leaderboardList');
const playerLoginModal = document.getElementById('playerLoginModal');
const playerLoginForm = document.getElementById('playerLoginForm');
const playerLoginStatus = document.getElementById('playerLoginStatus');
const participantInput = document.getElementById('participantInput');
const finalStats = document.getElementById('finalStats');
const levelLeaderboardSummary = document.getElementById('levelLeaderboardSummary');
const controllerCodeEl = document.getElementById('controllerCode');

const TOTAL_LEVELS = 100;
const GAME_VERSION = '1.1.0';
let leaderboardRequestToken = 0;

function buildLevel(levelNumber) {
  const sectorNames = [
    'Broken Gravity Lab', 'Laser Research Room', 'Flux Relay Vault', 'Neon Drift Hall',
    'Magnet Tunnel', 'Orbital Lift', 'Solar Anomaly', 'Echo Core', 'Signal Breaker',
    'Zero-G Foundry', 'Prism Chamber', 'Violet Pulse', 'Crystal Nursery', 'Gravity Fork',
    'Trajectory Gate', 'Helix Basin', 'Comet Lattice', 'Aether Forge', 'Ion Lattice',
    'Nova Rift', 'Cipher Room', 'Cyclone Array', 'Xenon Lift', 'Photon Maze', 'Steel Orbit',
    'Sable Vault', 'Kinetic Loop', 'Quantum Steps', 'Sunken Relay', 'Pulse Alley',
    'Mirage Dock', 'Starline Lab', 'Arc Reactor', 'Fission Hall', 'Delta Drift', 'Horizon Glass',
    'Titan Coil', 'Ember Corridor', 'Zenith Lab', 'Polar Shift', 'Abyss Relay', 'Orbit Testbed',
    'Cinder Circuit', 'Velocity Gate', 'Moonwell Chamber', 'Drift Station', 'Gravity Hearth',
    'Spectra Lift', 'Null Harbor', 'Radiant Loop', 'Vector Yard', 'Mantis Room', 'Skyline Array',
    'Blackwater Coil', 'Kindred Lab', 'Phase Tunnel', 'Hammer Vault', 'Deep Echo', 'Elemental Ring',
    'Perpetual Engine', 'Neutrino Yard', 'Starlight Cube', 'Glacier Run', 'Luminous Hall',
    'Cold Current', 'Shatter Bay', 'Night Shift', 'Atlas Lift', 'Prism Drive', 'Shadow Well',
    'Resonance Gate', 'Storm Engine', 'Quartz Run', 'Pulse Harbor', 'Gravity Bloom', 'Silver Rift',
    'Afterglow Lab', 'Runic Lift', 'Inferno Dock', 'Temple of Shift', 'Rogue Circuit', 'Solar Wells',
    'Crimson Loop', 'Nimbus Field', 'Tidal Relay', 'Echoing Core', 'Iron Bloom', 'Aurora Gate',
    'Bastion Run', 'Drift Prism', 'Kite Vault', 'High Voltage', 'Starlit Drift', 'Alpha Pulse',
    'Blackout Lab', 'Torque Valley', 'Frost Valve', 'Comet Gate', 'Quantum Bloom', 'Flux Harbor',
    'Mosaic Relay', 'Gravity Furnace', 'Blue Plasma', 'Voltage Vault', 'Cobalt Drift', 'Halo Circuit'
  ];

  const levelLabel = sectorNames[(levelNumber - 1) % sectorNames.length];
  const allowedGravity = levelNumber <= 10
    ? ['DOWN', 'UP']
    : levelNumber <= 35
      ? ['DOWN', 'UP', 'LEFT']
      : ['DOWN', 'UP', 'LEFT', 'RIGHT'];

  const platforms = [{ x: 0, y: 560, w: 1024, h: 80 }];
  const crystalCount = 2 + Math.min(4, Math.floor((levelNumber - 1) / 18));

  for (let i = 0; i < 4 + Math.min(6, Math.floor(levelNumber / 12)); i += 1) {
    const slope = (levelNumber * 17 + i * 31) % 120;
    const x = 100 + i * (150 + ((levelNumber * 21 + i * 41) % 70));
    const y = 520 - (i * 52) - (levelNumber % 5) * 8 - (i % 2) * 25 - (slope % 30) * 0.4;
    const w = 120 + ((levelNumber + i * 9) % 70);
    if (x + w < 980) {
      platforms.push({ x, y, w, h: 18 });
    }
  }

  const goalX = clamp(860 - ((levelNumber * 7) % 120), 760, 930);
  const goalY = Math.max(120, 150 - ((levelNumber - 1) % 6) * 8);

  const crystals = [];
  for (let i = 0; i < crystalCount; i += 1) {
    const px = platforms[(i % (platforms.length - 1)) + 1];
    const x = clamp((px.x + px.w / 2) + ((i % 2 === 0 ? -1 : 1) * 40) + (levelNumber % 7) * 2, 120, 900);
    const y = clamp(px.y - 28 - (i % 3) * 12, 80, 520);
    crystals.push({ x, y });
  }

  const hazards = [];
  if (levelNumber % 2 === 0) {
    hazards.push({ x: 320 + (levelNumber * 19 % 240), y: 560, w: 110 + (levelNumber % 4) * 18, h: 20 });
  }
  if (levelNumber % 3 === 0) {
    hazards.push({ x: 620 + (levelNumber * 7 % 150), y: 560, w: 90 + (levelNumber % 5) * 12, h: 20 });
  }
  if (levelNumber >= 20 && levelNumber % 5 === 0) {
    hazards.push({ x: 440 + (levelNumber % 7) * 30, y: 430, w: 90, h: 20 });
  }

  return {
    id: levelNumber,
    name: `${levelLabel} ${levelNumber}`,
    allowedGravity,
    playerStart: { x: 70, y: 500 },
    goal: { x: goalX, y: goalY, r: 22 + (levelNumber % 3) },
    crystals,
    platforms,
    hazards
  };
}

const levelData = Array.from({ length: TOTAL_LEVELS }, (_, index) => buildLevel(index + 1));

const controls = {
  left: false,
  right: false,
  jump: false
};

const game = {
  currentLevel: 0,
  highestUnlockedLevel: 1,
  gravity: 'DOWN',
  score: 0,
  crystals: 0,
  totalCrystals: 2,
  health: 100,
  shiftTimer: 6,
  won: false,
  gameOver: false,
  externalControllerConnected: true,
  controlMode: 'External Controller Connected',
  intervalId: null,
  levelStartTime: 0,
  levelCompletionMs: 0,
  attemptId: null,
  playerSessionId: null,
  playerIdentity: null,
  player: null,
  loggedIn: false,
  pendingSync: false,
  externalLastSeen: 0,
  controllerCode: String(Math.floor(100000 + Math.random() * 900000)),
  controllerSocket: null
};

function setDebugText(message) {
  if (debugText) {
    debugText.textContent = message;
  }
}


function getPendingCompletions() {
  try { return JSON.parse(localStorage.getItem('gs_pending_completions') || '[]'); } catch (_) { return []; }
}
function setPendingCompletions(items) {
  try { localStorage.setItem('gs_pending_completions', JSON.stringify(items)); } catch (_) {}
}
function queueOfflineCompletion(payload) {
  const queue = getPendingCompletions();
  if (!queue.some(item => item.idempotency_key === payload.idempotency_key)) {
    queue.push(payload);
    setPendingCompletions(queue);
  }
  game.pendingSync = true;
  setDebugText('Offline result saved locally; it will sync automatically when connected.');
}
async function syncPendingCompletions() {
  if (!navigator.onLine || !game.playerSessionId) return;
  const queue = getPendingCompletions();
  if (!queue.length) { game.pendingSync = false; return; }
  const remaining = [];
  for (const item of queue) {
    try {
      let attemptId = item.attempt_id;
      if (!attemptId || String(attemptId).startsWith('OFFLINE-')) {
        const startResponse = await fetch('/api/levels/start', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            session_id: game.playerSessionId,
            level_number: item.level_number,
            control_method: item.control_method,
            connection_status: 'Offline recovery',
            game_version: GAME_VERSION,
            client_started_at: item.level_started_at,
            offline_recovery: true,
            metadata: { recovered_offline: true }
          })
        });
        if (!startResponse.ok) throw new Error('Unable to create recovery attempt.');
        const startData = await startResponse.json();
        attemptId = startData.attempt.attempt_id;
      }
      const response = await fetch('/api/levels/complete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...item,
          attempt_id: attemptId,
          session_id: game.playerSessionId,
          connection_status: 'Reconnected / offline recovery',
          game_version: GAME_VERSION,
          idempotency_key: item.idempotency_key
        })
      });
      if (!response.ok) throw new Error('Completion sync failed.');
    } catch (_) {
      remaining.push(item);
    }
  }
  setPendingCompletions(remaining);
  game.pendingSync = remaining.length > 0;
  if (!remaining.length) setDebugText('Offline completion records synchronized with the backend.');
}

async function loginPlayer(participant) {
  const response = await fetch('/api/player/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ participant })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Unable to register participant.');
  game.playerSessionId = data.player.session_id;
  game.playerIdentity = data.player;
  game.loggedIn = true;
  participantInput.value = data.player.display_name;
  participantInput.readOnly = true;
  playerLoginModal?.classList.add('hidden');
  setDebugText(`Player ready: ${data.player.display_name}`);
  await syncPendingCompletions();
  await beginBackendAttempt();
}

async function beginBackendAttempt() {
  if (!game.loggedIn || !game.playerSessionId || !navigator.onLine) return;
  try {
    const response = await fetch('/api/levels/start', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: game.playerSessionId,
        level_number: game.currentLevel + 1,
        control_method: game.controlMode,
        connection_status: navigator.onLine ? 'online' : 'offline',
        game_version: GAME_VERSION
      })
    });
    if (!response.ok) throw new Error('Level start could not be registered.');
    const data = await response.json();
    game.attemptId = data.attempt.attempt_id;
    game.levelStartTime = performance.now();
    game.backendLevelStartTime = data.attempt.started_at;
  } catch (_) {
    game.attemptId = `OFFLINE-${crypto.randomUUID?.() || `${Date.now()}-${Math.random()}`}`;
    game.backendLevelStartTime = new Date().toISOString();
  }
}

async function recordLevelCompletion() {
  const levelNumber = game.currentLevel + 1;
  const idempotencyKey = `COMPLETE-${game.playerSessionId || 'guest'}-${game.attemptId || `${levelNumber}-${Date.now()}`}`;
  const payload = {
    attempt_id: game.attemptId,
    level_number: levelNumber,
    completion_time_ms: Math.max(100, Math.floor(game.levelCompletionMs)),
    score: game.score,
    control_method: game.controlMode,
    external_controller_used: game.externalControllerConnected ? 1 : 0,
    connection_status: game.controlMode,
    game_version: GAME_VERSION,
    level_started_at: game.backendLevelStartTime || new Date(Date.now() - game.levelCompletionMs).toISOString(),
    idempotency_key: idempotencyKey
  };

  if (!navigator.onLine || !game.attemptId || String(game.attemptId).startsWith('OFFLINE-')) {
    queueOfflineCompletion({ ...payload, level_started_at: new Date(Date.now() - game.levelCompletionMs).toISOString() });
    return { offline: true };
  }

  try {
    const response = await fetch('/api/levels/complete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!response.ok) throw new Error((await response.json().catch(() => ({}))).error || 'Unable to record completion.');
    const data = await response.json();
    await loadLeaderboard(levelNumber, data.rank);
    return data;
  } catch (_) {
    queueOfflineCompletion({ ...payload, level_started_at: new Date(Date.now() - game.levelCompletionMs).toISOString() });
    return { offline: true };
  }
}

function showLoading(show) {
  if (!loadingOverlay) return;
  loadingOverlay.classList.toggle('hidden', !show);
}

function showLevelCompletePanel(show) {
  if (!levelCompleteModal) return;
  levelCompleteModal.classList.toggle('hidden', !show);
}

async function showLevelResult(type) {
  const hasNextLevel = game.currentLevel < levelData.length - 1;
  const isWin = type === 'win';
  const isFinalWin = isWin && !hasNextLevel;

  game.won = isWin;
  game.gameOver = !isWin;

  const completePanel = document.querySelector('.level-complete-panel');
  if (completePanel) completePanel.classList.toggle('winner', isFinalWin);

  if (levelResultTitle) {
    levelResultTitle.textContent = isWin ? (isFinalWin ? 'YOU WIN THE GAME!' : 'LEVEL CLEAR!') : 'GAME OVER';
  }

  if (levelResultMessage) {
    levelResultMessage.textContent = isWin
      ? (isFinalWin
        ? 'You completed all 100 levels. Your final event result has been recorded.'
        : `Level ${game.currentLevel + 1} completed in ${formatTime(game.levelCompletionMs)}.`)
      : 'You ran out of health. Try again to beat this level.';
  }

  if (replayLevelBtn) replayLevelBtn.textContent = isWin ? (isFinalWin ? 'Play Again' : 'Replay Level') : 'Try Again';
  if (nextLevelBtn) {
    const canAdvance = isWin && hasNextLevel;
    nextLevelBtn.disabled = !canAdvance;
    nextLevelBtn.classList.toggle('hidden', !isWin || isFinalWin);
    nextLevelBtn.textContent = hasNextLevel ? 'Next Level' : 'Final Level';
  }

  if (isWin) {
    audio.playWinSound();
    const completion = await recordLevelCompletion();
    if (completion?.offline) {
      if (levelLeaderboardSummary) levelLeaderboardSummary.textContent = 'Result saved offline — rank will appear after synchronization.';
    } else {
      if (levelLeaderboardSummary) {
        levelLeaderboardSummary.textContent = `Current Level ${game.currentLevel + 1} Rank: #${completion.rank}`;
      }
      renderLeaderboard(completion.top10 || []);
    }
    if (isFinalWin) {
      document.querySelector('.level-complete-panel')?.classList.add('final-celebration');
      if (finalStats) {
        finalStats.textContent = `${game.playerIdentity?.display_name || participantInput.value} • 100/100 Levels Completed • Total Score ${game.score} • Final Level ${formatTime(game.levelCompletionMs)}`;
      }
    }
  } else {
    audio.playLoseSound();
  }

  showLevelCompletePanel(true);
}


function makePlayer(x, y) {
  return {
    x, y,
    w: 26,
    h: 38,
    vx: 0,
    vy: 0,
    grounded: false,
    facing: 1
  };
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

const audio = {
  ctx: null,

  init() {
    if (!this.ctx) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
      }
    }

    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  },

  tone({ frequency = 440, duration = 0.18, type = 'sine', volume = 0.05, sweep = 0 }) {
    if (!this.ctx) return;

    const oscillator = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(frequency, this.ctx.currentTime);

    if (sweep !== 0) {
      oscillator.frequency.linearRampToValueAtTime(
        frequency + sweep,
        this.ctx.currentTime + duration
      );
    }

    gainNode.gain.setValueAtTime(0.0001, this.ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(volume, this.ctx.currentTime + 0.02);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

    oscillator.connect(gainNode);
    gainNode.connect(this.ctx.destination);
    oscillator.start();
    oscillator.stop(this.ctx.currentTime + duration);
  },

  playWinSound() {
    this.init();
    if (!this.ctx) return;
    this.tone({ frequency: 660, duration: 0.12, type: 'triangle', volume: 0.05, sweep: 120 });
    setTimeout(() => {
      this.tone({ frequency: 880, duration: 0.16, type: 'triangle', volume: 0.05, sweep: 140 });
    }, 90);
  },

  playLoseSound() {
    this.init();
    if (!this.ctx) return;
    this.tone({ frequency: 260, duration: 0.25, type: 'sawtooth', volume: 0.05, sweep: -180 });
  }
};

function rectIntersect(a, b) {
  return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
}

function setControlMode(mode) {
  const isValidMode = ['External Controller Connected', 'Backup Controls Active', 'External Controller Reconnected'].includes(mode);
  if (!isValidMode) return;

  game.controlMode = mode;
  const controlModeValue = document.getElementById('controlModeValue');
  if (controlModeValue) {
    controlModeValue.textContent = mode;
    controlModeValue.style.color = mode === 'Backup Controls Active' ? '#ffbd66' : '#68f7d0';
  }
}

function updateHUD() {
  document.getElementById('hud-score').textContent = String(game.score);
  document.getElementById('hud-crystals').textContent = String(game.crystals);
  document.getElementById('gravity-indicator').textContent = `GRAVITY: ${game.gravity}`;
  document.getElementById('hud-gravity').textContent = `GRAVITY: ${game.gravity}`;
  document.getElementById('shift-text').textContent = `SHIFT IN: ${Math.ceil(game.shiftTimer)}s`;
  document.getElementById('health-fill').style.width = `${Math.max(0, game.health)}%`;

  const hasNextLevel = game.currentLevel < levelData.length - 1;
  if (nextLevelBtn) {
    if (game.won) {
      nextLevelBtn.disabled = !hasNextLevel;
      nextLevelBtn.textContent = hasNextLevel ? 'Next Level' : 'Final Level';
      nextLevelBtn.classList.toggle('hidden', !game.won);
    } else {
      nextLevelBtn.disabled = true;
      nextLevelBtn.classList.add('hidden');
    }
  }
}

function getSafeLevelIndex(levelIndex) {
  const normalized = Number(levelIndex);
  if (!Number.isFinite(normalized)) return 0;
  return clamp(Math.floor(normalized), 0, Math.max(levelData.length - 1, 0));
}

function resetLevel(levelIndex = game.currentLevel) {
  const safeIndex = getSafeLevelIndex(levelIndex);
  const level = levelData[safeIndex];

  if (!level) {
    setDebugText('Level data unavailable');
    return;
  }

  game.currentLevel = safeIndex;
  game.gravity = 'DOWN';
  game.health = 100;
  const freshLevel = buildLevel(level.id);
  level.crystals = freshLevel.crystals;
  level.platforms = freshLevel.platforms;
  level.hazards = freshLevel.hazards;
  game.shiftTimer = 6;
  game.won = false;
  game.gameOver = false;
  showLevelCompletePanel(false);
  game.levelStartTime = performance.now();
  game.levelCompletionMs = 0;
  if (nextLevelBtn) {
    nextLevelBtn.classList.remove('hidden');
    nextLevelBtn.disabled = true;
    nextLevelBtn.textContent = 'Next Level';
  }
  game.player = makePlayer(level.playerStart.x, level.playerStart.y);
  game.totalCrystals = level.crystals.length;
  game.crystals = 0;

  if (game.score === 0 || game.currentLevel === 0) {
    game.score = 0;
  }

  document.getElementById('level-name').textContent = `${level.id}. ${level.name}`;
  document.querySelectorAll('.level-btn').forEach((button) => {
    const buttonLevel = Number(button.dataset.level);
    const available = buttonLevel <= Math.min(game.highestUnlockedLevel, levelData.length);
    button.disabled = !available;
    button.classList.toggle('current', buttonLevel === level.id);
    button.classList.toggle('locked', !available);
    button.style.opacity = available ? '1' : '0.45';
  });
  updateHUD();
  setDebugText(`Level ${level.id}: ${level.name}`);
  if (game.loggedIn) {
    beginBackendAttempt();
  }
}

function setGravity(dir) {
  const level = levelData[game.currentLevel];
  if (!level.allowedGravity.includes(dir)) return;
  game.gravity = dir;
  updateHUD();
}

function triggerJump() {
  const player = game.player;
  if (!player.grounded) return;

  if (game.gravity === 'DOWN') player.vy = -10.5;
  if (game.gravity === 'UP') player.vy = 10.5;
  if (game.gravity === 'LEFT') player.vx = 10.5;
  if (game.gravity === 'RIGHT') player.vx = -10.5;

  player.grounded = false;
}

function handleMovementInput() {
  const player = game.player;

  if (controls.left) {
    player.vx = -3.2;
    player.facing = -1;
  } else if (controls.right) {
    player.vx = 3.2;
    player.facing = 1;
  } else {
    player.vx *= 0.78;
    if (Math.abs(player.vx) < 0.1) player.vx = 0;
  }

  if (controls.jump) {
    triggerJump();
    controls.jump = false;
  }
}

function movePlayer() {
  const player = game.player;
  const level = levelData[game.currentLevel];
  const gravityVector = {
    DOWN: { x: 0, y: 0.45 },
    UP: { x: 0, y: -0.45 },
    LEFT: { x: -0.45, y: 0 },
    RIGHT: { x: 0.45, y: 0 }
  };

  const g = gravityVector[game.gravity];
  player.vx += g.x;
  player.vy += g.y;

  const maxSpeed = 7;
  if (Math.abs(player.vx) > maxSpeed) player.vx = Math.sign(player.vx) * maxSpeed;
  if (Math.abs(player.vy) > 11) player.vy = Math.sign(player.vy) * 11;

  player.x += player.vx;
  for (const platform of level.platforms) {
    if (rectIntersect(player, platform)) {
      if (player.vx > 0) player.x = platform.x - player.w;
      if (player.vx < 0) player.x = platform.x + platform.w;
      player.vx = 0;
    }
  }

  player.y += player.vy;
  player.grounded = false;

  for (const platform of level.platforms) {
    if (rectIntersect(player, platform)) {
      if (player.vy > 0 && game.gravity === 'DOWN') {
        player.y = platform.y - player.h;
        player.vy = 0;
        player.grounded = true;
      } else if (player.vy < 0 && game.gravity === 'UP') {
        player.y = platform.y + platform.h;
        player.vy = 0;
        player.grounded = true;
      } else if (player.vx < 0 && game.gravity === 'LEFT') {
        player.x = platform.x + platform.w;
        player.vx = 0;
        player.grounded = true;
      } else if (player.vx > 0 && game.gravity === 'RIGHT') {
        player.x = platform.x - player.w;
        player.vx = 0;
        player.grounded = true;
      }
    }
  }

  player.x = clamp(player.x, 0, canvas.width - player.w);
  player.y = clamp(player.y, 0, canvas.height - player.h);

  if (game.gravity === 'DOWN' && player.y >= canvas.height - player.h) {
    player.y = canvas.height - player.h;
    player.vy = 0;
    player.grounded = true;
  }

  if (game.gravity === 'UP' && player.y <= 0) {
    player.y = 0;
    player.vy = 0;
    player.grounded = true;
  }

  if (game.gravity === 'LEFT' && player.x <= 0) {
    player.x = 0;
    player.vx = 0;
    player.grounded = true;
  }

  if (game.gravity === 'RIGHT' && player.x >= canvas.width - player.w) {
    player.x = canvas.width - player.w;
    player.vx = 0;
    player.grounded = true;
  }

  collectCrystals();
  checkGoal();
  checkHazards();
}

function collectCrystals() {
  const level = levelData[game.currentLevel];
  const player = game.player;

  for (let i = level.crystals.length - 1; i >= 0; i -= 1) {
    const crystal = level.crystals[i];
    const dx = player.x + player.w / 2 - crystal.x;
    const dy = player.y + player.h / 2 - crystal.y;
    if (Math.hypot(dx, dy) < 28) {
      level.crystals.splice(i, 1);
      game.crystals += 1;
      game.score += 100;
      updateHUD();
    }
  }
}

function checkGoal() {
  const level = levelData[game.currentLevel];
  const player = game.player;
  const goal = level.goal;

  const hitGoal = Math.hypot(player.x + player.w / 2 - goal.x, player.y + player.h / 2 - goal.y) < 42;
  if (hitGoal && game.crystals >= game.totalCrystals && !game.won && !game.gameOver) {
    game.levelCompletionMs = Math.max(0, performance.now() - game.levelStartTime);
    game.score += 250;
    game.highestUnlockedLevel = Math.min(levelData.length, Math.max(game.highestUnlockedLevel, level.id + 1));
    updateHUD();
    setDebugText(`Goal reached on ${level.name} in ${formatTime(game.levelCompletionMs)}`);
    showLevelResult('win');
  }
}

function checkHazards() {
  const level = levelData[game.currentLevel];
  const player = game.player;

  for (const hazard of level.hazards) {
    if (rectIntersect(player, hazard)) {
      game.health = Math.max(0, game.health - 10);
      updateHUD();
      player.x = level.playerStart.x;
      player.y = level.playerStart.y;
      player.vx = 0;
      player.vy = 0;

      if (game.health <= 0) {
        game.gameOver = true;
        showLevelResult('gameover');
      }
    }
  }
}

function drawGrid() {
  ctx.strokeStyle = 'rgba(73, 221, 255, 0.30)';
  ctx.lineWidth = 1;

  for (let x = 0; x <= canvas.width; x += 32) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }

  for (let y = 0; y <= canvas.height; y += 32) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
}

function drawPlatform(platform) {
  ctx.fillStyle = 'rgba(15, 31, 42, 0.5)';
  ctx.strokeStyle = '#46d6ff';
  ctx.lineWidth = 2;
  ctx.fillRect(platform.x, platform.y, platform.w, platform.h);
  ctx.strokeRect(platform.x, platform.y, platform.w, platform.h);
}

function drawCrystal(crystal) {
  ctx.save();
  ctx.translate(crystal.x, crystal.y);
  ctx.fillStyle = '#4ed8ff';
  ctx.beginPath();
  ctx.moveTo(0, -12);
  ctx.lineTo(10, 0);
  ctx.lineTo(0, 12);
  ctx.lineTo(-10, 0);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

function drawGoal(goal) {
  ctx.save();
  ctx.translate(goal.x, goal.y);
  ctx.fillStyle = '#de8af9';
  ctx.beginPath();
  ctx.arc(0, 0, goal.r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawHazard(hazard) {
  ctx.fillStyle = '#ff5a41';
  const triW = hazard.w / 3;
  for (let i = 0; i < 3; i += 1) {
    ctx.beginPath();
    ctx.moveTo(hazard.x + i * triW, hazard.y + hazard.h);
    ctx.lineTo(hazard.x + i * triW + triW / 2, hazard.y);
    ctx.lineTo(hazard.x + i * triW + triW, hazard.y + hazard.h);
    ctx.closePath();
    ctx.fill();
  }
}

function drawPlayer() {
  const player = game.player;
  ctx.fillStyle = '#1bcfff';
  ctx.fillRect(player.x + 8, player.y, player.w - 16, player.h - 10);

  ctx.fillStyle = '#3f1f2b';
  ctx.fillRect(player.x + 6, player.y + 10, 4, 4);
  ctx.fillRect(player.x + player.w - 10, player.y + 10, 4, 4);

  ctx.fillStyle = '#f5d4a5';
  ctx.fillRect(player.x + 13, player.y + 6, player.w - 26, 8);

  ctx.fillStyle = '#000';
  ctx.fillRect(player.x + 6, player.y + player.h - 4, 5, 4);
  ctx.fillRect(player.x + player.w - 11, player.y + player.h - 4, 5, 4);
}

function drawHUDText() {
  ctx.fillStyle = '#dff9ff';
  ctx.font = 'bold 13px Segoe UI';
  ctx.fillText(`LEVEL ${game.currentLevel + 1}`, 22, 30);
  ctx.fillText(`CRYSTALS ${game.crystals}/${game.totalCrystals}`, 22, 52);
}

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();

  const level = levelData[game.currentLevel];
  level.platforms.forEach(drawPlatform);
  level.hazards.forEach(drawHazard);
  drawGoal(level.goal);
  level.crystals.forEach(drawCrystal);
  drawPlayer();
  drawHUDText();

  if (game.won) {
    const finalGameWin = game.currentLevel === levelData.length - 1;
    const bannerWidth = finalGameWin ? 560 : 500;
    const bannerX = (canvas.width - bannerWidth) / 2;
    const panelY = 210;

    ctx.fillStyle = 'rgba(5, 15, 25, 0.75)';
    ctx.fillRect(bannerX, panelY, bannerWidth, 130);
    ctx.strokeStyle = finalGameWin ? '#ffd76a' : '#5ee3ff';
    ctx.strokeRect(bannerX, panelY, bannerWidth, 130);
    ctx.fillStyle = finalGameWin ? '#ffd76a' : '#dffaff';
    ctx.font = finalGameWin ? 'bold 30px Segoe UI' : 'bold 36px Segoe UI';
    ctx.textAlign = 'center';
    ctx.fillText(finalGameWin ? 'YOU WIN THE GAME!' : 'LEVEL CLEAR!', canvas.width / 2, 280);
    ctx.font = '18px Segoe UI';
    ctx.fillText(finalGameWin ? 'The full challenge is complete.' : 'Press R to restart or select another level.', canvas.width / 2, 315);
    ctx.textAlign = 'left';
  }
}

function updateGameLoop() {
  const level = levelData[game.currentLevel];

  if (!game.loggedIn) {
    render();
    return;
  }

  if (!game.won && !game.gameOver) {
    handleMovementInput();
    movePlayer();
    game.shiftTimer = Math.max(0, game.shiftTimer - 0.016);
  }

  if (game.shiftTimer <= 0) {
    const options = ['DOWN', 'UP', 'LEFT', 'RIGHT'];
    const currentIndex = options.indexOf(game.gravity);
    const nextGravity = options[(currentIndex + 1) % options.length];
    if (level.allowedGravity.includes(nextGravity)) {
      setGravity(nextGravity);
    }
    game.shiftTimer = 6;
  }

  updateHUD();
  render();
}

function handleButtonAction(action, isMiniDirection = false) {
  if (isMiniDirection) {
    if (action === 'up') setGravity('UP');
    if (action === 'down') setGravity('DOWN');
    if (action === 'left') setGravity('LEFT');
    if (action === 'right') setGravity('RIGHT');
    return;
  }

  if (action === 'left') controls.left = true;
  if (action === 'right') controls.right = true;
  if (action === 'jump') controls.jump = true;
}

function populateLevelButtons() {
  const levelList = document.querySelector('.level-list');
  if (!levelList) return;

  levelList.innerHTML = '';

  for (let levelNumber = 1; levelNumber <= TOTAL_LEVELS; levelNumber += 1) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'level-btn';
    button.dataset.level = String(levelNumber);
    button.textContent = `L${levelNumber}`;
    const isLocked = levelNumber > game.highestUnlockedLevel;
    button.disabled = isLocked;
    button.classList.toggle('locked', isLocked);
    button.style.opacity = isLocked ? '0.45' : '1';
    button.addEventListener('click', () => {
      audio.init();
      if (isLocked) {
        return;
      }
      resetLevel(levelNumber - 1);
    });
    levelList.appendChild(button);
  }
}

function formatTime(ms) {
  const safeMs = Number(ms || 0);
  const totalSeconds = Math.max(0, Math.floor(safeMs / 1000));
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  const hundredths = Math.floor((safeMs % 1000) / 10);
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}.${String(hundredths).padStart(2, '0')}`;
}

function renderLeaderboardRows(target, rows = []) {
  if (!target) return;
  target.innerHTML = '';
  if (!rows.length) {
    const emptyItem = document.createElement('li');
    emptyItem.className = 'leaderboard-empty';
    emptyItem.innerHTML = '<span class="rank">—</span><span class="name">No completed records yet</span><span class="score">--:--.--</span>';
    target.appendChild(emptyItem);
    return;
  }
  rows.slice(0, 10).forEach((entry, index) => {
    const item = document.createElement('li');
    const rank = Number(entry.rank ?? index + 1);
    item.className = `leaderboard-row rank-${rank}`;
    if (rank <= 3) item.classList.add('podium');
    const rankSpan = document.createElement('span');
    rankSpan.className = 'rank';
    rankSpan.textContent = rank === 1 ? '🥇 1' : rank === 2 ? '🥈 2' : rank === 3 ? '🥉 3' : `#${rank}`;
    const identity = document.createElement('div');
    identity.className = 'leaderboard-identity';
    const nameSpan = document.createElement('span');
    nameSpan.className = 'name';
    nameSpan.textContent = entry.player_name || entry.display_name || 'Player';
    const companySpan = document.createElement('small');
    companySpan.className = 'company';
    companySpan.textContent = entry.company_name || '';
    identity.append(nameSpan, companySpan);
    const details = document.createElement('div');
    details.className = 'leaderboard-details';
    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'score';
    scoreSpan.textContent = formatTime(entry.completion_time_ms);
    const timeSpan = document.createElement('small');
    timeSpan.className = 'timestamp';
    timeSpan.textContent = entry.completed_at ? new Date(entry.completed_at).toLocaleString() : '';
    details.append(scoreSpan, timeSpan);
    item.append(rankSpan, identity, details);
    target.appendChild(item);
  });
}
function renderLeaderboard(rows = []) {
  renderLeaderboardRows(leaderboardList, rows);
  renderLeaderboardRows(document.getElementById('completionLeaderboardList'), rows);
}


async function loadLeaderboard(levelNumber = game.currentLevel + 1, currentRank = null) {
  const requestId = ++leaderboardRequestToken;
  try {
    const response = await fetch(`/api/leaderboard/level/${Number(levelNumber)}`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Leaderboard unavailable.');
    const data = await response.json();
    if (requestId !== leaderboardRequestToken) return;
    const heading = document.querySelector('.panel-header h3');
    if (heading) heading.textContent = `Level ${Number(levelNumber)} • ${levelData[Number(levelNumber) - 1]?.name || 'Leaderboard'} • Top 10`;
    renderLeaderboard(data.leaderboard || []);
    if (levelLeaderboardSummary) {
      levelLeaderboardSummary.textContent = currentRank
        ? `Your Level ${Number(levelNumber)} Rank: #${currentRank}`
        : `Level ${Number(levelNumber)} Top 10`;
    }
  } catch (error) {
    if (requestId === leaderboardRequestToken) {
      renderLeaderboard([]);
      const heading = document.querySelector('.panel-header h3');
      if (heading) heading.textContent = `Level ${Number(levelNumber)} • Leaderboard unavailable`;
      if (levelLeaderboardSummary) levelLeaderboardSummary.textContent = 'The leaderboard could not be loaded. Check that the game server is running.';
    }
  }
}


function toggleLeaderboard(show) {
  if (!leaderboardPanel) return;
  leaderboardPanel.classList.toggle('hidden', !show);
}

async function restorePlayerSession() {
  let sessionId = null;
  try { sessionId = localStorage.getItem('gs_player_session_id'); } catch (_) {}
  if (!sessionId) {
    playerLoginModal?.classList.remove('hidden');
    return false;
  }
  try {
    const response = await fetch(`/api/player/session/${encodeURIComponent(sessionId)}`, { cache: 'no-store' });
    if (!response.ok) throw new Error('Session expired.');
    const data = await response.json();
    game.playerSessionId = data.player.session_id;
    game.playerIdentity = data.player;
    game.loggedIn = true;
    participantInput.value = data.player.display_name;
    playerLoginModal?.classList.add('hidden');
    await syncPendingCompletions();
    await beginBackendAttempt();
    return true;
  } catch (_) {
    try { localStorage.removeItem('gs_player_session_id'); } catch (_) {}
    playerLoginModal?.classList.remove('hidden');
    return false;
  }
}

async function handlePlayerLogin(event) {
  event.preventDefault();
  const value = document.getElementById('playerParticipantInput')?.value.trim() || '';
  if (!value) {
    if (playerLoginStatus) playerLoginStatus.textContent = 'Enter Company Name - Player Name.';
    return;
  }
  try {
    if (playerLoginStatus) playerLoginStatus.textContent = 'Registering participant…';
    await loginPlayer(value);
    try { localStorage.setItem('gs_player_session_id', game.playerSessionId); } catch (_) {}
    if (playerLoginStatus) playerLoginStatus.textContent = '';
  } catch (error) {
    if (playerLoginStatus) playerLoginStatus.textContent = error.message || 'Unable to register participant.';
  }
}

function applyExternalAction(action, pressed = true) {
  game.externalLastSeen = Date.now();
  if (!navigator.onLine) return;
  setControlMode('External Controller Connected');
  if (action === 'shift-up' && pressed) {
    const options = ['DOWN', 'UP', 'LEFT', 'RIGHT'];
    const currentIndex = options.indexOf(game.gravity);
    setGravity(options[(currentIndex + 1) % options.length]);
    return;
  }
  if (['up', 'down'].includes(action) && pressed) {
    setGravity(action.toUpperCase());
    return;
  }
  if (action === 'left') controls.left = pressed;
  if (action === 'right') controls.right = pressed;
  if (action === 'jump') controls.jump = pressed;
}


function connectControllerSocket() {
  if (!window.WebSocket) return;
  if (controllerCodeEl) controllerCodeEl.textContent = game.controllerCode;
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  try {
    const socket = new WebSocket(`${protocol}//${location.host}/ws/controller?role=game&code=${game.controllerCode}`);
    game.controllerSocket = socket;
    socket.addEventListener('open', () => {
      setControlMode('Backup Controls Active');
    });
    socket.addEventListener('message', event => {
      try {
        const data = JSON.parse(event.data);
        if (data.source === 'gravity-shift-controller') {
          if (data.type === 'heartbeat') {
            game.externalLastSeen = Date.now();
            if (navigator.onLine) setControlMode('External Controller Connected');
          } else if (data.type === 'input') {
            applyExternalAction(String(data.action || ''), data.pressed !== false);
          }
        }
      } catch (_) {}
    });
    socket.addEventListener('close', () => {
      game.externalControllerConnected = false;
      setControlMode('Backup Controls Active');
      setTimeout(connectControllerSocket, 2000);
    });
    socket.addEventListener('error', () => {
      game.externalControllerConnected = false;
      setControlMode('Backup Controls Active');
    });
  } catch (_) {
    setControlMode('Backup Controls Active');
  }
}

function bindExternalController() {
  window.addEventListener('message', (event) => {
    const data = event.data || {};
    if (data.source !== 'gravity-shift-controller') return;
    if (data.type === 'heartbeat') {
      game.externalLastSeen = Date.now();
      if (navigator.onLine) setControlMode('External Controller Connected');
      return;
    }
    if (data.type === 'input') applyExternalAction(String(data.action || ''), data.pressed !== false);
  });
  window.addEventListener('gravity-shift-controller', (event) => {
    const data = event.detail || {};
    if (data.type === 'heartbeat') {
      game.externalLastSeen = Date.now();
      if (navigator.onLine) setControlMode('External Controller Connected');
    } else if (data.type === 'input') {
      applyExternalAction(String(data.action || ''), data.pressed !== false);
    }
  });
  setInterval(() => {
    if (!game.externalLastSeen || Date.now() - game.externalLastSeen > 5000) {
      game.externalControllerConnected = false;
      setControlMode('Backup Controls Active');
    } else {
      game.externalControllerConnected = true;
    }
  }, 1000);
}

function bindUI() {
  populateLevelButtons();
  game.externalLastSeen = 0;
  game.externalControllerConnected = false;
  setControlMode('Backup Controls Active');
  bindExternalController();
  setInterval(syncPendingCompletions, 5000);
  connectControllerSocket();
  loadLeaderboard();
  restorePlayerSession();

  window.addEventListener('online', async () => {
    await syncPendingCompletions();
    setControlMode(game.externalLastSeen && Date.now() - game.externalLastSeen < 5000
      ? 'External Controller Reconnected'
      : 'Backup Controls Active');
    if (game.loggedIn && !game.won && !game.gameOver) await beginBackendAttempt();
  });

  window.addEventListener('offline', () => {
    game.externalControllerConnected = false;
    setControlMode('Backup Controls Active');
  });

  document.getElementById('leaderboardBtn')?.addEventListener('click', async () => {
    showLevelCompletePanel(false);
    toggleLeaderboard(true);
    await loadLeaderboard(game.currentLevel + 1);
  });
  document.getElementById('closeLeaderboardBtn')?.addEventListener('click', () => toggleLeaderboard(false));
  document.getElementById('adminLoginBtn')?.addEventListener('click', () => {
    window.location.href = '/admin';
  });
  playerLoginForm?.addEventListener('submit', handlePlayerLogin);

  document.querySelectorAll('.control-btn, .mini-btn').forEach((button) => {
    const press = (event) => {
      event.preventDefault();
      audio.init();
      const action = button.dataset.action;
      const isMiniDirection = button.classList.contains('mini-btn');
      if (action === 'shift-up') {
        const options = ['DOWN', 'UP', 'LEFT', 'RIGHT'];
        const currentIndex = options.indexOf(game.gravity);
        setGravity(options[(currentIndex + 1) % options.length]);
        return;
      }
      if (isMiniDirection) {
        handleButtonAction(action, true);
      } else if (['left', 'right', 'jump'].includes(action)) {
        handleButtonAction(action, false);
      }
    };
    const release = () => {
      const action = button.dataset.action;
      if (action === 'left') controls.left = false;
      if (action === 'right') controls.right = false;
      if (action === 'jump') controls.jump = false;
    };
    button.addEventListener('pointerdown', press);
    button.addEventListener('pointerup', release);
    button.addEventListener('pointercancel', release);
    button.addEventListener('pointerleave', release);
  });

  replayLevelBtn.addEventListener('click', () => {
    audio.init();
    resetLevel(game.currentLevel);
  });

  nextLevelBtn.addEventListener('click', () => {
    audio.init();
    if (!game.won || game.gameOver) {
      setDebugText('You must win the level before continuing.');
      return;
    }

    if (game.currentLevel < levelData.length - 1) {
      resetLevel(game.currentLevel + 1);
      return;
    }

    setDebugText('Final level complete');
    showLevelCompletePanel(false);
  });

  window.addEventListener('keydown', (event) => {
    audio.init();
    const key = event.key.toLowerCase();
    if (event.key === 'ArrowLeft' || key === 'a') controls.left = true;
    if (event.key === 'ArrowRight' || key === 'd') controls.right = true;
    if (event.key === ' ' || event.key === 'ArrowUp' || key === 'w') {
      controls.jump = true;
      event.preventDefault();
    }
    if (event.key === '1') setGravity('DOWN');
    if (event.key === '2') setGravity('UP');
    if (event.key === '3') setGravity('LEFT');
    if (event.key === '4') setGravity('RIGHT');
    if (key === 'r') resetLevel(game.currentLevel);
  });

  window.addEventListener('keyup', (event) => {
    const key = event.key.toLowerCase();
    if (event.key === 'ArrowLeft' || key === 'a') controls.left = false;
    if (event.key === 'ArrowRight' || key === 'd') controls.right = false;
  });

  fullscreenButton.addEventListener('click', () => {
    const root = document.documentElement;
    if (!document.fullscreenElement) {
      root.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  });
}

function init() {
  showLoading(true);
  bindUI();
  resetLevel(0);
  showLoading(false);
  setDebugText('Gravity Shift loaded');
  game.intervalId = setInterval(updateGameLoop, 1000 / 60);
}

init();
