const $ = id => document.getElementById(id);

function formatTime(ms) {
  const n = Math.max(0, Number(ms || 0));
  const total = Math.floor(n / 1000);
  return `${String(Math.floor(total / 60)).padStart(2,'0')}:${String(total % 60).padStart(2,'0')}.${String(Math.floor((n % 1000) / 10)).padStart(2,'0')}`;
}
function esc(value) {
  const div = document.createElement('div');
  div.textContent = value ?? '';
  return div.innerHTML;
}
async function api(path, options = {}) {
  const response = await fetch(path, {
    cache: 'no-store',
    credentials: 'same-origin',
    ...options,
    headers: { ...(options.headers || {}) }
  });
  if (response.status === 401) {
    showLogin('Admin session expired. Please sign in again.');
    throw new Error('Unauthorized');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Request failed.');
  return data;
}
function showLogin(message = '') {
  $('loginView').classList.remove('hidden');
  $('dashboardView').classList.add('hidden');
  $('loginStatus').textContent = message;
}
function showDashboard(username, eventLive = false) {
  $('loginView').classList.add('hidden');
  $('dashboardView').classList.remove('hidden');
  $('adminUser').textContent = username || 'Authenticated organizer';
  const badge = $('eventModeBadge');
  const clearBtn = $('clearTestDataBtn');
  if (badge) {
    badge.textContent = eventLive ? 'EVENT LIVE' : 'TEST MODE';
    badge.classList.toggle('live', eventLive);
  }
  if (clearBtn) {
    clearBtn.disabled = eventLive;
    clearBtn.title = eventLive ? 'Disabled while EVENT_LIVE=true' : 'Clear all test records';
  }
}
function renderStats(stats) {
  showDashboard($('adminUser').textContent || 'Authenticated organizer', Boolean(stats.event_live));
  const c = stats.counts || {};
  $('statsGrid').innerHTML = [
    ['Completed level records', c.completed_records],
    ['Level attempts', c.attempts],
    ['Players', c.players],
    ['Companies', c.companies]
  ].map(([label,value]) => `<div class="stat"><span>${label}</span><strong>${Number(value||0).toLocaleString()}</strong></div>`).join('');
}
function renderTop10(rows) {
  $('top10Body').innerHTML = rows.map(r => `<tr class="${Number(r.rank)<=3?'podium-row':''}">
    <td><strong>${r.rank}</strong></td><td>${esc(r.company_name)}</td><td>${esc(r.player_name)}</td>
    <td><strong>${formatTime(r.completion_time_ms)}</strong></td><td>${esc(r.completed_at)}</td><td class="mono">${esc(r.game_id)}</td>
  </tr>`).join('') || '<tr><td colspan="6">No completed records for this level.</td></tr>';
}
function renderHistory(rows) {
  $('historyBody').innerHTML = rows.map(r => `<tr>
    <td class="mono">${esc(r.game_id)}</td><td>${r.level_number}</td><td>${esc(r.company_name)}</td><td>${esc(r.player_name)}</td>
    <td>${formatTime(r.completion_time_ms)}</td><td>${Number(r.score||0).toLocaleString()}</td>
    <td>${esc(r.level_start_time)}</td><td>${esc(r.completed_at)}</td><td>${esc(r.control_method)}</td><td>${esc(r.connection_status)}</td>
  </tr>`).join('') || '<tr><td colspan="10">No history.</td></tr>';
}
function renderCompanies(rows) {
  $('companiesBody').innerHTML = rows.map(r => `<tr><td>${esc(r.company_name)}</td><td>${r.completed_levels}</td><td>${r.unique_players}</td><td>${formatTime(r.best_completion_time_ms)}</td><td>${formatTime(r.average_completion_time_ms)}</td><td>${Number(r.total_score||0).toLocaleString()}</td></tr>`).join('');
}
function renderPlayers(rows) {
  $('playersBody').innerHTML = rows.map(r => `<tr><td>${esc(r.player_name)}</td><td>${esc(r.company_name)}</td><td>${r.completed_levels}</td><td>${formatTime(r.best_completion_time_ms)}</td><td>${formatTime(r.average_completion_time_ms)}</td><td>${Number(r.total_score||0).toLocaleString()}</td></tr>`).join('');
}
function renderAttempts(rows) {
  $('attemptsBody').innerHTML = rows.map(r => `<tr><td class="mono">${esc(r.attempt_id)}</td><td>${r.level_number}</td><td>${esc(r.company_name)}</td><td>${esc(r.player_name)}</td><td>${esc(r.status)}</td><td>${esc(r.started_at)}</td><td>${esc(r.completed_at||'')}</td><td>${r.completion_time_ms ? formatTime(r.completion_time_ms) : '—'}</td><td>${esc(r.control_method||'')}</td></tr>`).join('');
}
async function downloadTop10Csv() {
  const level = Number($('levelSelect').value || 1);
  try {
    const response = await fetch(`/api/admin/leaderboard/level/${level}/csv`, { credentials: 'same-origin', cache: 'no-store' });
    if (response.status === 401) { showLogin('Admin session expired. Please sign in again.'); return; }
    if (!response.ok) { const data = await response.json().catch(() => ({})); throw new Error(data.error || 'CSV download failed.'); }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `gravity-shift-level-${level}-top-10.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  } catch (e) { $('levelSummary').textContent = e.message; }
}

async function clearTestData() {
  const status = $('clearTestStatus');
  if (!confirm('This permanently deletes all current test records. Continue?')) return;
  const confirmation = prompt('Type DELETE ALL TEST DATA to confirm:');
  if (confirmation !== 'DELETE ALL TEST DATA') {
    if (status) status.textContent = 'Cancelled.';
    return;
  }
  try {
    const data = await api('/api/admin/testing/clear', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({confirmation})
    });
    if (status) status.textContent = data.message;
    await loadDashboard();
  } catch (e) {
    if (status) status.textContent = e.message;
  }
}

async function loadLevel(level) {
  const data = await api(`/api/admin/leaderboard/level/${level}`);
  $('levelSummary').textContent = `Level ${level}: ${data.top10.length} visible Top 10 entries • ${data.history.length} permanent completed records • ${data.attempts.length} attempts`;
  renderTop10(data.top10);
  renderHistory(data.history);
  renderAttempts(data.attempts);
}
async function loadDashboard() {
  const [stats, companies, players, levels] = await Promise.all([
    api('/api/admin/stats'), api('/api/admin/companies'), api('/api/admin/players'), api('/api/admin/levels')
  ]);
  renderStats(stats); renderCompanies(companies.companies); renderPlayers(players.players);
  const select = $('levelSelect');
  select.innerHTML = Array.from({length: 100}, (_, i) => `<option value="${i+1}">Level ${i+1}</option>`).join('');
  select.addEventListener('change', () => loadLevel(Number(select.value)).catch(e => $('levelSummary').textContent = e.message));
  $('downloadTop10CsvBtn').addEventListener('click', downloadTop10Csv);
  await loadLevel(1);
}
$('loginForm').addEventListener('submit', async e => {
  e.preventDefault();
  $('loginStatus').textContent = 'Authenticating…';
  try {
    const response = await fetch('/api/admin/login', {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ username: $('username').value.trim(), password: $('password').value })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'Invalid credentials.');
    showDashboard(data.username); $('password').value = '';
    await loadDashboard();
  } catch (e) { showLogin(e.message); }
});
$('clearTestDataBtn')?.addEventListener('click', clearTestData);
$('logoutBtn').addEventListener('click', async () => {
  try { await api('/api/admin/logout', {method:'POST'}); } catch (_) {}
  showLogin('Signed out.');
});
(async function init() {
  try {
    const response = await fetch('/api/admin/stats', { cache: 'no-store', credentials: 'same-origin' });
    if (!response.ok) return showLogin();
    showDashboard('Authenticated organizer');
    const stats = await response.json();
    renderStats(stats);
    await loadDashboard();
  } catch (_) { showLogin(); }
})();
