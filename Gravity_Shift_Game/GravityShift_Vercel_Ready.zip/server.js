require('dotenv').config();

const express = require('express');
const http = require('http');
const { WebSocketServer, WebSocket } = require('ws');
const path = require('path');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');

const {
  ensureReady,
  normalizeParticipantName,
  createPlayerSession,
  getPlayerSession,
  startLevelAttempt,
  getAttempt,
  completeLevelAttempt,
  rankForRecord,
  getLevelRecords,
  getAllRecords,
  getAttemptRecords,
  getCompanyStats,
  getPlayerStats,
  getLevelStats,
  getCounts,
  clearTestData,
  sanitizeString,
  usePostgres
} = require('./db');

const app = express();
app.set('trust proxy', 1);
const port = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const GAME_VERSION = process.env.GAME_VERSION || '1.2.0';
const TOTAL_LEVELS = 100;

const adminUsername = sanitizeString(process.env.ADMIN_USERNAME || '');
const adminPassword = String(process.env.ADMIN_PASSWORD || '');
const adminSessionSecret = String(process.env.ADMIN_SESSION_SECRET || '');
const adminSessionTtlSeconds = 8 * 60 * 60;
const eventLive = String(process.env.EVENT_LIVE || 'false').toLowerCase() === 'true';

if (!adminUsername || !adminPassword || !adminSessionSecret) {
  console.warn('WARNING: Set ADMIN_USERNAME, ADMIN_PASSWORD and ADMIN_SESSION_SECRET in the backend environment.');
}

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.static(ROOT, { index: false }));

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false
});

function timingSafeEqualStrings(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (aa.length !== bb.length) return false;
  return crypto.timingSafeEqual(aa, bb);
}

function validAdminCredentials(username, password) {
  if (!adminUsername || !adminPassword || !adminSessionSecret) return false;
  return timingSafeEqualStrings(username, adminUsername) && timingSafeEqualStrings(password, adminPassword);
}

/*
  Stateless signed admin cookie.
  This is important on Vercel because a Map held by one server instance
  is not a durable session store. The secret remains backend-only.
*/
function signAdminPayload(payload) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const signature = crypto.createHmac('sha256', adminSessionSecret).update(body).digest('base64url');
  return `${body}.${signature}`;
}

function verifyAdminToken(token) {
  if (!token || !adminSessionSecret) return null;
  const parts = String(token).split('.');
  if (parts.length !== 2) return null;
  const [body, signature] = parts;
  const expected = crypto.createHmac('sha256', adminSessionSecret).update(body).digest('base64url');
  if (!timingSafeEqualStrings(signature, expected)) return null;
  try {
    const payload = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
    if (!payload.exp || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch (_) {
    return null;
  }
}

function readCookie(req, name) {
  const cookies = String(req.headers.cookie || '').split(';').map(v => v.trim());
  const prefix = `${name}=`;
  const found = cookies.find(v => v.startsWith(prefix));
  return found ? decodeURIComponent(found.slice(prefix.length)) : '';
}

function setAdminCookie(req, res, username) {
  const now = Math.floor(Date.now() / 1000);
  const token = signAdminPayload({ username, iat: now, exp: now + adminSessionTtlSeconds });
  const secure = req.secure || req.headers['x-forwarded-proto'] === 'https';
  res.setHeader(
    'Set-Cookie',
    `gs_admin_session=${encodeURIComponent(token)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${adminSessionTtlSeconds}${secure ? '; Secure' : ''}`
  );
}

function clearAdminCookie(res) {
  res.setHeader('Set-Cookie', 'gs_admin_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');
}

function requireAdmin(req, res, next) {
  const session = verifyAdminToken(readCookie(req, 'gs_admin_session'));
  if (!session) return res.status(401).json({ error: 'Admin session expired.' });
  req.admin = session;
  next();
}

function validateLevel(levelNumber) {
  const level = Number(levelNumber);
  if (!Number.isInteger(level) || level < 1 || level > TOTAL_LEVELS) {
    const error = new Error('Level must be an integer between 1 and 100.');
    error.statusCode = 400;
    throw error;
  }
  return level;
}

app.get('/api/health', async (req, res) => {
  try {
    await ensureReady();
    res.json({ ok: true, status: 'online', game_version: GAME_VERSION, database: usePostgres ? 'postgres' : 'sqlite-local' });
  } catch (error) {
    res.status(503).json({ ok: false, status: 'database-unavailable', error: error.message });
  }
});

app.post('/api/validate-name', (req, res) => {
  try {
    const value = req.body?.participant || req.body?.display_name ||
      `${req.body?.company_name || ''} - ${req.body?.player_name || ''}`;
    const parsed = normalizeParticipantName(value);
    res.json({ valid: true, ...parsed });
  } catch (error) {
    res.status(400).json({ valid: false, error: error.message });
  }
});

/* Player registration. This is not admin authentication. */
app.post('/api/player/login', async (req, res) => {
  try {
    const participant = req.body?.participant || '';
    const session = await createPlayerSession(participant);
    res.status(201).json({
      ok: true,
      player: {
        session_id: session.session_id,
        company_name: session.company_name,
        player_name: session.player_name,
        display_name: session.display_name
      }
    });
  } catch (error) {
    res.status(400).json({ ok: false, error: error.message });
  }
});

app.get('/api/player/session/:sessionId', async (req, res) => {
  try {
    const session = await getPlayerSession(req.params.sessionId);
    if (!session) return res.status(404).json({ error: 'Player session not found.' });
    res.json({ ok: true, player: session });
  } catch (error) {
    res.status(500).json({ error: 'Unable to read player session.' });
  }
});

app.post('/api/levels/start', async (req, res) => {
  try {
    const session = await getPlayerSession(req.body?.session_id);
    if (!session) return res.status(401).json({ error: 'Player login required.' });
    const level = validateLevel(req.body?.level_number);
    const attempt = await startLevelAttempt({
      session_id: session.session_id,
      level_number: level,
      control_method: req.body?.control_method,
      connection_status: req.body?.connection_status,
      game_version: req.body?.game_version || GAME_VERSION,
      metadata: req.body?.metadata,
      client_started_at: req.body?.client_started_at,
      offline_recovery: Boolean(req.body?.offline_recovery)
    });
    res.status(201).json({ ok: true, attempt });
  } catch (error) {
    res.status(error.statusCode || 400).json({ error: error.message || 'Unable to start level.' });
  }
});

app.post('/api/levels/complete', async (req, res) => {
  try {
    const attempt = await getAttempt(req.body?.attempt_id);
    if (!attempt) return res.status(404).json({ error: 'Level attempt not found.' });

    const result = await completeLevelAttempt({
      ...req.body,
      game_version: req.body?.game_version || GAME_VERSION,
      idempotency_key: req.body?.idempotency_key || attempt.attempt_id
    });

    const rank = await rankForRecord(result.record);
    const top10 = await getLevelRecords(result.record.level_number, 10);

    res.status(result.duplicate ? 200 : 201).json({
      ok: true,
      duplicate: result.duplicate,
      record: result.record,
      rank,
      level_number: result.record.level_number,
      top10
    });
  } catch (error) {
    res.status(400).json({ error: error.message || 'Unable to record level completion.' });
  }
});

/* Public: ONLY the requested level's Top 10. */
app.get('/api/leaderboard/level/:levelNumber', async (req, res) => {
  try {
    const level = validateLevel(req.params.levelNumber);
    const leaderboard = await getLevelRecords(level, 10);
    res.json({ level_number: level, leaderboard, total_visible: leaderboard.length });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/leaderboard/top10', async (req, res) => {
  try {
    const level = validateLevel(req.query.level || 1);
    const leaderboard = await getLevelRecords(level, 10);
    res.json({ level_number: level, leaderboard, total: leaderboard.length });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

/* Admin authentication. Credentials are read ONLY from backend environment variables. */
app.post('/api/admin/login', loginLimiter, (req, res) => {
  const username = sanitizeString(req.body?.username);
  const password = String(req.body?.password || '');
  if (!validAdminCredentials(username, password)) {
    return res.status(401).json({ ok: false, error: 'Invalid admin credentials.' });
  }
  setAdminCookie(req, res, username);
  res.json({ ok: true, authenticated: true, expires_in_seconds: adminSessionTtlSeconds, username });
});

app.post('/api/admin/logout', requireAdmin, (req, res) => {
  clearAdminCookie(res);
  res.json({ ok: true });
});

app.get('/api/admin/me', requireAdmin, (req, res) => {
  res.json({ ok: true, username: req.admin.username, event_live: eventLive });
});

app.get('/api/admin/leaderboard', requireAdmin, async (req, res) => {
  try {
    const level = req.query.level ? validateLevel(req.query.level) : null;
    const leaderboard = await getAllRecords({ levelNumber: level });
    res.json({ leaderboard, total: leaderboard.length });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/admin/leaderboard/level/:levelNumber', requireAdmin, async (req, res) => {
  try {
    const level = validateLevel(req.params.levelNumber);
    const [top10, history, attempts] = await Promise.all([
      getLevelRecords(level, 10),
      getAllRecords({ levelNumber: level }),
      getAttemptRecords({ levelNumber: level })
    ]);
    res.json({ level_number: level, top10, history, attempts, event_live: eventLive });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/admin/attempts', requireAdmin, async (req, res) => {
  try {
    const level = req.query.level ? validateLevel(req.query.level) : null;
    res.json({ attempts: await getAttemptRecords({ levelNumber: level }) });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/admin/companies', requireAdmin, async (req, res) => {
  try { res.json({ companies: await getCompanyStats() }); }
  catch (error) { res.status(500).json({ error: 'Unable to load company statistics.' }); }
});

app.get('/api/admin/players', requireAdmin, async (req, res) => {
  try { res.json({ players: await getPlayerStats() }); }
  catch (error) { res.status(500).json({ error: 'Unable to load player statistics.' }); }
});

app.get('/api/admin/levels', requireAdmin, async (req, res) => {
  try { res.json({ levels: await getLevelStats(), total_levels: TOTAL_LEVELS }); }
  catch (error) { res.status(500).json({ error: 'Unable to load level statistics.' }); }
});

app.get('/api/admin/stats', requireAdmin, async (req, res) => {
  try { res.json({ counts: await getCounts(), levels: await getLevelStats(), game_version: GAME_VERSION, event_live: eventLive }); }
  catch (error) { res.status(500).json({ error: 'Unable to load dashboard statistics.' }); }
});

function csvCell(value) {
  const text = String(value ?? '');
  const safe = /^[=+\-@]/.test(text) ? "'" + text : text;
  return '"' + safe.replace(/"/g, '""') + '"';
}

app.get('/api/admin/leaderboard/level/:levelNumber/csv', requireAdmin, async (req, res) => {
  try {
    const level = validateLevel(req.params.levelNumber);
    const rows = await getLevelRecords(level, 10);
    const header = ['Rank','Company Name','Player Name','Display Name','Completion Time (ms)','Completion Time','Completed UTC','Game ID','Score'];
    const lines = [header.map(csvCell).join(',')];
    rows.forEach((r, index) => {
      const ms = Number(r.completion_time_ms || 0);
      const totalSeconds = Math.floor(ms / 1000);
      const minutes = Math.floor(totalSeconds / 60);
      const seconds = totalSeconds % 60;
      const hundredths = Math.floor((ms % 1000) / 10);
      const formatted = `${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}.${String(hundredths).padStart(2,'0')}`;
      lines.push([
        index + 1, r.company_name, r.player_name, r.display_name,
        ms, formatted, r.completed_at, r.game_id, r.score
      ].map(csvCell).join(','));
    });
    const filename = `gravity-shift-level-${level}-top-10.csv`;
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send('\ufeff' + lines.join('\r\n'));
  } catch (error) {
    res.status(error.statusCode || 400).json({ error: error.message || 'Unable to export leaderboard.' });
  }
});

app.get('/api/admin/records', requireAdmin, async (req, res) => {
  try {
    const level = req.query.level ? validateLevel(req.query.level) : null;
    const limit = req.query.limit ? Math.min(100000, Math.max(1, Number(req.query.limit))) : null;
    const offset = Math.max(0, Number(req.query.offset) || 0);
    res.json({ records: await getAllRecords({ levelNumber: level, limit, offset }) });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

/* Testing-only reset. Disabled automatically once EVENT_LIVE=true. */
app.post('/api/admin/testing/clear', requireAdmin, async (req, res) => {
  if (eventLive) return res.status(403).json({ error: 'Test-data reset is disabled because EVENT_LIVE=true.' });
  if (String(req.body?.confirmation || '') !== 'DELETE ALL TEST DATA') {
    return res.status(400).json({ error: 'Confirmation text does not match.' });
  }
  try {
    await clearTestData();
    res.json({ ok: true, message: 'All test records were cleared.' });
  } catch (error) {
    res.status(500).json({ error: 'Unable to clear test data.' });
  }
});

app.get(['/admin', '/admin/login'], (req, res) => {
  res.sendFile(path.join(ROOT, 'admin.html'));
});
app.get('/controller', (req, res) => {
  res.sendFile(path.join(ROOT, 'controller.html'));
});

/*
  WebSocket controller channel.
  Vercel supports WebSockets in Public Beta on Fluid Compute. The game also
  has automatic backup controls, so controller failure does not stop play.
*/
const httpServer = http.createServer(app);
const controllerWss = new WebSocketServer({ noServer: true });
const controllerChannels = new Map();

function getControllerChannel(code) {
  if (!controllerChannels.has(code)) controllerChannels.set(code, { game: null, controllers: new Set() });
  return controllerChannels.get(code);
}
function removeSocketFromChannels(ws) {
  for (const [code, channel] of controllerChannels.entries()) {
    if (channel.game === ws) channel.game = null;
    channel.controllers.delete(ws);
    if (!channel.game && channel.controllers.size === 0) controllerChannels.delete(code);
  }
}

httpServer.on('upgrade', (request, socket, head) => {
  try {
    const url = new URL(request.url, `http://${request.headers.host}`);
    if (url.pathname !== '/ws/controller') {
      socket.destroy();
      return;
    }
    const code = String(url.searchParams.get('code') || '').replace(/[^0-9]/g, '').slice(0, 6);
    const role = url.searchParams.get('role');
    if (!/^\d{6}$/.test(code) || !['game','controller'].includes(role)) {
      socket.destroy();
      return;
    }
    controllerWss.handleUpgrade(request, socket, head, ws => {
      ws.controllerCode = code;
      ws.controllerRole = role;
      controllerWss.emit('connection', ws, request);
    });
  } catch (_) {
    socket.destroy();
  }
});

controllerWss.on('connection', (ws) => {
  const channel = getControllerChannel(ws.controllerCode);
  if (ws.controllerRole === 'game') {
    if (channel.game && channel.game.readyState === WebSocket.OPEN) channel.game.close(4000, 'Replaced by newer game connection');
    channel.game = ws;
  } else {
    channel.controllers.add(ws);
    if (channel.game && channel.game.readyState === WebSocket.OPEN) {
      channel.game.send(JSON.stringify({ source: 'gravity-shift-controller', type: 'heartbeat' }));
    }
  }
  ws.on('message', raw => {
    let message;
    try { message = JSON.parse(raw.toString()); } catch (_) { return; }
    if (ws.controllerRole !== 'controller') return;
    if (message.type === 'heartbeat') {
      if (channel.game && channel.game.readyState === WebSocket.OPEN) {
        channel.game.send(JSON.stringify({ source: 'gravity-shift-controller', type: 'heartbeat' }));
      }
      return;
    }
    if (message.type === 'input') {
      const outgoing = JSON.stringify({
        source: 'gravity-shift-controller',
        type: 'input',
        action: String(message.action || ''),
        pressed: message.pressed !== false
      });
      if (channel.game && channel.game.readyState === WebSocket.OPEN) channel.game.send(outgoing);
    }
  });
  ws.on('close', () => removeSocketFromChannels(ws));
  ws.on('error', () => removeSocketFromChannels(ws));
});

app.get('*', (req, res) => {
  res.sendFile(path.join(ROOT, 'index.html'));
});

async function startLocal() {
  await ensureReady();
  httpServer.listen(port, () => {
    console.log(`Gravity Shift server listening on http://localhost:${port}`);
    console.log(`Database mode: ${usePostgres ? 'PostgreSQL' : 'local SQLite'}`);
  });
}

/*
  Vercel loads this exported server as the Node/Express application.
  Locally, `node server.js` starts a normal HTTP server.
*/
module.exports = httpServer;
module.exports.app = app;

if (require.main === module) {
  startLocal().catch(error => {
    console.error('Failed to start Gravity Shift:', error);
    process.exit(1);
  });
}
