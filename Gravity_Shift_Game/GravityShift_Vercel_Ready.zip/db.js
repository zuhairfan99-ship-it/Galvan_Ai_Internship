const crypto = require('crypto');

const usePostgres = Boolean(process.env.DATABASE_URL);
let sqlite = null;
let pool = null;
let schemaReady = null;

if (usePostgres) {
  const { Pool } = require('pg');
  pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: { rejectUnauthorized: false },
    max: Number(process.env.DB_POOL_MAX || 10),
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });
} else {
  const fs = require('fs');
  const path = require('path');
  const { DatabaseSync } = require('node:sqlite');
  const dbDir = path.join(__dirname, 'data');
  fs.mkdirSync(dbDir, { recursive: true });
  const dbPath = process.env.DB_PATH ? path.resolve(process.env.DB_PATH) : path.join(dbDir, 'leaderboard.db');
  sqlite = new DatabaseSync(dbPath);
  sqlite.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 5000;');
}

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS player_sessions (
  session_id TEXT PRIMARY KEY,
  company_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  last_seen_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS level_attempts (
  attempt_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES player_sessions(session_id),
  level_number INTEGER NOT NULL CHECK (level_number BETWEEN 1 AND 100),
  started_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  completion_time_ms INTEGER,
  status TEXT NOT NULL DEFAULT 'started',
  control_method TEXT,
  connection_status TEXT,
  game_version TEXT,
  metadata_json TEXT,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS game_records (
  id BIGSERIAL PRIMARY KEY,
  game_id TEXT NOT NULL UNIQUE,
  attempt_id TEXT UNIQUE REFERENCES level_attempts(attempt_id),
  session_id TEXT REFERENCES player_sessions(session_id),
  company_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  level_number INTEGER NOT NULL CHECK (level_number BETWEEN 1 AND 100),
  score INTEGER NOT NULL DEFAULT 0,
  completion_time_ms INTEGER NOT NULL CHECK (completion_time_ms >= 100),
  level_start_time TIMESTAMPTZ,
  level_completion_time TIMESTAMPTZ,
  completed_at TIMESTAMPTZ NOT NULL,
  "timestamp" TIMESTAMPTZ NOT NULL,
  game_start_time TIMESTAMPTZ,
  game_end_time TIMESTAMPTZ,
  duration INTEGER,
  control_method TEXT,
  device_id TEXT,
  external_controller_used INTEGER DEFAULT 0,
  connection_status TEXT,
  reached_stage TEXT,
  combo INTEGER DEFAULT 0,
  mistakes INTEGER DEFAULT 0,
  game_version TEXT,
  valid_completion INTEGER NOT NULL DEFAULT 1,
  metadata_json TEXT,
  created_at TIMESTAMPTZ NOT NULL,
  idempotency_key TEXT UNIQUE
);

CREATE INDEX IF NOT EXISTS idx_records_level_rank
  ON game_records(level_number, completion_time_ms ASC, completed_at ASC);
CREATE INDEX IF NOT EXISTS idx_records_company ON game_records(company_name);
CREATE INDEX IF NOT EXISTS idx_records_player ON game_records(player_name);
CREATE INDEX IF NOT EXISTS idx_records_completed_at ON game_records(completed_at);
CREATE INDEX IF NOT EXISTS idx_attempts_level ON level_attempts(level_number, started_at);
CREATE INDEX IF NOT EXISTS idx_attempts_session ON level_attempts(session_id);
`;

function sanitizeString(value, fallback = '') {
  if (value === undefined || value === null) return fallback;
  return String(value).replace(/[\u0000-\u001F\u007F]/g, '').trim();
}

function normalizeParticipantName(input) {
  const text = sanitizeString(input, '').replace(/\s*[-–—]\s*/g, ' - ').replace(/\s+/g, ' ').trim();
  const parts = text.split(' - ');
  if (parts.length !== 2 || !parts[0].trim() || !parts[1].trim()) {
    throw new Error('Participant name must use the format: Company Name - Player Name');
  }
  const company_name = sanitizeString(parts[0]);
  const player_name = sanitizeString(parts[1]);
  if (!company_name || !player_name) throw new Error('Company name and player name are required.');
  return { company_name, player_name, display_name: `${company_name} - ${player_name}` };
}

function generateId(prefix) {
  return `${prefix}-${crypto.randomUUID()}`;
}
function nowUtc() {
  return new Date().toISOString();
}

async function ensureReady() {
  if (!schemaReady) {
    schemaReady = (async () => {
      if (usePostgres) {
        await pool.query(SCHEMA_SQL);
      } else {
        // Translate the portable schema into SQLite-compatible DDL.
        sqlite.exec(`
          CREATE TABLE IF NOT EXISTS player_sessions (
            session_id TEXT PRIMARY KEY,
            company_name TEXT NOT NULL,
            player_name TEXT NOT NULL,
            display_name TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_seen_at TEXT NOT NULL
          );
          CREATE TABLE IF NOT EXISTS level_attempts (
            attempt_id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            level_number INTEGER NOT NULL,
            started_at TEXT NOT NULL,
            completed_at TEXT,
            completion_time_ms INTEGER,
            status TEXT NOT NULL DEFAULT 'started',
            control_method TEXT,
            connection_status TEXT,
            game_version TEXT,
            metadata_json TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(session_id) REFERENCES player_sessions(session_id)
          );
          CREATE TABLE IF NOT EXISTS game_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            game_id TEXT NOT NULL UNIQUE,
            attempt_id TEXT UNIQUE,
            session_id TEXT,
            company_name TEXT NOT NULL,
            player_name TEXT NOT NULL,
            display_name TEXT NOT NULL,
            level_number INTEGER NOT NULL,
            score INTEGER NOT NULL DEFAULT 0,
            completion_time_ms INTEGER NOT NULL,
            level_start_time TEXT,
            level_completion_time TEXT,
            completed_at TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            game_start_time TEXT,
            game_end_time TEXT,
            duration INTEGER,
            control_method TEXT,
            device_id TEXT,
            external_controller_used INTEGER DEFAULT 0,
            connection_status TEXT,
            reached_stage TEXT,
            combo INTEGER DEFAULT 0,
            mistakes INTEGER DEFAULT 0,
            game_version TEXT,
            valid_completion INTEGER NOT NULL DEFAULT 1,
            metadata_json TEXT,
            created_at TEXT NOT NULL,
            idempotency_key TEXT UNIQUE,
            FOREIGN KEY(attempt_id) REFERENCES level_attempts(attempt_id),
            FOREIGN KEY(session_id) REFERENCES player_sessions(session_id)
          );
          CREATE INDEX IF NOT EXISTS idx_records_level_rank ON game_records(level_number, completion_time_ms ASC, completed_at ASC);
          CREATE INDEX IF NOT EXISTS idx_records_company ON game_records(company_name);
          CREATE INDEX IF NOT EXISTS idx_records_player ON game_records(player_name);
          CREATE INDEX IF NOT EXISTS idx_records_completed_at ON game_records(completed_at);
          CREATE INDEX IF NOT EXISTS idx_attempts_level ON level_attempts(level_number, started_at);
          CREATE INDEX IF NOT EXISTS idx_attempts_session ON level_attempts(session_id);
        `);
      }
    })().catch(err => { schemaReady = null; throw err; });
  }
  return schemaReady;
}

function normalizeSql(text) {
  let sql = String(text);
  if (usePostgres) {
    if (!/\$\d+/.test(sql) && sql.includes('?')) {
      let i = 0;
      sql = sql.replace(/\?/g, () => `$${++i}`);
    }
    return sql;
  }
  return sql.replace(/\$\d+/g, '?');
}

async function q(text, params = []) {
  await ensureReady();
  const sql = normalizeSql(text);
  if (usePostgres) {
    const r = await pool.query(sql, params);
    return r.rows;
  }
  return sqlite.prepare(sql).all(...params);
}
async function qOne(text, params = []) {
  await ensureReady();
  const sql = normalizeSql(text);
  if (usePostgres) {
    const r = await pool.query(sql, params);
    return r.rows[0] || null;
  }
  return sqlite.prepare(sql).get(...params) || null;
}
async function exec(text, params = []) {
  await ensureReady();
  const sql = normalizeSql(text);
  if (usePostgres) {
    await pool.query(sql, params);
  } else {
    sqlite.prepare(sql).run(...params);
  }
}

async function createPlayerSession(participant) {
  const parsed = normalizeParticipantName(participant);
  const session_id = generateId('SESSION');
  const now = nowUtc();
  if (usePostgres) {
    await pool.query(
      `INSERT INTO player_sessions(session_id,company_name,player_name,display_name,created_at,last_seen_at)
       VALUES($1,$2,$3,$4,$5,$5)`,
      [session_id, parsed.company_name, parsed.player_name, parsed.display_name, now]
    );
  } else {
    sqlite.prepare(`INSERT INTO player_sessions(session_id,company_name,player_name,display_name,created_at,last_seen_at)
      VALUES(?,?,?,?,?,?)`).run(session_id, parsed.company_name, parsed.player_name, parsed.display_name, now, now);
  }
  return { session_id, ...parsed, created_at: now };
}

async function getPlayerSession(sessionId) {
  return qOne('SELECT * FROM player_sessions WHERE session_id = $1'.replace('$1','?'), [sanitizeString(sessionId)]);
}

async function touchPlayerSession(sessionId) {
  const now = nowUtc();
  if (usePostgres) await pool.query('UPDATE player_sessions SET last_seen_at=$1 WHERE session_id=$2', [now, sessionId]);
  else sqlite.prepare('UPDATE player_sessions SET last_seen_at=? WHERE session_id=?').run(now, sessionId);
}

async function startLevelAttempt({ session_id, level_number, control_method, connection_status, game_version, metadata, client_started_at, offline_recovery }) {
  const session = await getPlayerSession(session_id);
  if (!session) throw new Error('Invalid player session.');
  const level = Number(level_number);
  if (!Number.isInteger(level) || level < 1 || level > 100) throw new Error('Level must be between 1 and 100.');

  const attempt_id = generateId('ATTEMPT');
  const nowMs = Date.now();
  let started_at = nowUtc();
  if (offline_recovery && client_started_at) {
    const candidate = Date.parse(client_started_at);
    if (Number.isFinite(candidate) && candidate <= nowMs + 5 * 60 * 1000 && candidate >= nowMs - 24 * 60 * 60 * 1000) {
      started_at = new Date(candidate).toISOString();
    }
  }
  const vals = [attempt_id, session_id, level, started_at, 'started', sanitizeString(control_method,'Backup'),
    sanitizeString(connection_status,'unknown'), sanitizeString(game_version,'1.2.0'), JSON.stringify(metadata || {}), started_at];
  if (usePostgres) {
    await pool.query(`INSERT INTO level_attempts(
      attempt_id,session_id,level_number,started_at,status,control_method,connection_status,game_version,metadata_json,created_at)
      VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`, vals);
  } else {
    sqlite.prepare(`INSERT INTO level_attempts(
      attempt_id,session_id,level_number,started_at,status,control_method,connection_status,game_version,metadata_json,created_at)
      VALUES(?,?,?,?,?,?,?,?,?,?)`).run(...vals);
  }
  await touchPlayerSession(session_id);
  return { attempt_id, started_at, level_number: level };
}

async function getAttempt(attemptId) {
  return qOne('SELECT * FROM level_attempts WHERE attempt_id = $1'.replace('$1','?'), [sanitizeString(attemptId)]);
}

function parseJson(value) {
  try { return value ? JSON.parse(value) : {}; } catch (_) { return {}; }
}

async function completeLevelAttempt(payload) {
  await ensureReady();
  const attempt = await getAttempt(payload.attempt_id);
  if (!attempt) throw new Error('Unknown level attempt.');
  if (payload.session_id && String(payload.session_id) !== String(attempt.session_id)) {
    throw new Error('Attempt does not belong to this player session.');
  }
  const session = await getPlayerSession(attempt.session_id);
  if (!session) throw new Error('Player session no longer exists.');

  const existing = await qOne('SELECT * FROM game_records WHERE attempt_id = $1'.replace('$1','?'), [attempt.attempt_id]);
  if (existing) return { record: existing, duplicate: true };
  if (attempt.status === 'completed') throw new Error('This attempt has already been completed.');

  const completionTimeMs = Number(payload.completion_time_ms);
  if (!Number.isFinite(completionTimeMs) || completionTimeMs < 100 || completionTimeMs > 24 * 60 * 60 * 1000) {
    throw new Error('Invalid completion time.');
  }

  const completedAt = nowUtc();
  const startedAtMs = Date.parse(attempt.started_at);
  const completedAtMs = Date.parse(completedAt);
  const serverElapsed = completedAtMs - startedAtMs;
  if (!Number.isFinite(serverElapsed) || completionTimeMs < Math.max(100, serverElapsed - 5000)) {
    throw new Error('Completion time failed server validation.');
  }

  const score = Number(payload.score || 0);
  if (!Number.isFinite(score) || score < 0 || score > 100000000) throw new Error('Invalid score.');

  const idempotencyKey = sanitizeString(payload.idempotency_key || attempt.attempt_id);
  const duplicateByKey = await qOne('SELECT * FROM game_records WHERE idempotency_key = $1'.replace('$1','?'), [idempotencyKey]);
  if (duplicateByKey) return { record: duplicateByKey, duplicate: true };

  const gameId = generateId('GAME');
  const record = {
    game_id: gameId, attempt_id: attempt.attempt_id, session_id: attempt.session_id,
    company_name: session.company_name, player_name: session.player_name, display_name: session.display_name,
    level_number: attempt.level_number, score: Math.floor(score), completion_time_ms: Math.floor(completionTimeMs),
    level_start_time: attempt.started_at, level_completion_time: completedAt, completed_at: completedAt,
    timestamp: completedAt, game_start_time: attempt.started_at, game_end_time: completedAt,
    duration: Math.floor(completionTimeMs), control_method: sanitizeString(payload.control_method || attempt.control_method || 'Backup'),
    device_id: sanitizeString(payload.device_id), external_controller_used: Number(payload.external_controller_used ? 1 : 0),
    connection_status: sanitizeString(payload.connection_status || attempt.connection_status || 'unknown'),
    reached_stage: `Level ${attempt.level_number}`, combo: Number(payload.combo || 0), mistakes: Number(payload.mistakes || 0),
    game_version: sanitizeString(payload.game_version || attempt.game_version || '1.2.0', '1.2.0'),
    valid_completion: 1, metadata_json: JSON.stringify(payload.metadata || parseJson(attempt.metadata_json)),
    created_at: completedAt, idempotency_key: idempotencyKey
  };

  if (usePostgres) {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');
      const inserted = await client.query(`INSERT INTO game_records(
        game_id,attempt_id,session_id,company_name,player_name,display_name,level_number,score,completion_time_ms,
        level_start_time,level_completion_time,completed_at,"timestamp",game_start_time,game_end_time,duration,
        control_method,device_id,external_controller_used,connection_status,reached_stage,combo,mistakes,
        game_version,valid_completion,metadata_json,created_at,idempotency_key
      ) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27)
      RETURNING *`, [
        record.game_id,record.attempt_id,record.session_id,record.company_name,record.player_name,record.display_name,
        record.level_number,record.score,record.completion_time_ms,record.level_start_time,record.level_completion_time,
        record.completed_at,record.game_start_time,record.game_end_time,record.duration,record.control_method,
        record.device_id,record.external_controller_used,record.connection_status,record.reached_stage,record.combo,
        record.mistakes,record.game_version,record.valid_completion,record.metadata_json,record.created_at,record.idempotency_key
      ]);
      await client.query(`UPDATE level_attempts SET status='completed',completed_at=$1,completion_time_ms=$2,
        control_method=$3,connection_status=$4,game_version=$5 WHERE attempt_id=$6`,
        [completedAt,record.completion_time_ms,record.control_method,record.connection_status,record.game_version,attempt.attempt_id]);
      await client.query('UPDATE player_sessions SET last_seen_at=$1 WHERE session_id=$2',[completedAt,attempt.session_id]);
      await client.query('COMMIT');
      return { record: inserted.rows[0], duplicate: false };
    } catch (error) {
      await client.query('ROLLBACK').catch(()=>{});
      if (error.code === '23505') {
        const dup = await qOne('SELECT * FROM game_records WHERE idempotency_key = $1'.replace('$1','?'), [idempotencyKey]);
        if (dup) return { record: dup, duplicate: true };
      }
      throw error;
    } finally {
      client.release();
    }
  }

  sqlite.exec('BEGIN IMMEDIATE');
  try {
    sqlite.prepare(`INSERT INTO game_records(
      game_id,attempt_id,session_id,company_name,player_name,display_name,level_number,score,completion_time_ms,
      level_start_time,level_completion_time,completed_at,timestamp,game_start_time,game_end_time,duration,
      control_method,device_id,external_controller_used,connection_status,reached_stage,combo,mistakes,
      game_version,valid_completion,metadata_json,created_at,idempotency_key
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      record.game_id,record.attempt_id,record.session_id,record.company_name,record.player_name,record.display_name,
      record.level_number,record.score,record.completion_time_ms,record.level_start_time,record.level_completion_time,
      record.completed_at,record.timestamp,record.game_start_time,record.game_end_time,record.duration,
      record.control_method,record.device_id,record.external_controller_used,record.connection_status,
      record.reached_stage,record.combo,record.mistakes,record.game_version,record.valid_completion,
      record.metadata_json,record.created_at,record.idempotency_key
    );
    sqlite.prepare(`UPDATE level_attempts SET status='completed',completed_at=?,completion_time_ms=?,control_method=?,
      connection_status=?,game_version=? WHERE attempt_id=?`).run(
      completedAt,record.completion_time_ms,record.control_method,record.connection_status,record.game_version,attempt.attempt_id
    );
    touchPlayerSession(attempt.session_id);
    sqlite.exec('COMMIT');
    return { record, duplicate:false };
  } catch (error) {
    try { sqlite.exec('ROLLBACK'); } catch (_) {}
    if (String(error.message).includes('UNIQUE constraint failed')) {
      const dup = await qOne('SELECT * FROM game_records WHERE idempotency_key = $1'.replace('$1','?'), [idempotencyKey]);
      if (dup) return { record: dup, duplicate: true };
    }
    throw error;
  }
}

async function rankForRecord(record) {
  if (!record) return null;
  const row = await qOne(`
    SELECT COUNT(*) + 1 AS rank
    FROM game_records
    WHERE valid_completion = 1 AND level_number = $1
      AND (completion_time_ms < $2 OR (completion_time_ms = $2 AND completed_at < $3))
  `.replace(/\$(\d+)/g, (_,n)=>`?`), [record.level_number, record.completion_time_ms, record.completed_at]);
  return Number(row?.rank || 1);
}

async function getLevelRecords(levelNumber, limit = 10) {
  const level = Number(levelNumber);
  const safeLimit = Math.min(100, Math.max(1, Number(limit) || 10));
  return q(`
    SELECT *
    FROM game_records
    WHERE valid_completion = 1 AND level_number = $1
    ORDER BY completion_time_ms ASC, completed_at ASC
    LIMIT $2
  `.replace(/\$(\d+)/g, (_,n)=>'?'), [level, safeLimit]).then(rows => rows.map((row,i)=>({rank:i+1,...row})));
}

async function getAllRecords({ levelNumber = null, limit = null, offset = 0 } = {}) {
  let sql = 'SELECT * FROM game_records WHERE valid_completion = 1';
  const params = [];
  if (Number.isInteger(Number(levelNumber)) && Number(levelNumber) >= 1) {
    sql += ' AND level_number = $1';
    params.push(Number(levelNumber));
  }
  sql += ' ORDER BY level_number ASC, completion_time_ms ASC, completed_at ASC';
  if (limit !== null) {
    const p1=params.length+1, p2=params.length+2;
    sql += ` LIMIT $${p1} OFFSET $${p2}`;
    params.push(Math.min(100000, Math.max(1, Number(limit))), Math.max(0, Number(offset)||0));
  }
  if (!usePostgres) sql=sql.replace(/\$\d+/g,'?');
  return q(sql,params);
}

async function getAttemptRecords({ levelNumber = null } = {}) {
  let sql = `SELECT a.*, s.company_name, s.player_name, s.display_name
             FROM level_attempts a JOIN player_sessions s ON s.session_id=a.session_id WHERE 1=1`;
  const params=[];
  if (Number.isInteger(Number(levelNumber)) && Number(levelNumber)>=1) {
    sql += ' AND a.level_number = $1';
    params.push(Number(levelNumber));
  }
  sql += ' ORDER BY a.started_at DESC';
  if (!usePostgres) sql=sql.replace(/\$\d+/g,'?');
  return q(sql,params);
}

async function getCompanyStats() {
  return q(`SELECT company_name, COUNT(*) AS completed_levels, COUNT(DISTINCT player_name) AS unique_players,
    MIN(completion_time_ms) AS best_completion_time_ms, AVG(completion_time_ms) AS average_completion_time_ms,
    SUM(score) AS total_score FROM game_records WHERE valid_completion=1
    GROUP BY company_name ORDER BY completed_levels DESC, best_completion_time_ms ASC, company_name ASC`);
}

async function getPlayerStats() {
  return q(`SELECT company_name, player_name, display_name, COUNT(*) AS completed_levels,
    COUNT(DISTINCT level_number) AS unique_levels, MIN(completion_time_ms) AS best_completion_time_ms,
    AVG(completion_time_ms) AS average_completion_time_ms, SUM(score) AS total_score
    FROM game_records WHERE valid_completion=1
    GROUP BY company_name, player_name, display_name
    ORDER BY completed_levels DESC, best_completion_time_ms ASC, display_name ASC`);
}

async function getLevelStats() {
  return q(`SELECT level_number, COUNT(*) AS completions, MIN(completion_time_ms) AS best_completion_time_ms,
    AVG(completion_time_ms) AS average_completion_time_ms, MAX(completion_time_ms) AS slowest_completion_time_ms
    FROM game_records WHERE valid_completion=1 GROUP BY level_number ORDER BY level_number ASC`);
}

async function getCounts() {
  const [a,b,c,d] = await Promise.all([
    qOne('SELECT COUNT(*) AS n FROM game_records WHERE valid_completion=1'),
    qOne('SELECT COUNT(*) AS n FROM level_attempts'),
    qOne('SELECT COUNT(*) AS n FROM player_sessions'),
    qOne('SELECT COUNT(DISTINCT company_name) AS n FROM game_records')
  ]);
  return { completed_records:Number(a?.n||0), attempts:Number(b?.n||0), players:Number(c?.n||0), companies:Number(d?.n||0) };
}

async function clearTestData() {
  if (usePostgres) {
    const client=await pool.connect();
    try {
      await client.query('BEGIN');
      await client.query('DELETE FROM game_records');
      await client.query('DELETE FROM level_attempts');
      await client.query('DELETE FROM player_sessions');
      await client.query('COMMIT');
    } catch(e) { await client.query('ROLLBACK').catch(()=>{}); throw e; }
    finally { client.release(); }
  } else {
    sqlite.exec('BEGIN IMMEDIATE');
    try {
      sqlite.exec('DELETE FROM game_records; DELETE FROM level_attempts; DELETE FROM player_sessions;');
      sqlite.exec('COMMIT');
    } catch(e) { try{sqlite.exec('ROLLBACK')}catch(_){}; throw e; }
  }
}

async function getAllRecordsForMigration() {
  return q('SELECT * FROM game_records ORDER BY id ASC');
}

module.exports = {
  usePostgres,
  pool,
  ensureReady,
  sanitizeString,
  normalizeParticipantName,
  createPlayerSession,
  getPlayerSession,
  startLevelAttempt,
  getAttempt,
  completeLevelAttempt,
  rankForRecord,
  getLevelRecords,
  getAllRecords,
  getAttemptRecords,
  getCompanyStats,
  getPlayerStats,
  getLevelStats,
  getCounts,
  clearTestData,
  getAllRecordsForMigration
};
