CREATE TABLE IF NOT EXISTS player_sessions (
  session_id TEXT PRIMARY KEY,
  company_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  last_seen_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS level_attempts (
  attempt_id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES player_sessions(session_id),
  level_number INTEGER NOT NULL CHECK (level_number BETWEEN 1 AND 100),
  started_at TIMESTAMPTZ NOT NULL,
  completed_at TIMESTAMPTZ,
  completion_time_ms INTEGER,
  status TEXT NOT NULL DEFAULT 'started',
  control_method TEXT,
  connection_status TEXT,
  game_version TEXT,
  metadata_json TEXT,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS game_records (
  id BIGSERIAL PRIMARY KEY,
  game_id TEXT NOT NULL UNIQUE,
  attempt_id TEXT UNIQUE REFERENCES level_attempts(attempt_id),
  session_id TEXT REFERENCES player_sessions(session_id),
  company_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  display_name TEXT NOT NULL,
  level_number INTEGER NOT NULL CHECK (level_number BETWEEN 1 AND 100),
  score INTEGER NOT NULL DEFAULT 0,
  completion_time_ms INTEGER NOT NULL CHECK (completion_time_ms >= 100),
  level_start_time TIMESTAMPTZ,
  level_completion_time TIMESTAMPTZ,
  completed_at TIMESTAMPTZ NOT NULL,
  "timestamp" TIMESTAMPTZ NOT NULL,
  game_start_time TIMESTAMPTZ,
  game_end_time TIMESTAMPTZ,
  duration INTEGER,
  control_method TEXT,
  device_id TEXT,
  external_controller_used INTEGER DEFAULT 0,
  connection_status TEXT,
  reached_stage TEXT,
  combo INTEGER DEFAULT 0,
  mistakes INTEGER DEFAULT 0,
  game_version TEXT,
  valid_completion INTEGER NOT NULL DEFAULT 1,
  metadata_json TEXT,
  created_at TIMESTAMPTZ NOT NULL,
  idempotency_key TEXT UNIQUE
);

CREATE INDEX IF NOT EXISTS idx_records_level_rank ON game_records(level_number, completion_time_ms ASC, completed_at ASC);
CREATE INDEX IF NOT EXISTS idx_records_company ON game_records(company_name);
CREATE INDEX IF NOT EXISTS idx_records_player ON game_records(player_name);
CREATE INDEX IF NOT EXISTS idx_records_completed_at ON game_records(completed_at);
CREATE INDEX IF NOT EXISTS idx_attempts_level ON level_attempts(level_number, started_at);
CREATE INDEX IF NOT EXISTS idx_attempts_session ON level_attempts(session_id);
