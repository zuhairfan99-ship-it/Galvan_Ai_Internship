let socket=null, heartbeatTimer=null;
const $=id=>document.getElementById(id);
function setStatus(text){$('status').textContent=text}
function send(action,pressed=true){if(socket?.readyState===WebSocket.OPEN)socket.send(JSON.stringify({type:'input',action,pressed}))}
function connect(){
  const code=$('code').value.replace(/\D/g,'');
  if(code.length!==6){setStatus('Enter the six-digit code shown on the game screen.');return}
  const protocol=location.protocol==='https:'?'wss:':'ws:';
  socket=new WebSocket(`${protocol}//${location.host}/ws/controller?role=controller&code=${code}`);
  socket.addEventListener('open',()=>{
    $('controls').classList.remove('hidden');$('connectCard').classList.add('hidden');setStatus('Connected');
    heartbeatTimer=setInterval(()=>socket?.send(JSON.stringify({type:'heartbeat'})),2000);
  });
  socket.addEventListener('close',()=>{clearInterval(heartbeatTimer);heartbeatTimer=null;$('controls').classList.add('hidden');$('connectCard').classList.remove('hidden');setStatus('Controller disconnected.');});
  socket.addEventListener('error',()=>setStatus('Connection failed.'));
}
$('connect').addEventListener('click',connect);
$('disconnect').addEventListener('click',()=>socket?.close());
document.querySelectorAll('[data-action]').forEach(btn=>{
  const action=btn.dataset.action;
  const down=e=>{e.preventDefault();send(action,true)};
  const up=e=>{e.preventDefault();send(action,false)};
  btn.addEventListener('pointerdown',down);btn.addEventListener('pointerup',up);btn.addEventListener('pointercancel',up);btn.addEventListener('pointerleave',up);
});
